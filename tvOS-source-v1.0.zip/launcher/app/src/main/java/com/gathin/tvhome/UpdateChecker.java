package com.gathin.tvhome;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads the project's latest GitHub release and the launcher version code in its build.gradle. Android only treats
 * an APK as an update when its version code is higher, so the comparison is on that number, not on the tag: a fork
 * with its own 1.x versions is never told to install an unrelated upstream build.
 */
final class UpdateChecker {

    private static final String RELEASES =
            "https://api.github.com/repos/Gathin23/cleanyourtv/releases/latest";
    private static final String BUILD_GRADLE =
            "https://raw.githubusercontent.com/Gathin23/cleanyourtv/%s/launcher/app/build.gradle";
    private static final Pattern VERSION_CODE = Pattern.compile("versionCode\\s+(\\d+)");

    interface Listener {
        void onChecked(String tag, String releaseUrl, Integer upstreamVersionCode);

        void onFailed();
    }

    private UpdateChecker() { }

    static void check(Context context, Listener listener) {
        Context app = context.getApplicationContext();
        Handler main = new Handler(Looper.getMainLooper());
        Thread worker = new Thread(() -> {
            try {
                JSONObject release = new JSONObject(get(RELEASES));
                String tag = release.optString("tag_name", "");
                String url = release.optString("html_url", "");
                if (tag.isEmpty() || url.isEmpty()) {
                    main.post(listener::onFailed);
                    return;
                }
                Integer upstream = null;
                try {
                    Matcher matcher = VERSION_CODE.matcher(get(String.format(BUILD_GRADLE, tag)));
                    if (matcher.find()) upstream = Integer.parseInt(matcher.group(1));
                } catch (Exception unknownBuild) {
                    // A release without a readable build.gradle still names itself: no update is offered.
                }
                Integer code = upstream;
                main.post(() -> listener.onChecked(tag, url, code));
            } catch (Exception offline) {
                main.post(listener::onFailed);
            }
        }, "update-check");
        worker.setDaemon(true);
        worker.start();
    }

    private static String get(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(10_000);
        connection.setReadTimeout(10_000);
        connection.setRequestProperty("Accept", "application/vnd.github+json");
        connection.setRequestProperty("User-Agent", "tvos-launcher");
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) body.append(line).append('\n');
            return body.toString();
        } finally {
            connection.disconnect();
        }
    }
}
