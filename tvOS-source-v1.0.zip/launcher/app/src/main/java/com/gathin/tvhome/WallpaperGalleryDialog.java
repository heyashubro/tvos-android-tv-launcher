package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** A remote-friendly gallery of images the TV's media scanner has indexed. */
final class WallpaperGalleryDialog {
    interface Listener {
        void onSelected(Uri uri, String name);
    }

    private static final String[] PROJECTION = {
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_ADDED
    };
    private static final ExecutorService THUMBNAILS = Executors.newFixedThreadPool(2);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private WallpaperGalleryDialog() { }

    static void show(Activity activity, String emptyMessage, String title, Listener listener) {
        List<Image> images = query(activity);
        RecyclerView grid = new RecyclerView(activity);
        grid.setLayoutManager(new GridLayoutManager(activity, 4));
        grid.setClipToPadding(false);
        grid.setPadding(dp(activity, 18), dp(activity, 12), dp(activity, 18), dp(activity, 12));
        WallpaperAdapter adapter = new WallpaperAdapter(activity, images, emptyMessage, listener);
        grid.setAdapter(adapter);

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(title)
                .setView(grid)
                .setNegativeButton(android.R.string.cancel, null)
                .create();
        dialog.setOnShowListener(ignored -> {
            int width = Math.round(activity.getResources().getDisplayMetrics().widthPixels * 0.88f);
            int height = Math.round(activity.getResources().getDisplayMetrics().heightPixels * 0.78f);
            dialog.getWindow().setLayout(width, height);
            adapter.dialog = dialog;
            if (!images.isEmpty()) grid.post(() -> {
                RecyclerView.ViewHolder first = grid.findViewHolderForAdapterPosition(0);
                if (first != null) first.itemView.requestFocus();
            });
        });
        dialog.show();
    }

    static List<Image> query(Context context) {
        List<Image> images = new ArrayList<>();
        Uri collection = Build.VERSION.SDK_INT >= 29
                ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        try (Cursor cursor = context.getContentResolver().query(collection, PROJECTION,
                null, null, MediaStore.Images.Media.DATE_ADDED + " DESC")) {
            if (cursor == null) return images;
            int idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
            int nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
            while (cursor.moveToNext()) {
                Uri uri = ContentUris.withAppendedId(collection, cursor.getLong(idColumn));
                String name = cursor.getString(nameColumn);
                images.add(new Image(uri, name == null || name.isEmpty() ? "Image" : name));
            }
        } catch (SecurityException ignored) {
            // Permission is checked before this dialog opens. A revoked permission is handled as an empty gallery.
        }
        return images;
    }

    private static int dp(Context context, int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    static final class Image {
        final Uri uri;
        final String name;
        Image(Uri uri, String name) { this.uri = uri; this.name = name; }
    }

    private static final class WallpaperAdapter extends RecyclerView.Adapter<WallpaperAdapter.Holder> {
        final Activity activity;
        final List<Image> images;
        final String emptyMessage;
        final Listener listener;
        AlertDialog dialog;

        WallpaperAdapter(Activity activity, List<Image> images, String emptyMessage, Listener listener) {
            this.activity = activity;
            this.images = images;
            this.emptyMessage = emptyMessage;
            this.listener = listener;
            setHasStableIds(true);
        }

        @Override public long getItemId(int position) { return position; }
        @Override public int getItemCount() { return Math.max(1, images.size()); }

        @Override public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
            if (images.isEmpty()) {
                TextView empty = new TextView(activity);
                empty.setText(emptyMessage);
                empty.setTextColor(0xFFFFFFFF);
                empty.setTextSize(18);
                empty.setGravity(Gravity.CENTER);
                empty.setFocusable(false);
                return new Holder(empty, null);
            }
            LinearLayout card = new LinearLayout(activity);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setFocusable(true);
            card.setClickable(true);
            card.setBackgroundResource(R.drawable.settings_choice_bg);
            card.setPadding(dp(activity, 8), dp(activity, 8), dp(activity, 8), dp(activity, 8));
            ImageView image = new ImageView(activity);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            card.addView(image, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 112)));
            TextView name = new TextView(activity);
            name.setTextColor(0xFFFFFFFF);
            name.setTextSize(13);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            name.setGravity(Gravity.CENTER_VERTICAL);
            name.setPadding(dp(activity, 4), dp(activity, 5), dp(activity, 4), 0);
            card.addView(name, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 28)));
            return new Holder(card, image);
        }

        @Override public void onBindViewHolder(Holder holder, int position) {
            if (images.isEmpty()) return;
            Image item = images.get(position);
            holder.itemView.setTag(item.uri);
            holder.name.setText(item.name);
            holder.itemView.setOnClickListener(v -> {
                if (dialog != null) dialog.dismiss();
                listener.onSelected(item.uri, item.name);
            });
            holder.image.setImageDrawable(null);
            THUMBNAILS.execute(() -> {
                Bitmap bitmap = null;
                try {
                    if (Build.VERSION.SDK_INT >= 29) {
                        bitmap = activity.getContentResolver().loadThumbnail(item.uri,
                                new Size(dp(activity, 320), dp(activity, 180)), null);
                    } else {
                        try (InputStream input = activity.getContentResolver().openInputStream(item.uri)) {
                            if (input != null) {
                                BitmapFactory.Options options = new BitmapFactory.Options();
                                options.inSampleSize = 4;
                                bitmap = BitmapFactory.decodeStream(input, null, options);
                            }
                        }
                    }
                } catch (Exception ignored) {
                    // One unreadable image should not prevent choosing any of the others.
                }
                Bitmap result = bitmap;
                MAIN.post(() -> {
                    if (result != null && item.uri.equals(holder.itemView.getTag())) {
                        holder.image.setImageBitmap(result);
                    }
                });
            });
        }

        static final class Holder extends RecyclerView.ViewHolder {
            final ImageView image;
            final TextView name;
            Holder(View view, ImageView image) {
                super(view);
                this.image = image;
                this.name = image == null ? null : (TextView) ((LinearLayout) view).getChildAt(1);
            }
        }
    }
}
