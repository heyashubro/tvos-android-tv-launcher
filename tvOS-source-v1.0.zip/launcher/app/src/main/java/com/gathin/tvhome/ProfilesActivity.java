package com.gathin.tvhome;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * The tvOS-style profile picker over Home: a glass panel in the top-right corner with a two-column avatar
 * grid. Choosing a profile switches Home to it; the Add tile creates a fourth, and so on.
 */
public final class ProfilesActivity extends LauncherActivity {

    private static final int EDITOR = 1;
    private static final int COLUMNS = 2;
    private GridLayout grid;
    private boolean reducedMotion;

    @Override
    protected int themeRes() {
        return R.style.Theme_Panel;
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_profiles);
        reducedMotion = Config.load(this).reducedMotion;
        ProfileStore.syncAccount(this);
        grid = findViewById(R.id.profileGrid);
        findViewById(R.id.profileScrim).setOnClickListener(v -> finish());
        View panel = findViewById(R.id.profilePanel);
        panel.setClickable(true);
        setUpBackdrop();
        render();
        playEntrance(panel);
    }

    private void setUpBackdrop() {
        Bitmap backdrop = ControlCenterBackdrop.current();
        if (backdrop != null) {
            ImageView image = findViewById(R.id.profileBackdrop);
            // Frosted, not merely blurred: the picker is about the faces, and the room behind them should
            // read as ground glass, the way the Apple TV profile sheet sits on its wallpaper.
            image.setImageBitmap(ControlCenterBackdrop.frost(backdrop));
            image.setVisibility(View.VISIBLE);
        }
        findViewById(R.id.profileShade).setBackgroundResource(R.drawable.glass_frost);
    }

    private void playEntrance(View panel) {
        if (reducedMotion) return;
        panel.setAlpha(0f);
        panel.setScaleX(0.96f);
        panel.setScaleY(0.96f);
        panel.setTranslationY(-dp(8));
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(200).setInterpolator(new DecelerateInterpolator()).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (grid != null && grid.getChildCount() > 0) render();
    }

    private void render() {
        grid.removeAllViews();
        List<ProfileStore.Profile> profiles = ProfileStore.list(this);
        boolean guest = ProfileStore.isGuest(this);
        String active = ProfileStore.activeId(this);
        int focusIndex = 0;
        for (int i = 0; i < profiles.size(); i++) {
            ProfileStore.Profile profile = profiles.get(i);
            if (profile.id.equals(active)) focusIndex = i;
            addCard(profile, profile.id.equals(active));
        }
        if (guest) focusIndex = profiles.size();
        addGuestCard(guest);
        // Guest keeps nothing, so adding a profile is offered only outside a guest session.
        if (!guest) addCard(null, false);
        int count = grid.getChildCount();
        for (int i = 0; i < count; i++) setUpKeys(grid.getChildAt(i), i, count);
        View focus = grid.getChildAt(Math.min(focusIndex, count - 1));
        if (focus != null) focus.post(focus::requestFocus);
    }

    private void addCard(ProfileStore.Profile profile, boolean current) {
        View card = getLayoutInflater().inflate(R.layout.item_profile_avatar, grid, false);
        ImageView avatar = card.findViewById(R.id.avatar);
        TextView name = card.findViewById(R.id.name);
        if (profile == null) {
            avatar.setImageResource(R.drawable.ic_add);
            avatar.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            int pad = dp(26);
            avatar.setPadding(pad, pad, pad, pad);
            name.setText(R.string.profile_add);
            card.setContentDescription(getString(R.string.profile_add));
        } else {
            avatar.setImageDrawable(profile.avatarDrawable(this));
            name.setText(profile.name);
            card.setContentDescription(profile.name + (current ? ", " + getString(R.string.profile_current) : ""));
            card.findViewById(R.id.profileCurrent).setVisibility(current ? View.VISIBLE : View.GONE);
        }
        card.setOnClickListener(v -> {
            if (profile == null) {
                startActivityForResult(new Intent(this, ProfileEditorActivity.class), EDITOR);
            } else {
                switchTo(profile);
            }
        });
        setUpCardFocus(card);
        grid.addView(card);
    }

    private void addGuestCard(boolean current) {
        View card = getLayoutInflater().inflate(R.layout.item_profile_avatar, grid, false);
        ImageView avatar = card.findViewById(R.id.avatar);
        avatar.setImageResource(R.drawable.profile_avatar_default);
        ((TextView) card.findViewById(R.id.name)).setText(R.string.profile_guest);
        card.setContentDescription(getString(R.string.profile_guest_desc)
                + (current ? ", " + getString(R.string.profile_current) : ""));
        card.findViewById(R.id.profileCurrent).setVisibility(current ? View.VISIBLE : View.GONE);
        card.setOnClickListener(v -> {
            if (ProfileStore.isGuest(this)) return;
            ProfileStore.enterGuest(this);
            setResult(RESULT_OK);
            finish();
        });
        setUpCardFocus(card);
        grid.addView(card);
    }

    private void setUpCardFocus(View card) {
        card.setOnFocusChangeListener((v, focused) -> {
            v.animate().scaleX(focused ? 1.06f : 1f).scaleY(focused ? 1.06f : 1f)
                    .setDuration(reducedMotion ? Motion.REDUCED_MS : 160).start();
            v.setTranslationZ(focused ? dp(6) : 0);
        });
    }

    /** Explicit grid walking; the automatic focus search leaves the small panel on the first sideways press. */
    private void setUpKeys(View card, int index, int count) {
        card.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            int row = index / COLUMNS;
            int column = index % COLUMNS;
            int target = -1;
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && column < COLUMNS - 1 && index + 1 < count) {
                target = index + 1;
            } else if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && column > 0) {
                target = index - 1;
            } else if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN && index + COLUMNS < count) {
                target = index + COLUMNS;
            } else if (keyCode == KeyEvent.KEYCODE_DPAD_UP && row > 0) {
                target = index - COLUMNS;
            } else if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT || keyCode == KeyEvent.KEYCODE_DPAD_LEFT
                    || keyCode == KeyEvent.KEYCODE_DPAD_DOWN || keyCode == KeyEvent.KEYCODE_DPAD_UP) {
                return true;
            } else {
                return false;
            }
            grid.getChildAt(target).requestFocus();
            return true;
        });
    }

    private void switchTo(ProfileStore.Profile profile) {
        if (ProfileStore.isGuest(this)) ProfileStore.leaveGuest(this, profile.id);
        else ProfileStore.setActive(this, profile.id);
        setResult(RESULT_OK);
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == EDITOR && resultCode == RESULT_OK) {
            setResult(RESULT_OK);
            finish();
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
