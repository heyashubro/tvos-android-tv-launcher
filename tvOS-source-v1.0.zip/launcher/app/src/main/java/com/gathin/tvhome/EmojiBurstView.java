package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;

/**
 * A transparent full-screen overlay that plays a one-off burst of emoji, fired when the owner's side
 * wins a match. Each glyph launches from the celebration point (the sports card), arcs up against
 * gravity, spins and fades over the last third of its flight. Everything finishes within the given
 * duration, then the callback runs on the main thread. The view takes no focus, clicks or
 * accessibility, and allocates nothing per frame.
 */
public final class EmojiBurstView extends View {

    /** Celebration styles, indexed by the Celebration emoji setting. */
    public static final int STYLE_PARTY = 0;
    public static final int STYLE_TROPHIES = 1;
    public static final int STYLE_FIREWORKS = 2;
    private static final String[][] PACKS = {
            {"\uD83C\uDF89", "\uD83C\uDFC6", "\uD83C\uDF8A", "\u2B50", "\uD83C\uDF87"},
            {"\uD83C\uDFC6", "\uD83E\uDD47", "\uD83C\uDFC5", "\uD83D\uDC51", "\u2B50"},
            {"\uD83C\uDF86", "\u2728", "\uD83D\uDCA5", "\uD83C\uDF1F", "\uD83C\uDF87"}
    };
    private static final double TAU = 2 * Math.PI;

    private final float density;
    private final Random rnd = new Random();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int count;
    private float[] x0 = new float[0], y0 = new float[0], vx = new float[0], vy = new float[0],
            size = new float[0], delay = new float[0], life = new float[0],
            rot0 = new float[0], spin = new float[0];
    private int[] glyph = new int[0];

    private int style;
    private boolean playing;
    private long start, duration;
    private Runnable onDone;
    private final Runnable finish = this::finish;

    public EmojiBurstView(Context context) {
        this(context, null);
    }

    public EmojiBurstView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public EmojiBurstView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        density = context.getResources().getDisplayMetrics().density;
        setFocusable(false);
        setClickable(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        setWillNotDraw(false);
        paint.setTextAlign(Paint.Align.CENTER);
    }

    /** The glyph pack: Party, Trophies or Fireworks. */
    public void setStyle(int style) {
        this.style = Math.max(STYLE_PARTY, Math.min(style, PACKS.length - 1));
    }

    /**
     * Plays a burst of {@code emojis} lasting {@code durationMs}, launching from the view-local
     * point ({@code fromX}, {@code fromY}), then runs {@code done} on the main thread. Playing again
     * before the last burst ends finishes that one first (its callback runs).
     */
    public void play(int emojis, long durationMs, float fromX, float fromY, Runnable done) {
        if (playing) {
            removeCallbacks(finish);
            finish();
        }
        int n = Math.max(0, emojis);
        ensureCapacity(n);
        count = n;
        duration = Math.max(1, durationMs);
        onDone = done;
        for (int i = 0; i < n; i++) {
            x0[i] = fromX;
            y0[i] = fromY;
            double angle = -Math.PI / 2 + (rnd.nextFloat() - 0.5f) * 1.9;   // mostly upward fan
            double speed = (170 + rnd.nextFloat() * 260) * density;          // px per second
            vx[i] = (float) (Math.cos(angle) * speed);
            vy[i] = (float) (Math.sin(angle) * speed);
            size[i] = (15f + rnd.nextFloat() * 13f) * density;
            delay[i] = rnd.nextFloat() * 0.18f;
            life[i] = 0.68f + rnd.nextFloat() * (1f - delay[i] - 0.68f);
            rot0[i] = (rnd.nextFloat() - 0.5f) * 60f;
            spin[i] = (120f + rnd.nextFloat() * 220f) * (rnd.nextBoolean() ? 1f : -1f);
            glyph[i] = rnd.nextInt(PACKS[style].length);
        }
        playing = true;
        start = SystemClock.uptimeMillis();
        postDelayed(finish, duration);
        postInvalidateOnAnimation();
    }

    private void finish() {
        if (!playing) return;
        playing = false;
        invalidate();
        Runnable done = onDone;
        onDone = null;
        if (done != null) done.run();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (playing) {
            removeCallbacks(finish);
            finish();
        }
    }

    @Override protected void onDraw(Canvas c) {
        if (!playing) return;
        long now = SystemClock.uptimeMillis();
        float elapsed = (now - start) / (float) duration;
        for (int i = 0; i < count; i++) {
            float p = (elapsed - delay[i]) / life[i];
            if (p <= 0f || p >= 1f) continue;
            // Closed-form parabola over the glyph's own age, so the arc is stable at any frame rate.
            float age = (elapsed - delay[i]) * duration / 1000f;
            float x = x0[i] + vx[i] * age;
            float y = y0[i] + vy[i] * age + 0.5f * 560f * density * age * age;
            int a = p > 0.66f ? (int) (255 * (1f - (p - 0.66f) / 0.34f)) : 255;
            paint.setTextSize(size[i]);
            paint.setAlpha(a);
            c.save();
            c.translate(x, y);
            c.rotate(rot0[i] + spin[i] * age);
            c.drawText(PACKS[style][glyph[i]], 0f, 0f, paint);
            c.restore();
        }
        postInvalidateOnAnimation();
    }

    private void ensureCapacity(int n) {
        if (x0.length >= n) return;
        x0 = new float[n];
        y0 = new float[n];
        vx = new float[n];
        vy = new float[n];
        size = new float[n];
        delay = new float[n];
        life = new float[n];
        rot0 = new float[n];
        spin = new float[n];
        glyph = new int[n];
    }
}
