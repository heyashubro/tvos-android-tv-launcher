package com.gathin.tvhome;

import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.net.Uri;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * The source list: HDMI ports (with their CEC device taking the port's row), AV, the TV's own source panel and
 * Live TV on the tuner. Home shows it as a dropdown under the clock pill and Control Center as a slide of its
 * own, so the enumeration and the per-firmware ways of switching live here once; each caller only draws rows.
 */
final class InputMenu {

    /** The config values the list and the switching need, from config.xml or a theme. */
    static final class Settings {
        final boolean coocaaSources;
        final String sourcePanelService, sourcePanelAction, sourcePanelExtra;
        final String inputAction, inputUriScheme;
        final String liveTvPackage, liveTvAction, liveTvInputId;

        static Settings of(Config cfg) {
            return new Settings(cfg.coocaaSources, cfg.sourcePanelService, cfg.sourcePanelAction,
                    cfg.sourcePanelExtra, cfg.inputAction, cfg.inputUriScheme,
                    cfg.liveTvPackage, cfg.liveTvAction, cfg.liveTvInputId);
        }

        private Settings(boolean coocaaSources, String sourcePanelService, String sourcePanelAction,
                String sourcePanelExtra, String inputAction, String inputUriScheme,
                String liveTvPackage, String liveTvAction, String liveTvInputId) {
            this.coocaaSources = coocaaSources;
            this.sourcePanelService = sourcePanelService;
            this.sourcePanelAction = sourcePanelAction;
            this.sourcePanelExtra = sourcePanelExtra;
            this.inputAction = inputAction;
            this.inputUriScheme = inputUriScheme;
            this.liveTvPackage = liveTvPackage;
            this.liveTvAction = liveTvAction;
            this.liveTvInputId = liveTvInputId;
        }
    }

    /** Where the rows go: a caller adds them to its dropdown or its slide. */
    interface Sink {
        void separator();

        void row(int iconRes, String label, int state, Runnable open);
    }

    private InputMenu() { }

    /**
     * A configured source panel and no Live TV row to offer next to it: the panel is the whole menu, so the
     * caller opens it instead of listing anything. The BYINTEK U4 needs this, as its TvInputManager lists three
     * HDMI ports and an AV input it doesn't have.
     */
    static boolean opensSourcePanelAlone(Context ctx, Settings s) {
        return coocaa(ctx, s).isEmpty() && !s.sourcePanelService.isEmpty() && liveTvIntent(ctx, s) == null;
    }

    /** Fills the sink; false when there is nothing to list. */
    static boolean build(Context ctx, Settings s, Sink sink) {
        List<CoocaaSources.Source> coocaa = coocaa(ctx, s);
        int[] added = {0};
        Sink counting = new Sink() {
            @Override public void separator() {
                if (added[0] > 0) sink.separator();
            }

            @Override public void row(int iconRes, String label, int state, Runnable open) {
                added[0]++;
                sink.row(iconRes, label, state, open);
            }
        };

        String tunerId = null;
        TvInputManager tim = (TvInputManager) ctx.getSystemService(Context.TV_INPUT_SERVICE);
        if (tim != null) {
            List<TvInputInfo> inputs = new ArrayList<>(tim.getTvInputList());
            // HDMI ports first in port order, then AV and the rest.
            Collections.sort(inputs, (a, b) -> {
                boolean ha = a.getType() == TvInputInfo.TYPE_HDMI, hb = b.getType() == TvInputInfo.TYPE_HDMI;
                if (ha != hb) return ha ? -1 : 1;
                return String.valueOf(a.loadLabel(ctx)).compareToIgnoreCase(String.valueOf(b.loadLabel(ctx)));
            });
            // An HDMI-CEC device (an Apple TV, a soundbar) gets an input of its own whose parent is the
            // port it sits on, so the port and the device would each get a row (Vestel MT7332: "HDMI 1"
            // and "HDMI Apple TV"). The device takes its port's row instead, and a bare port is listed
            // only when nothing on it speaks CEC.
            Set<String> inputIds = new HashSet<>();
            for (TvInputInfo info : inputs) inputIds.add(info.getId());
            Map<String, List<TvInputInfo>> cecDevices = new HashMap<>();
            for (TvInputInfo info : inputs) {
                String parent = info.getParentId();
                if (parent == null || !inputIds.contains(parent)) continue;
                if (!info.isPassthroughInput() || info.isHidden(ctx)) continue;
                List<TvInputInfo> onPort = cecDevices.get(parent);
                if (onPort == null) cecDevices.put(parent, onPort = new ArrayList<>());
                onPort.add(info);
            }
            // Some TVs (Sony) report every HDMI port as connected whether or not anything is plugged in,
            // so drop the HDMI status then. A TV with every port really in use loses it too.
            int hdmiPorts = 0, hdmiConnected = 0;
            for (TvInputInfo info : inputs) {
                if (!info.isPassthroughInput() || info.getType() != TvInputInfo.TYPE_HDMI) continue;
                if (info.getParentId() != null && inputIds.contains(info.getParentId())) continue;
                hdmiPorts++;
                if (tim.getInputState(info.getId()) == TvInputManager.INPUT_STATE_CONNECTED) hdmiConnected++;
            }
            boolean hdmiStateBogus = hdmiPorts > 1 && hdmiConnected == hdmiPorts;
            boolean sawNonHdmi = false;
            boolean tunerIsHw = false, tunerIsAnalog = false;
            for (TvInputInfo info : inputs) {
                if (info.getType() == TvInputInfo.TYPE_TUNER
                        && (info.getServiceInfo().applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                        && (s.liveTvInputId.isEmpty() || s.liveTvInputId.equals(info.getId()))) {
                    // Prefer a hardware tuner: the framework names those ".../HW<n>". System apps such as
                    // AirPlay also register software inputs of type TUNER and may sort first (seen on TCL G05).
                    // Among tuners of the same kind, skip an analog input when another is present.
                    // MediaTek names them AnalogInputService and TunerInputService; alphabetical order
                    // would pick the analog one, and Live TV then opens a dead ATV source.
                    boolean hw = info.getId().matches(".*/HW\\d+$");
                    boolean analog = info.getId().toLowerCase(Locale.ROOT).contains("analog");
                    boolean better = tunerId == null
                            || (hw && !tunerIsHw)
                            || (hw == tunerIsHw && tunerIsAnalog && !analog)
                            || (hw == tunerIsHw && analog == tunerIsAnalog
                                    && info.getId().compareTo(tunerId) < 0);
                    if (better) {
                        tunerId = info.getId();
                        tunerIsHw = hw;
                        tunerIsAnalog = analog;
                    }
                }
                // Inputs hidden in the TV's Settings > Inputs stay out of the menu too.
                if (!info.isPassthroughInput() || info.isHidden(ctx)) continue;
                // input_sources can leave out ports the board reports but the set does not have ("HW8=-").
                if (Integer.valueOf(-1).equals(mappedSource(ctx, info.getId()))) continue;
                // A CEC device's row is added with its port, below.
                if (info.getParentId() != null && inputIds.contains(info.getParentId())) continue;
                CharSequence l = info.loadLabel(ctx);
                String label = l == null ? info.getId() : l.toString();
                boolean hdmi = info.getType() == TvInputInfo.TYPE_HDMI;
                if (hdmi && !label.toUpperCase(Locale.ROOT).contains("HDMI")) label = "HDMI " + label;
                CharSequence custom = info.loadCustomLabel(ctx);
                boolean named = custom != null && custom.length() > 0 && !custom.toString().equals(label);
                if (!hdmi && !sawNonHdmi) {
                    counting.separator();
                    sawNonHdmi = true;
                }
                List<TvInputInfo> devices = cecDevices.get(info.getId());
                if (devices != null) {
                    // "Apple TV · HDMI 1": the device's own name (or the one given to it or to its port in
                    // Settings > Inputs), then the port. Opening the device's input also makes it the CEC
                    // active source, which wakes it.
                    for (TvInputInfo device : devices) {
                        CharSequence name = device.loadCustomLabel(ctx);
                        if (name == null || name.length() == 0) name = named ? custom : device.loadLabel(ctx);
                        String deviceLabel = name == null || name.length() == 0
                                ? label : name + " \u00B7 " + label;
                        final String deviceId = device.getId();
                        int state = hdmiStateBogus ? -1 : tim.getInputState(deviceId);
                        counting.row(R.drawable.ic_input, deviceLabel, state, () -> openInput(ctx, s, deviceId));
                    }
                    continue;
                }
                // The name given in Settings > Inputs (e.g. "MacBook Pro") goes first, the port after it.
                if (named) label = custom + " \u00B7 " + label;
                final String id = info.getId();
                // Analog AV jacks have no hotplug detection, and some TVs report them as always connected
                // (TCL Smart TV Pro G03 says "Connected" with nothing plugged in), so AV rows show no state.
                int state = !hdmi || hdmiStateBogus ? -1 : tim.getInputState(id);
                counting.row(hdmi ? R.drawable.ic_input : R.drawable.ic_av, label, state, () -> openInput(ctx, s, id));
            }
        }
        // Coocaa OS registers nothing with TvInputManager; com.skyworth.tv lists its sources instead.
        if (added[0] == 0) {
            for (CoocaaSources.Source source : coocaa) {
                int icon = "HDMI".equals(source.name) ? R.drawable.ic_input
                        : "VOD".equals(source.name) ? R.drawable.ic_livetv : R.drawable.ic_av;
                counting.row(icon, source.label, -1, () -> {
                    if (!CoocaaSources.open(ctx, source)) {
                        Toast.makeText(ctx, R.string.not_available, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
        // Nothing to list where there is no TvInputManager: the TV's own source panel switches inputs.
        if (added[0] == 0 && !s.sourcePanelService.isEmpty()) {
            counting.row(R.drawable.ic_input, ctx.getString(R.string.inputs), -1, () -> openSourcePanel(ctx, s));
        }
        Intent liveTv = liveTvIntent(ctx, s);
        if (liveTv != null) {
            counting.separator();
            if (tunerId != null) {
                // Tune that input only when the Live TV package itself handles the URI.
                // The unrestricted input player also resolves it (that is how HDMI opens), but on the
                // AIWA AI PONT SA that player stays black, and the Live TV package does not handle the
                // URI at all, which used to toast "Not available on this TV". Keep the leanback activity
                // then: it is the same path as the Live TV tile. Do not drop the package restriction.
                // An explicit tuner uses its channel collection (e.g. DVB-S rather than DVB-T/C).
                // Keep the legacy passthrough route for automatic selection: some OEM players need it.
                // If the configured input is absent, tunerId stays null and the app opens normally.
                boolean configured = !s.liveTvInputId.isEmpty();
                Intent tuned = new Intent(Intent.ACTION_VIEW)
                        .setDataAndType(configured ? TvContract.buildChannelsUriForInput(tunerId)
                                        : TvContract.buildChannelUriForPassthroughInput(tunerId),
                                configured ? TvContract.Channels.CONTENT_TYPE : TvContract.Channels.CONTENT_ITEM_TYPE)
                        .setPackage(s.liveTvPackage);
                if (tuned.resolveActivity(ctx.getPackageManager()) != null) liveTv = tuned;
            }
            final Intent open = liveTv;
            counting.row(R.drawable.ic_livetv, ctx.getString(R.string.live_tv), -1,
                    () -> start(ctx, open));
        }
        return added[0] > 0;
    }

    private static List<CoocaaSources.Source> coocaa(Context ctx, Settings s) {
        return s.coocaaSources ? CoocaaSources.list(ctx) : Collections.emptyList();
    }

    /** The Live TV app's own entry: its leanback activity, or the configured action when it has none. */
    static Intent liveTvIntent(Context ctx, Settings s) {
        if (s.liveTvPackage.isEmpty()) return null;
        Intent i = ctx.getPackageManager().getLeanbackLaunchIntentForPackage(s.liveTvPackage);
        if (i != null || s.liveTvAction.isEmpty()) return i;
        Intent byAction = new Intent(s.liveTvAction).setPackage(s.liveTvPackage);
        return ctx.getPackageManager().resolveActivity(byAction, 0) != null ? byAction : null;
    }

    /** The source number this input id maps to in `input_sources`, or null when it is not mapped. */
    static Integer mappedSource(Context ctx, String inputId) {
        if (inputId == null) return null;
        String hw = inputId.substring(inputId.lastIndexOf('/') + 1);
        for (String m : ctx.getResources().getStringArray(R.array.input_sources)) {
            int eq = m.indexOf('=');
            if (eq <= 0 || !m.substring(0, eq).trim().equals(hw)) continue;
            String v = m.substring(eq + 1).trim();
            if (v.equals("-")) return -1;
            try {
                return Integer.parseInt(v);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }

    /**
     * Switches to a passthrough input (HDMI, AV). An input mapped in `input_sources` is opened by sending
     * `input_action` with its source number as the int extra "input" (Xiaomi China firmware, whose tvplayer
     * answers com.xiaomi.mitv.tvplayer.EXTSRC_PLAY and nothing else). Otherwise the standard way is
     * ACTION_VIEW on its channel URI, which the Live TV app handles; where nothing takes that, the
     * configured `input_action` is sent with the same URI instead (XGIMI's HDMI player only answers
     * com.xgimi.action.hdmiPlayer). With `input_uri_scheme` set (YaOS: live-tv) the same URI goes out
     * with that scheme and no MIME type. A player guarded by a permission this build does not declare
     * throws SecurityException, which used to take Home down with it (YaOS before the manifest asked
     * for ACCESS_TV_SOURCE).
     */
    static void openInput(Context ctx, Settings s, String inputId) {
        Integer source = mappedSource(ctx, inputId);
        if (source != null && source >= 0 && !s.inputAction.isEmpty()) {
            try {
                start(ctx, new Intent(s.inputAction).putExtra("input", source.intValue()));
                return;
            } catch (ActivityNotFoundException | SecurityException e) {
                // fall through to the standard way
            }
        }
        Uri uri = TvContract.buildChannelUriForPassthroughInput(inputId);
        Intent view = s.inputUriScheme.isEmpty()
                ? new Intent(Intent.ACTION_VIEW).setDataAndType(uri, "vnd.android.cursor.item/channel")
                : new Intent(Intent.ACTION_VIEW, uri.buildUpon().scheme(s.inputUriScheme).build());
        try {
            start(ctx, view);
            return;
        } catch (ActivityNotFoundException | SecurityException e) {
            if (s.inputAction.isEmpty()) {
                Toast.makeText(ctx, R.string.not_available, Toast.LENGTH_SHORT).show();
                return;
            }
        }
        start(ctx, new Intent(s.inputAction).setDataAndType(uri, "vnd.android.cursor.item/channel"));
    }

    /**
     * The TV's own source-selection panel, for TVs that have no TvInputManager (TCL Android TV 9): a
     * service, or an activity on sets whose panel is a dialog (BYINTEK U4's QuickSourceActivity).
     */
    static void openSourcePanel(Context ctx, Settings s) {
        Intent i = new Intent(s.sourcePanelAction);
        ComponentName c = ComponentName.unflattenFromString(s.sourcePanelService);
        if (c != null) i.setComponent(c);
        int eq = s.sourcePanelExtra.indexOf('=');
        if (eq > 0) {
            try {
                i.putExtra(s.sourcePanelExtra.substring(0, eq).trim(),
                        Integer.parseInt(s.sourcePanelExtra.substring(eq + 1).trim()));
            } catch (NumberFormatException ignored) {
            }
        }
        try {
            if (ctx.getPackageManager().resolveActivity(i, 0) != null) {
                start(ctx, i);
                return;
            }
            ctx.startService(i);
        } catch (Exception e) {
            Toast.makeText(ctx, R.string.not_available, Toast.LENGTH_SHORT).show();
        }
    }

    private static void start(Context ctx, Intent intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (!(ctx instanceof android.app.Activity)) {
            try {
                ctx.startActivity(intent);
            } catch (ActivityNotFoundException | SecurityException e) {
                Toast.makeText(ctx, R.string.not_available, Toast.LENGTH_SHORT).show();
            }
            return;
        }
        ctx.startActivity(intent);
    }
}
