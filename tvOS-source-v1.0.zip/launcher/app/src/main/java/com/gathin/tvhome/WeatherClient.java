package com.gathin.tvhome;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.content.pm.PackageManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Small, optional forecast helper. Location or city is sent only when Weather is enabled. */
final class WeatherClient {
    static final String ACTION_UPDATED = "com.gathin.tvhome.WEATHER_UPDATED";
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static volatile long lastRequestAt;

    private WeatherClient() { }

    static String cachedLabel(Context context) {
        return prefs(context).getString(Config.WEATHER_CACHE_TEXT_KEY, "");
    }

    /** The cached reading alone, e.g. "24°C"; empty before the first forecast arrives. */
    static String cachedTemperature(Context context) {
        return prefs(context).getString(Config.WEATHER_CACHE_TEMP_KEY, "");
    }

    static String cachedPlace(Context context) {
        return prefs(context).getString(Config.WEATHER_CACHE_PLACE_KEY, "");
    }

    /** WMO weather code of the cached forecast, -1 while unknown. */
    static int cachedCode(Context context) {
        return prefs(context).getInt(Config.WEATHER_CACHE_CODE_KEY, -1);
    }

    /** The condition glyph for a WMO code: clear, partly cloudy, overcast, fog, rain, snow or storm. */
    static int iconFor(int code) {
        if (code == 0) return R.drawable.ic_weather_sun;
        if (code >= 1 && code <= 2) return R.drawable.ic_weather_partly;
        if (code == 3) return R.drawable.ic_weather_cloud;
        if (code == 45 || code == 48) return R.drawable.ic_weather_fog;
        if (code >= 71 && code <= 77) return R.drawable.ic_weather_snow;
        if (code == 85 || code == 86) return R.drawable.ic_weather_snow;
        if (code >= 95) return R.drawable.ic_weather_storm;
        if (code >= 51 && code <= 67) return R.drawable.ic_weather_rain;
        if (code >= 80 && code <= 82) return R.drawable.ic_weather_rain;
        return R.drawable.ic_weather_cloud;
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE);
    }

    static void refresh(Context context, boolean force) {
        Context app = context.getApplicationContext();
        SharedPreferences p = app.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE);
        if (!p.getBoolean(Config.WEATHER_ENABLED_KEY, false)) return;
        long now = System.currentTimeMillis();
        if (!force && (now - p.getLong(Config.WEATHER_CACHE_TIME_KEY, 0L) < 55_000L
                || now - lastRequestAt < 30_000L)) return;
        lastRequestAt = now;
        String mode = p.getString(Config.WEATHER_LOCATION_MODE_KEY, "city");
        String unit = p.getString(Config.WEATHER_UNIT_KEY, "c");
        if ("device".equals(mode)) {
            if (app.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && app.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
            refreshFromDeviceLocation(app, unit);
        } else {
            String city = p.getString(Config.WEATHER_CITY_KEY, "").trim();
            if (city.isEmpty()) return;
            WORKER.execute(() -> {
                try {
                    JSONObject place = get("https://geocoding-api.open-meteo.com/v1/search?name="
                            + Uri.encode(city) + "&count=1&language=en&format=json");
                    JSONArray results = place.optJSONArray("results");
                    if (results == null || results.length() == 0) return;
                    JSONObject location = results.getJSONObject(0);
                    String name = location.optString("name", city);
                    String country = location.optString("country", "");
                    double lat = location.getDouble("latitude");
                    double lon = location.getDouble("longitude");
                    publish(app, forecast(lat, lon, unit), name + (country.isEmpty() ? "" : ", " + country), unit);
                } catch (Exception ignored) { }
            });
        }
    }

    private static void refreshFromDeviceLocation(Context app, String unit) {
        MAIN.post(() -> {
            try {
                LocationManager manager = (LocationManager) app.getSystemService(Context.LOCATION_SERVICE);
                if (manager == null) return;
                Location cached = null;
                for (String provider : new String[]{LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER,
                        LocationManager.PASSIVE_PROVIDER}) {
                    try {
                        Location candidate = manager.getLastKnownLocation(provider);
                        if (candidate != null && (cached == null || candidate.getTime() > cached.getTime())) cached = candidate;
                    } catch (Exception ignored) { }
                }
                if (cached != null) {
                    final Location location = cached;
                    WORKER.execute(() -> fetchAndPublish(app, location, unit));
                    return;
                }
                String provider = null;
                for (String candidate : new String[]{LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER}) {
                    try { if (manager.isProviderEnabled(candidate)) { provider = candidate; break; } }
                    catch (Exception ignored) { }
                }
                if (provider == null) return;
                manager.getCurrentLocation(provider, null, app.getMainExecutor(), location -> {
                    if (location != null) WORKER.execute(() -> fetchAndPublish(app, location, unit));
                });
            } catch (SecurityException | IllegalArgumentException ignored) { }
        });
    }

    private static void fetchAndPublish(Context app, Location location, String unit) {
        try {
            publish(app, forecast(location.getLatitude(), location.getLongitude(), unit), "", unit);
        } catch (Exception ignored) { }
    }

    private static JSONObject forecast(double lat, double lon, String unit) throws Exception {
        String scale = "f".equals(unit) ? "fahrenheit" : "celsius";
        return get("https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon
                + "&current=temperature_2m,weather_code&temperature_unit=" + scale);
    }

    private static JSONObject get(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(10_000);
        connection.setReadTimeout(10_000);
        connection.setRequestProperty("Accept", "application/json");
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) body.append(line);
            return new JSONObject(body.toString());
        } finally { connection.disconnect(); }
    }

    private static void publish(Context app, JSONObject response, String place, String unit) {
        JSONObject current = response.optJSONObject("current");
        JSONObject units = response.optJSONObject("current_units");
        if (current == null) return;
        String degree = units == null ? ("f".equals(unit) ? "°F" : "°C")
                : units.optString("temperature_2m", "°C");
        int code = current.optInt("weather_code", -1);
        String label = Math.round(current.optDouble("temperature_2m")) + degree + " · " + condition(code);
        app.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE).edit()
                .putString(Config.WEATHER_CACHE_TEXT_KEY, label)
                .putString(Config.WEATHER_CACHE_TEMP_KEY, Math.round(current.optDouble("temperature_2m")) + degree)
                .putInt(Config.WEATHER_CACHE_CODE_KEY, code)
                .putString(Config.WEATHER_CACHE_PLACE_KEY, place)
                .putLong(Config.WEATHER_CACHE_TIME_KEY, System.currentTimeMillis()).apply();
        app.sendBroadcast(new Intent(ACTION_UPDATED).setPackage(app.getPackageName()));
    }

    private static String condition(int code) {
        if (code == 0) return "Clear";
        if (code <= 3 && code >= 1) return "Partly cloudy";
        if (code == 45 || code == 48) return "Foggy";
        if (code >= 51 && code <= 67) return "Drizzle";
        if (code >= 71 && code <= 77) return "Snow";
        if (code >= 80 && code <= 82) return "Showers";
        if (code >= 85 && code <= 86) return "Snow showers";
        if (code >= 95) return "Thunderstorms";
        return "Weather";
    }
}
