package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadata;

import java.io.File;
import java.io.FileOutputStream;

/** Small PNG of the current track's artwork, shared by Home and the Glance. */
final class NowPlayingArt {
    private static final int MAX_PX = 256;

    private NowPlayingArt() { }

    static File file(Context context) {
        return new File(context.getCacheDir(), Config.NOW_PLAYING_ART_FILE);
    }

    /** Whether the metadata carries any bitmap, before paying for the scale and the write. */
    static boolean hasBitmap(MediaMetadata metadata) {
        if (metadata == null) return false;
        return metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) != null
                || metadata.getBitmap(MediaMetadata.METADATA_KEY_ART) != null
                || metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON) != null;
    }

    static boolean exists(Context context) {
        return file(context).isFile();
    }

    /** Saves the session's best artwork; false when the metadata has none or the write fails. */
    static boolean save(Context context, MediaMetadata metadata) {
        if (metadata == null) return false;
        Bitmap source = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
        if (source == null) source = metadata.getBitmap(MediaMetadata.METADATA_KEY_ART);
        if (source == null) source = metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
        if (source == null) return false;
        Bitmap scaled = source;
        try {
            int longest = Math.max(source.getWidth(), source.getHeight());
            if (longest > MAX_PX) {
                float scale = MAX_PX / (float) longest;
                scaled = Bitmap.createScaledBitmap(source,
                        Math.max(1, Math.round(source.getWidth() * scale)),
                        Math.max(1, Math.round(source.getHeight() * scale)), true);
            }
            File target = file(context);
            File temp = new File(target.getPath() + ".tmp");
            try (FileOutputStream out = new FileOutputStream(temp)) {
                if (!scaled.compress(Bitmap.CompressFormat.PNG, 100, out)) return false;
            }
            if (!temp.renameTo(target)) {
                if (!target.delete() || !temp.renameTo(target)) return false;
            }
            return true;
        } catch (Exception | OutOfMemoryError ignored) {
            return false;
        } finally {
            if (scaled != source) scaled.recycle();   // the session still owns the metadata bitmap
        }
    }

    /** The cached artwork, or null when the current track has none. */
    static Bitmap load(Context context) {
        File file = file(context);
        if (!file.isFile()) return null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getPath(), bounds);
            int sample = 1;
            while (bounds.outWidth > 0 && bounds.outHeight > 0
                    && Math.max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_PX) sample *= 2;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            return BitmapFactory.decodeFile(file.getPath(), options);
        } catch (Exception | OutOfMemoryError ignored) {
            return null;
        }
    }

    static void delete(Context context) {
        File file = file(context);
        if (file.exists()) //noinspection ResultOfMethodCallIgnored
            file.delete();
    }
}
