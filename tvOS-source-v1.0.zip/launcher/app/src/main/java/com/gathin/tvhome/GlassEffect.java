package com.gathin.tvhome;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;

/**
 * Frost depth for the glass surfaces over the wallpaper. Android has no per-view backdrop blur (the only
 * platform blur, Window.setBackgroundBlurRadius, covers the whole window behind Home), so the level deepens
 * the translucent frost instead: more of the smoked glass and its white veil, which is what reads as thicker
 * glass on a TV. Applying the same level to the card, the weather pill and Glance keeps them consistent.
 */
final class GlassEffect {
    static final int DEFAULT_LEVEL = 2;
    static final int LEVELS = 5;
    private static final int[] FROST_ALPHA = {150, 185, 215, 235, 255};
    private static final int[] LABELS = {R.string.glass_blur_off, R.string.glass_blur_soft,
            R.string.glass_blur_medium, R.string.glass_blur_strong, R.string.glass_blur_max};

    private GlassEffect() { }

    static int level(Context context) {
        return clamp(context.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE)
                .getInt(Config.GLASS_BLUR_KEY, DEFAULT_LEVEL));
    }

    static int frostAlpha(int level) {
        return FROST_ALPHA[clamp(level)];
    }

    static int labelRes(int level) {
        return LABELS[clamp(level)];
    }

    static void apply(View view, int level) {
        if (view == null) return;
        Drawable background = view.getBackground();
        if (background == null) return;
        background.mutate().setAlpha(FROST_ALPHA[clamp(level)]);
        view.invalidate();
    }

    private static int clamp(int level) {
        return Math.max(0, Math.min(level, LEVELS - 1));
    }
}
