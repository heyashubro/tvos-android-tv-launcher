package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.widget.ImageView;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Plays clear, indexed local photos behind the Glance clock. */
final class GlanceScene {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private final Context context;
    private final ImageView wallpaper;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final int width;
    private final int height;
    private final long slideMs;
    private final Runnable advance = this::showNext;
    private List<WallpaperGalleryDialog.Image> images = new ArrayList<>();
    private int index;
    private Bitmap current;
    private boolean started;
    private boolean loading;
    private boolean closed;

    GlanceScene(Context context, ImageView wallpaper) {
        this.context = context.getApplicationContext();
        this.wallpaper = wallpaper;
        width = context.getResources().getDisplayMetrics().widthPixels;
        height = context.getResources().getDisplayMetrics().heightPixels;
        int seconds = context.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE)
                .getInt(Config.GLANCE_SLIDE_SECONDS_KEY, 20);
        slideMs = Math.max(10, Math.min(60, seconds)) * 1_000L;
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
    }

    void start() {
        if (started || closed) return;
        started = true;
        worker.execute(() -> {
            List<WallpaperGalleryDialog.Image> found = WallpaperGalleryDialog.query(context);
            if (found.isEmpty()) found = fallbackImages();
            images = found;
            loadAt(0);
        });
    }

    private List<WallpaperGalleryDialog.Image> fallbackImages() {
        List<WallpaperGalleryDialog.Image> fallback = new ArrayList<>();
        Config config = Config.load(context);
        for (File file : config.wallpapers) {
            if (file != null && file.isFile()) fallback.add(new WallpaperGalleryDialog.Image(Uri.fromFile(file), file.getName()));
        }
        File selected = new File(context.getFilesDir(), Config.USER_WALLPAPER_FILE);
        if (selected.isFile() && fallback.isEmpty()) {
            fallback.add(new WallpaperGalleryDialog.Image(Uri.fromFile(selected),
                    context.getString(R.string.wallpaper_custom)));
        }
        return fallback;
    }

    private void showNext() {
        if (!started || closed || loading || images.size() < 2) return;
        loadAt((index + 1) % images.size());
    }

    private void loadAt(int position) {
        if (closed || images.isEmpty()) {
            scheduleAdvance();
            return;
        }
        loading = true;
        WallpaperGalleryDialog.Image item = images.get(position);
        Bitmap bitmap = decode(item.uri);
        MAIN.post(() -> {
            loading = false;
            if (closed || !started) {
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                return;
            }
            if (bitmap != null) {
                index = position;
                Bitmap previous = current;
                current = bitmap;
                wallpaper.animate().cancel();
                wallpaper.setAlpha(0f);
                wallpaper.setImageBitmap(bitmap);
                wallpaper.animate().alpha(1f).setDuration(900).start();
                if (previous != null && previous != bitmap) wallpaper.postDelayed(() -> {
                    if (!previous.isRecycled()) previous.recycle();
                }, 1_000L);
            } else if (images.size() > 1) {
                index = position;
            }
            scheduleAdvance();
        });
    }

    private void scheduleAdvance() {
        MAIN.removeCallbacks(advance);
        if (started && images.size() > 1) MAIN.postDelayed(advance, slideMs);
    }

    private Bitmap decode(Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream probe = context.getContentResolver().openInputStream(uri)) {
                if (probe == null) return null;
                BitmapFactory.decodeStream(probe, null, bounds);
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
            int sample = WallpaperSize.sampleSize(bounds.outWidth, bounds.outHeight, width, height);
            if (!WallpaperSize.accepted(bounds.outWidth / sample, bounds.outHeight / sample)) return null;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            try (InputStream input = context.getContentResolver().openInputStream(uri)) {
                return input == null ? null : BitmapFactory.decodeStream(input, null, options);
            }
        } catch (Exception | OutOfMemoryError ignored) {
            return null;
        }
    }

    void stop() {
        started = false;
        MAIN.removeCallbacks(advance);
        wallpaper.animate().cancel();
    }

    void close() {
        stop();
        closed = true;
        worker.shutdownNow();
        if (current != null && !current.isRecycled()) current.recycle();
        current = null;
    }
}
