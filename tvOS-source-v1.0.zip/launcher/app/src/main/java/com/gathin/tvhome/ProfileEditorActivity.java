package com.gathin.tvhome;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** Name, avatar and delete for one profile. Also used by the setup assistant for its profile step. */
public final class ProfileEditorActivity extends LauncherActivity {

    static final String EXTRA_PROFILE_ID = "profile_id";

    private final List<ImageView> avatarViews = new ArrayList<>();
    private List<Integer> avatarChoices;
    private ProfileStore.Profile profile;
    private EditText nameField;
    private int avatar;
    private boolean reducedMotion;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_profile_editor);
        reducedMotion = Config.load(this).reducedMotion;
        if (ProfileStore.isGuest(this)) {
            Toast.makeText(this, R.string.profile_guest_locked, Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        ProfileStore.syncAccount(this);
        String email = AccountIdentity.email(this);
        String id = getIntent().getStringExtra(EXTRA_PROFILE_ID);
        for (ProfileStore.Profile candidate : ProfileStore.list(this)) {
            if (candidate.id.equals(id)) profile = candidate;
        }
        nameField = findViewById(R.id.profileName);
        ((TextView) findViewById(R.id.profileEditorTitle))
                .setText(profile == null ? R.string.profile_new : R.string.profile_edit);
        String autoName = AccountIdentity.name(email);
        nameField.setText(profile == null ? (autoName == null ? "" : autoName) : profile.name);
        avatar = profile == null ? (email == null ? 0 : ProfileStore.AVATAR_ACCOUNT) : profile.avatar;
        TextView account = findViewById(R.id.profileAccount);
        if (email == null) {
            account.setVisibility(View.GONE);
        } else {
            account.setVisibility(View.VISIBLE);
            account.setText(getString(R.string.profile_signed_in, email));
        }
        nameField.setShowSoftInputOnFocus(false);
        nameField.setOnClickListener(v -> showKeyboard());
        nameField.setOnFocusChangeListener((view, focused) -> {
            if (focused) showKeyboard();
            else hideKeyboard();
        });
        nameField.setOnEditorActionListener((view, actionId, event) -> {
            hideKeyboard();
            if (!avatarViews.isEmpty()) avatarViews.get(Math.max(0, avatarChoices.indexOf(avatar))).requestFocus();
            return true;
        });

        TextView delete = findViewById(R.id.profileDelete);
        boolean deletable = profile != null && !ProfileStore.DEFAULT_ID.equals(profile.id)
                && ProfileStore.list(this).size() > 1;
        delete.setVisibility(deletable ? View.VISIBLE : View.GONE);
        delete.setOnClickListener(v -> confirmDelete());

        buildAvatars();
        findViewById(R.id.profileSave).setOnClickListener(v -> save());
        View focus = avatarViews.get(Math.max(0, avatarChoices.indexOf(avatar)));
        focus.post(() -> {
            focus.requestFocus();
            hideKeyboard();
        });
    }

    private void buildAvatars() {
        GridLayout grid = findViewById(R.id.avatarGrid);
        avatarChoices = ProfileStore.avatarChoices(this);
        for (int i = 0; i < avatarChoices.size(); i++) {
            int index = avatarChoices.get(i);
            ImageView view = new ImageView(this);
            view.setImageDrawable(index == ProfileStore.AVATAR_ACCOUNT
                    ? AccountIdentity.avatar(this) : getDrawable(ProfileStore.avatarRes(index)));
            view.setScaleType(ImageView.ScaleType.CENTER_CROP);
            view.setBackgroundResource(R.drawable.profile_avatar_choice);
            view.setForeground(getDrawable(R.drawable.profile_avatar_focus));
            view.setClipToOutline(true);
            view.setFocusable(true);
            view.setClickable(true);
            view.setContentDescription(index == ProfileStore.AVATAR_ACCOUNT
                    ? getString(R.string.profile_account_avatar)
                    : getString(R.string.profile_choose_avatar) + " " + (index + 1));
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = dp(82);
            params.height = dp(82);
            params.setMargins(dp(6), dp(6), dp(6), dp(6));
            view.setLayoutParams(params);
            view.setOnClickListener(v -> select(index));
            view.setOnFocusChangeListener((v, focused) -> {
                v.animate().scaleX(focused ? 1.07f : 1f).scaleY(focused ? 1.07f : 1f)
                        .setDuration(reducedMotion ? Motion.REDUCED_MS : 150).start();
            });
            grid.addView(view);
            avatarViews.add(view);
        }
        select(avatar);
    }

    private void select(int index) {
        avatar = index;
        for (int i = 0; i < avatarViews.size(); i++) avatarViews.get(i).setActivated(avatarChoices.get(i) == index);
    }

    private void save() {
        String name = nameField.getText().toString();
        if (profile == null) {
            ProfileStore.Profile added = ProfileStore.add(this, name, avatar);
            ProfileStore.setActive(this, added.id);
        } else {
            profile.name = name;
            profile.avatar = avatar;
            ProfileStore.save(this, profile);
        }
        setResult(RESULT_OK);
        finish();
    }

    private void confirmDelete() {
        if (profile == null) return;
        new AlertDialog.Builder(this)
                .setTitle(R.string.profile_delete)
                .setMessage(getString(R.string.profile_delete_body, profile.name))
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    ProfileStore.remove(this, profile.id);
                    setResult(RESULT_OK);
                    finish();
                })
                .show();
    }

    private void showKeyboard() {
        nameField.requestFocus();
        InputMethodManager keyboard = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (keyboard != null) keyboard.showSoftInput(nameField, InputMethodManager.SHOW_IMPLICIT);
    }

    private void hideKeyboard() {
        InputMethodManager keyboard = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(nameField.getWindowToken(), 0);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
