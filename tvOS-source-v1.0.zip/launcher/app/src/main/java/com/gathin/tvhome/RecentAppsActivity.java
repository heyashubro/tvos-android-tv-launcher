package com.gathin.tvhome;

import android.app.ActivityManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.format.Formatter;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * The full-page recent apps screen behind Back: the apps this Home opened, a live memory pill (actual / used /
 * free), and Clear, which empties the list and asks Android to reclaim those apps' background processes. Best
 * effort only: a foreground app or one with a foreground service stays up.
 */
public final class RecentAppsActivity extends LauncherActivity {
    private static final int CARD_WIDTH_DP = 156;
    private static final int CARD_GAP_DP = 12;
    private LinearLayout row;
    private View empty;
    private View clear;
    private View panel;
    private boolean reducedMotion;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected int themeRes() {
        return R.style.Theme_Panel;
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_recent_apps);
        reducedMotion = Config.load(this).reducedMotion;
        row = findViewById(R.id.recentsRow);
        empty = findViewById(R.id.recentsEmpty);
        clear = findViewById(R.id.recentsClear);
        panel = findViewById(R.id.recentsPanel);
        panel.setFocusable(true);
        findViewById(R.id.recentsScrim).setOnClickListener(v -> finish());
        clear.setOnClickListener(v -> clearAll());
        setUpBackdrop();
        updateMemory();
        render();
        playEntrance();
    }

    private void setUpBackdrop() {
        Bitmap backdrop = ControlCenterBackdrop.current();
        if (backdrop != null) {
            ImageView image = findViewById(R.id.recentsBackdrop);
            image.setImageBitmap(backdrop);
            image.setVisibility(View.VISIBLE);
        }
        findViewById(R.id.recentsShade).setBackgroundColor(0x99000000);
    }

    private void playEntrance() {
        if (reducedMotion) return;
        panel.setAlpha(0f);
        panel.setTranslationY(dp(14));
        panel.animate().alpha(1f).translationY(0f)
                .setDuration(200).setInterpolator(new DecelerateInterpolator()).start();
    }

    /** Reads the RAM figure the TV reports: actual total, used (total minus available) and free. */
    private void updateMemory() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        manager.getMemoryInfo(info);
        long total = info.totalMem;
        long free = info.availMem;
        long used = Math.max(0, total - free);
        int percent = total > 0 ? Math.round(used * 100f / total) : 0;
        String totalText = size(total);
        String usedText = size(used);
        String freeText = size(free);
        ((TextView) findViewById(R.id.recentsMemoryPercent))
                .setText(getString(R.string.recents_memory_percent, percent));
        ((TextView) findViewById(R.id.recentsMemoryUsed))
                .setText(getString(R.string.recents_memory_compact, usedText, freeText));
        findViewById(R.id.recentsMemory).setContentDescription(getString(R.string.recents_memory_title)
                + ": " + getString(R.string.recents_memory_percent, percent) + ", "
                + getString(R.string.recents_memory_used, usedText) + ", "
                + getString(R.string.recents_memory_free, freeText) + ", "
                + getString(R.string.recents_memory_total, totalText));
    }

    private void render() {
        row.removeAllViews();
        PackageManager pm = getPackageManager();
        List<RecentsStore.Entry> entries = RecentsStore.items(this);
        int shown = 0;
        for (RecentsStore.Entry entry : entries) {
            CharSequence label;
            Drawable icon;
            try {
                label = pm.getApplicationLabel(pm.getApplicationInfo(entry.pkg, 0));
                icon = pm.getApplicationIcon(entry.pkg);
            } catch (PackageManager.NameNotFoundException ignored) {
                continue;   // uninstalled since Home opened it
            }
            View card = getLayoutInflater().inflate(R.layout.item_recent_app, row, false);
            ((ImageView) card.findViewById(R.id.recentIcon)).setImageDrawable(icon);
            ((TextView) card.findViewById(R.id.recentName)).setText(label);
            ((TextView) card.findViewById(R.id.recentWhen)).setText(LastOpened.describe(this, entry.at));
            card.setContentDescription(label + ", " + LastOpened.describe(this, entry.at));
            card.setOnClickListener(v -> open(entry.pkg));
            card.setOnFocusChangeListener((v, focused) -> {
                v.animate().scaleX(focused ? 1.06f : 1f).scaleY(focused ? 1.06f : 1f)
                        .setDuration(reducedMotion ? Motion.REDUCED_MS : 160).start();
                v.setTranslationZ(focused ? dp(6) : 0);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    dp(CARD_WIDTH_DP), LinearLayout.LayoutParams.WRAP_CONTENT);
            if (shown > 0) lp.setMarginStart(dp(CARD_GAP_DP));
            row.addView(card, lp);
            shown++;
        }
        boolean hasApps = shown > 0;
        empty.setVisibility(hasApps ? View.GONE : View.VISIBLE);
        findViewById(R.id.recentsScroll).setVisibility(hasApps ? View.VISIBLE : View.GONE);
        clear.setVisibility(hasApps ? View.VISIBLE : View.GONE);
        setUpKeys(shown);
        View focus = hasApps ? row.getChildAt(0) : panel;
        focus.post(focus::requestFocus);
    }

    /** Explicit walking: sideways along the row, Down to Clear, Up back to the row. */
    private void setUpKeys(int count) {
        for (int i = 0; i < count; i++) {
            final int index = i;
            row.getChildAt(i).setOnKeyListener((v, keyCode, event) -> {
                if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
                if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                    if (index == 0) return true;
                    row.getChildAt(index - 1).requestFocus();
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    if (index >= count - 1) return true;
                    row.getChildAt(index + 1).requestFocus();
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                    clear.requestFocus();
                    return true;
                }
                return keyCode == KeyEvent.KEYCODE_DPAD_UP;
            });
        }
        clear.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP && count > 0) {
                row.getChildAt(count - 1).requestFocus();
                return true;
            }
            return keyCode == KeyEvent.KEYCODE_DPAD_DOWN
                    || keyCode == KeyEvent.KEYCODE_DPAD_LEFT
                    || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
                    || keyCode == KeyEvent.KEYCODE_DPAD_UP;
        });
    }

    private void open(String pkg) {
        PackageManager pm = getPackageManager();
        CharSequence label = pkg;
        try {
            label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0));
        } catch (PackageManager.NameNotFoundException ignored) {
        }
        if (ParentalControls.gate(this, pkg, label, () -> start(pkg))) return;
        start(pkg);
    }

    /** The intent itself, once the parental gate has passed. */
    private void start(String pkg) {
        PackageManager pm = getPackageManager();
        Intent intent = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (intent == null) intent = pm.getLaunchIntentForPackage(pkg);
        if (intent == null) {
            Toast.makeText(this, getString(R.string.cant_open, pkg), Toast.LENGTH_SHORT).show();
            return;
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        RecentsStore.record(this, pkg);
        try {
            startActivity(intent);
            finish();
        } catch (Exception ignored) {
            Toast.makeText(this, getString(R.string.cant_open, pkg), Toast.LENGTH_SHORT).show();
        }
    }

    /** Clears the list and asks Android to reclaim each app's background process; reports the RAM recovered. */
    private void clearAll() {
        List<RecentsStore.Entry> entries = RecentsStore.items(this);
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo before = new ActivityManager.MemoryInfo();
        manager.getMemoryInfo(before);
        for (RecentsStore.Entry entry : entries) {
            try {
                manager.killBackgroundProcesses(entry.pkg);
            } catch (RuntimeException ignored) {
                // A protected app: skip it and keep clearing the rest.
            }
        }
        RecentsStore.clear(this);
        render();
        updateMemory();
        handler.postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            updateMemory();
            ActivityManager.MemoryInfo after = new ActivityManager.MemoryInfo();
            manager.getMemoryInfo(after);
            long freed = after.availMem - before.availMem;
            String message = freed > 0
                    ? getString(R.string.recents_freed, size(freed))
                    : getString(R.string.recents_cleared, size(after.availMem));
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        }, 900L);
    }

    private String size(long bytes) {
        return Formatter.formatShortFileSize(this, Math.max(0, bytes));
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
