package com.gathin.tvhome;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * The liquid-glass Control Center in the top-right corner: a fixed cluster of crystal pills over a dimmed,
 * blurred Home, with no background of its own. The header holds the clock with its date beside it and the round
 * Settings and profile buttons; page one is Do Not Disturb, Wi-Fi and Inputs, page two is the Now Bar (Now
 * Playing, the weather bar and the score board). Down from the tiles opens the Now Bar, Up or Back returns, the
 * dots say which page is up, and Inputs opens as a folder over the page it was pressed from.
 */
public final class ControlCenterActivity extends LauncherActivity {

    private static final String STATE_FOCUS = "control_center_focus";
    private static final String STATE_NOW_BAR = "control_center_now_bar";
    private static final int REQUEST_WIFI_NAME = 51;
    /** A tile's Down target that opens the Now Bar slide instead of another view. */
    private static final int NOW_BAR = -1;
    /** A tile's Up target that returns from the Now Bar slide to the control tiles. */
    private static final int CONTROLS = -2;
    /** One prompt per app run: the network name needs precise location, and nagging is worse than "Connected". */
    private static boolean wifiNameAsked;

    private boolean reducedMotion;
    private boolean weatherRegistered;
    private boolean sportsRegistered;
    private boolean nowPlayingRegistered;
    private int[] settingsKeycodes = new int[0];
    private InputMenu.Settings inputSettings;
    private Bitmap artBitmap;
    /** Artwork version on screen, -1 for none yet. */
    private int artShown = -1;
    private boolean showingNowBar;
    private boolean inputsOpen;
    /** The tile to focus when the Now Bar slide returns to the control tiles. */
    private int controlsFocus = R.id.tileSleep;
    private final BroadcastReceiver weatherReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            updateWeatherHeader();
        }
    };
    private final BroadcastReceiver sportsReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            updateScoreBoard();
        }
    };
    private final BroadcastReceiver nowPlayingReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            updateNowPlayingTile();
        }
    };
    private final Handler handler = new Handler(Looper.getMainLooper());
    /** The score board follows the live feed while the panel is up; Home's ticker is paused behind it. */
    private final Runnable sportsTick = new Runnable() {
        @Override public void run() {
            SportsRepository.refresh(ControlCenterActivity.this, false);
            updateScoreBoard();
            handler.postDelayed(this, 1_000L);
        }
    };

    @Override protected int themeRes() {
        return R.style.Theme_Panel;
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_control_center);
        Config config = Config.load(this);
        reducedMotion = config.reducedMotion;
        settingsKeycodes = config.settingsKeycodes;
        inputSettings = InputMenu.Settings.of(config);
        setUpBackdrop();
        setUpHeader();
        setUpTiles();
        applyGlass();
        registerUpdates();
        // The capsule opens on a reading: show the cache right away, then let the receiver replace it.
        WeatherClient.refresh(this, true);
        askForWifiName();
        boolean nowBar = state != null && state.getBoolean(STATE_NOW_BAR, false);
        setPage(nowBar, nowBar);
        if (!nowBar) {
            int focusId = state == null ? R.id.tileSleep : state.getInt(STATE_FOCUS, R.id.tileSleep);
            View focus = findViewById(focusId);
            if (focus == null) focus = findViewById(R.id.tileSleep);
            focus.post(focus::requestFocus);
        }
        playEntrance();
        overridePendingTransition(android.R.anim.fade_in, 0);
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putBoolean(STATE_NOW_BAR, showingNowBar);
        View focus = getCurrentFocus();
        if (focus != null && focus.getId() != View.NO_ID && !showingNowBar) {
            out.putInt(STATE_FOCUS, focus.getId());
        }
    }

    /** Settings pressed again while the panel is up. */
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        finish();
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(sportsTick);
        handler.postDelayed(sportsTick, 1_000L);
    }

    @Override protected void onPause() {
        super.onPause();
        handler.removeCallbacks(sportsTick);
        unregisterUpdates();
        if (!isFinishing()) finish();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        for (int code : settingsKeycodes) {
            if (event.getKeyCode() != code) continue;
            if (event.getAction() == KeyEvent.ACTION_UP && !event.isCanceled()) finish();
            return true;
        }
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (event.getAction() == KeyEvent.ACTION_UP && !event.isCanceled()) {
                if (inputsOpen) {
                    showInputs(false);
                } else if (showingNowBar) {
                    setPage(false, true);
                } else {
                    finish();
                }
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_WIFI_NAME) return;
        setTileStatus(R.id.tileWifi, wifiStatus());
    }

    private void setUpBackdrop() {
        Bitmap backdrop = ControlCenterBackdrop.current();
        if (backdrop != null) {
            ImageView image = findViewById(R.id.ccBackdrop);
            image.setImageBitmap(backdrop);
            image.setVisibility(View.VISIBLE);
        } else {
            findViewById(R.id.ccRoot).setBackgroundResource(R.drawable.control_center_gradient);
        }
        findViewById(R.id.ccScrim).setBackgroundColor(0x73000000);
    }

    private void setUpHeader() {
        ProfileStore.Profile profile = ProfileStore.active(this);
        ImageView avatar = findViewById(R.id.ccAvatar);
        avatar.setImageDrawable(profile.avatarDrawable(this));
        avatar.setContentDescription(profile.name);
        avatar.setOnClickListener(v -> openProfiles());
        scaleOnFocus(avatar, 1.08f);
        View settings = findViewById(R.id.ccSettings);
        settings.setOnClickListener(v -> openLauncherSettings());
        scaleOnFocus(settings, 1.08f);
        View weather = findViewById(R.id.ccWeather);
        weather.setOnClickListener(v -> {
            if (!getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE)
                    .getBoolean(Config.WEATHER_ENABLED_KEY, false)) {
                openLauncherSettings();
            } else {
                WeatherClient.refresh(this, true);
                updateWeatherHeader();
            }
        });
        scaleOnFocus(weather, 1.04f);
    }

    private void setUpTiles() {
        SharedPreferences choices = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        boolean glance = choices.getBoolean(Config.GLANCE_ENABLED_KEY, false);

        setTile(R.id.tileSleep, R.drawable.ic_dnd, getString(R.string.sleep_now),
                getString(glance ? R.string.settings_glance : R.string.dream_name), () -> {
                    startActivity(new Intent(this, glance ? GlanceActivity.class : ClockActivity.class));
                    finish();
                });
        setTile(R.id.tileWifi, R.drawable.ic_wifi, getString(R.string.wifi), wifiStatus(),
                () -> openSystem(Settings.ACTION_WIFI_SETTINGS));
        setTile(R.id.tileDnd, R.drawable.ic_moon, getString(R.string.do_not_disturb),
                getString(R.string.tap_to_manage), () -> openSystem(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
        setTile(R.id.tileInputs, R.drawable.ic_remote, getString(R.string.inputs),
                getString(R.string.cc_inputs_hint), () -> showInputs(true));
        setTile(R.id.tileGlance, R.drawable.ic_weather_sun, getString(R.string.settings_glance),
                getString(glance ? R.string.on : R.string.off), () -> {
                    startActivity(new Intent(this, glance ? GlanceActivity.class : ClockActivity.class));
                    finish();
                });

        findViewById(R.id.ccRecent).setOnClickListener(v -> {
            startActivity(new Intent(this, RecentAppsActivity.class));
            finish();
        });
        findViewById(R.id.ccAccessibility).setOnClickListener(v -> openSystem(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        findViewById(R.id.ccRemote).setOnClickListener(v -> showInputs(true));
        findViewById(R.id.ccHome).setOnClickListener(v -> finish());

        View nowPlaying = findViewById(R.id.tileNowPlaying);
        nowPlaying.setOnClickListener(v -> NowPlayingListener.sendCommand(this, NowPlayingListener.ACTION_TOGGLE));
        nowPlaying.findViewById(R.id.ccNpPrevious).setOnClickListener(v ->
                NowPlayingListener.sendCommand(this, NowPlayingListener.ACTION_PREVIOUS));
        nowPlaying.findViewById(R.id.ccNpNext).setOnClickListener(v ->
                NowPlayingListener.sendCommand(this, NowPlayingListener.ACTION_NEXT));
        nowPlaying.findViewById(R.id.ccNpToggle).setOnClickListener(v ->
                NowPlayingListener.sendCommand(this, NowPlayingListener.ACTION_TOGGLE));

        View scores = findViewById(R.id.ccScores);
        scores.setOnClickListener(v -> {
            if (!SportsRepository.enabled(this)) {
                openSportsSettings();
                return;
            }
            SportsRepository.refresh(this, true);
            updateScoreBoard();
        });

        scaleOnFocus(findViewById(R.id.tileSleep), 1.06f);
        scaleOnFocus(findViewById(R.id.tileWifi), 1.06f);
        scaleOnFocus(findViewById(R.id.tileDnd), 1.06f);
        scaleOnFocus(findViewById(R.id.tileInputs), 1.03f);
        scaleOnFocus(findViewById(R.id.tileGlance), 1.03f);
        scaleOnFocus(findViewById(R.id.ccRecent), 1.08f);
        scaleOnFocus(findViewById(R.id.ccAccessibility), 1.08f);
        scaleOnFocus(findViewById(R.id.ccRemote), 1.08f);
        scaleOnFocus(findViewById(R.id.ccHome), 1.08f);
        scaleOnFocus(findViewById(R.id.ccScores), 1.02f);
        scaleOnFocus(nowPlaying, 1.03f);

        setUpKeys();
        updateWeatherHeader();
        updateNowPlayingTile();
        updateScoreBoard();
    }

    /** Appearance, Background blur: the frost level deepens each pill's own glass. */
    private void applyGlass() {
        int level = GlassEffect.level(this);
        int[] glass = {R.id.tileSleep, R.id.tileWifi, R.id.tileDnd, R.id.tileInputs, R.id.tileGlance,
                R.id.ccRecent, R.id.ccAccessibility, R.id.ccRemote, R.id.ccHome, R.id.ccWeather,
                R.id.tileNowPlaying, R.id.ccScores, R.id.ccSettings, R.id.ccAvatar};
        for (int id : glass) GlassEffect.apply(findViewById(id), level);
    }

    private void setUpKeys() {
        // The visual grid, spelled out: automatic focus search wanders between the pills.
        keys(R.id.ccSettings, 0, R.id.tileSleep, 0, R.id.ccAvatar);
        keys(R.id.ccAvatar, 0, R.id.tileWifi, R.id.ccSettings, 0);
        keys(R.id.ccWeather, 0, R.id.tileSleep, R.id.ccSettings, R.id.ccSettings);
        keys(R.id.tileSleep, R.id.ccSettings, R.id.tileInputs, 0, R.id.tileWifi);
        keys(R.id.tileWifi, R.id.ccAvatar, R.id.tileInputs, R.id.tileDnd, R.id.tileSleep);
        keys(R.id.tileDnd, R.id.ccAvatar, R.id.tileInputs, R.id.tileWifi, R.id.tileSleep);
        keys(R.id.tileInputs, R.id.tileSleep, R.id.ccRecent, 0, R.id.tileGlance);
        keys(R.id.tileGlance, R.id.tileWifi, R.id.ccRecent, R.id.tileInputs, R.id.tileDnd);
        keys(R.id.ccRecent, R.id.tileInputs, NOW_BAR, 0, R.id.ccAccessibility);
        keys(R.id.ccAccessibility, R.id.tileInputs, NOW_BAR, R.id.ccRecent, R.id.ccRemote);
        keys(R.id.ccRemote, R.id.tileInputs, NOW_BAR, R.id.ccAccessibility, R.id.ccHome);
        keys(R.id.ccHome, R.id.tileInputs, NOW_BAR, R.id.ccRemote, 0);
        keys(R.id.ccScores, R.id.tileNowPlaying, 0, 0, 0);
        // Up from the top of the Now Bar returns to the control tiles.
        keys(R.id.tileNowPlaying, CONTROLS, R.id.ccScores, 0, 0);
    }

    private void keys(int id, int up, int down, int left, int right) {
        View view = findViewById(id);
        if (view == null) return;
        view.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (id == R.id.tileNowPlaying && keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                NowPlayingListener.sendCommand(this, NowPlayingListener.ACTION_PREVIOUS);
                return true;
            }
            if (id == R.id.tileNowPlaying && keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                NowPlayingListener.sendCommand(this, NowPlayingListener.ACTION_NEXT);
                return true;
            }
            int target;
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP) target = up;
            else if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) target = down;
            else if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) target = left;
            else if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) target = right;
            else return false;
            if (target == NOW_BAR) {
                setPage(true, true);
                return true;
            }
            if (target == CONTROLS) {
                setPage(false, true);
                return true;
            }
            View next = target == 0 ? null : findViewById(target);
            if (next != null) next.requestFocus();
            return true;
        });
    }

    /** Switches the two slides, their dots and focus; {@code restoreFocus} moves focus with the page. */
    private void setPage(boolean nowBar, boolean restoreFocus) {
        if (showingNowBar == nowBar && !restoreFocus) {
            updateDots();
            return;
        }
        // Leaving the tiles: remember the tile to come back to when the Now Bar slide closes.
        if (!showingNowBar) {
            View current = getCurrentFocus();
            if (current != null && current.getId() != View.NO_ID) controlsFocus = current.getId();
        }
        showingNowBar = nowBar;
        findViewById(R.id.pageControls).setVisibility(nowBar ? View.GONE : View.VISIBLE);
        findViewById(R.id.pageNowBar).setVisibility(nowBar ? View.VISIBLE : View.GONE);
        updateDots();
        if (!restoreFocus) return;
        if (nowBar) {
            updateNowPlayingTile();
            updateScoreBoard();
            View card = findViewById(R.id.tileNowPlaying);
            card.post(card::requestFocus);
        } else {
            View back = findViewById(controlsFocus);
            if (back == null) back = findViewById(R.id.tileSleep);
            back.post(back::requestFocus);
        }
    }

    private void updateDots() {
        View first = findViewById(R.id.ccDot0);
        View second = findViewById(R.id.ccDot1);
        if (first == null || second == null) return;
        first.setAlpha(showingNowBar ? 0.3f : 1f);
        second.setAlpha(showingNowBar ? 1f : 0.3f);
    }

    /**
     * Inputs as a folder: the same list Home drops under the clock pill, opened over the page it was called
     * from, so switching a source never leaves Control Center. Back or the pill again closes it.
     */
    private void showInputs(boolean open) {
        View folder = findViewById(R.id.pageInputs);
        if (!open) {
            inputsOpen = false;
            folder.setVisibility(View.GONE);
            View back = findViewById(showingNowBar ? R.id.tileNowPlaying : controlsFocus);
            if (back != null) back.requestFocus();
            return;
        }
        LinearLayout rows = findViewById(R.id.ccInputRows);
        rows.removeAllViews();
        boolean built = InputMenu.build(this, inputSettings, new InputMenu.Sink() {
            @Override public void separator() {
                View line = new View(ControlCenterActivity.this);
                line.setBackgroundColor(0x22FFFFFF);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
                lp.setMargins(dp(10), dp(6), dp(10), dp(6));
                rows.addView(line, lp);
            }

            @Override public void row(int iconRes, String label, int state, Runnable open) {
                addInputRow(rows, iconRes, label, state, open);
            }
        });
        if (!built) {
            Toast.makeText(this, R.string.no_inputs, Toast.LENGTH_SHORT).show();
            return;
        }
        inputsOpen = true;
        folder.setVisibility(View.VISIBLE);
        if (rows.getChildCount() > 0) rows.getChildAt(0).requestFocus();
    }

    private void addInputRow(LinearLayout rows, int iconRes, String label, int state, Runnable open) {
        View row = getLayoutInflater().inflate(R.layout.item_input, rows, false);
        ((ImageView) row.findViewById(R.id.icon)).setImageResource(iconRes);
        ((TextView) row.findViewById(R.id.title)).setText(label);
        TextView status = row.findViewById(R.id.status);
        View dot = row.findViewById(R.id.dot);
        // Same rule as Home's list: only definite states are shown, because some TVs report standby for
        // every port whether or not something is plugged in.
        if (state == android.media.tv.TvInputManager.INPUT_STATE_CONNECTED) {
            status.setText(R.string.connected);
            dot.setVisibility(View.VISIBLE);
        } else if (state == android.media.tv.TvInputManager.INPUT_STATE_DISCONNECTED) {
            status.setText(R.string.not_connected);
            dot.setVisibility(View.GONE);
        } else {
            status.setVisibility(View.GONE);
            dot.setVisibility(View.GONE);
        }
        row.setContentDescription(status.getVisibility() == View.VISIBLE
                ? label + ", " + status.getText() : label);
        row.setOnClickListener(v -> {
            open.run();
            finish();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rows.addView(row, lp);
    }

    private void setTile(int id, int icon, CharSequence title, CharSequence status, Runnable action) {
        View tile = findViewById(id);
        ImageView tileIcon = tile.findViewById(R.id.tileIcon);
        tileIcon.setImageResource(icon);
        tileIcon.setColorFilter(0xF2FFFFFF, android.graphics.PorterDuff.Mode.SRC_IN);
        ((TextView) tile.findViewById(R.id.tileTitle)).setText(title);
        TextView statusView = tile.findViewById(R.id.tileStatus);
        if (status == null || status.length() == 0) {
            statusView.setVisibility(View.GONE);
        } else {
            statusView.setText(status);
            statusView.setVisibility(View.VISIBLE);
        }
        tile.setContentDescription(status == null || status.length() == 0
                ? title : title + ", " + status);
        tile.setOnClickListener(v -> {
            // The Inputs pill doubles as the folder's close button while it is open.
            if (id == R.id.tileInputs && inputsOpen) {
                showInputs(false);
                return;
            }
            action.run();
        });
    }

    private void setTileStatus(int id, CharSequence status) {
        View tile = findViewById(id);
        if (tile == null) return;
        TextView statusView = tile.findViewById(R.id.tileStatus);
        statusView.setText(status);
        statusView.setVisibility(View.VISIBLE);
        CharSequence title = ((TextView) tile.findViewById(R.id.tileTitle)).getText();
        tile.setContentDescription(title + ", " + status);
    }

    private void updateWeatherHeader() {
        View chip = findViewById(R.id.ccWeather);
        if (chip == null) return;
        ImageView icon = chip.findViewById(R.id.ccWeatherIcon);
        TextView temperature = chip.findViewById(R.id.ccWeatherTemp);
        SharedPreferences choices = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        boolean enabled = choices.getBoolean(Config.WEATHER_ENABLED_KEY, false);
        String label = WeatherClient.cachedLabel(this);
        String place = WeatherClient.cachedPlace(this);
        int code = WeatherClient.cachedCode(this);
        int iconId = R.drawable.ic_weather_cloud;
        if (code == 0) iconId = R.drawable.ic_weather_sun;
        else if (code == 1 || code == 2) iconId = R.drawable.ic_weather_partly;
        else if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) {
            iconId = R.drawable.ic_weather_rain;
        } else if (code >= 71 && code <= 77) {
            iconId = R.drawable.ic_weather_snow;
        } else if (code == 45 || code == 48) {
            iconId = R.drawable.ic_weather_fog;
        } else if (code >= 95 && code <= 99) {
            iconId = R.drawable.ic_weather_storm;
        }
        icon.setImageResource(iconId);
        icon.setColorFilter(0xF2FFFFFF, android.graphics.PorterDuff.Mode.SRC_IN);
        String currentTemp = label;
        int split = currentTemp.indexOf(" · ");
        if (split > 0) currentTemp = currentTemp.substring(0, split);
        temperature.setText(currentTemp.isEmpty() ? (enabled ? "—" : getString(R.string.off)) : currentTemp);

        StringBuilder description = new StringBuilder(getString(R.string.cc_weather));
        if (!label.isEmpty()) description.append(", ").append(label);
        if (!place.isEmpty()) description.append(", ").append(place);
        if (!enabled) description.append(", ").append(getString(R.string.cc_weather_off));
        chip.setContentDescription(description);
    }

    /** The score board on the Now Bar slide: every chosen sport, its LIVE state and its winner line. */
    private void updateScoreBoard() {
        LinearLayout scores = findViewById(R.id.ccScores);
        if (scores == null) return;
        View empty = findViewById(R.id.ccScoresEmpty);
        for (int i = scores.getChildCount() - 1; i >= 0; i--) {
            if (scores.getChildAt(i) != empty) scores.removeViewAt(i);
        }
        List<SportsRepository.Item> items = SportsRepository.leadLive(SportsRepository.items(this));
        if (items.isEmpty()) {
            empty.setVisibility(View.VISIBLE);
            scores.setContentDescription(getString(SportsRepository.enabled(this)
                    ? R.string.sports_empty : R.string.sports_off));
            return;
        }
        empty.setVisibility(View.GONE);
        StringBuilder description = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            SportsRepository.Item item = items.get(i);
            View row = getLayoutInflater().inflate(R.layout.item_sports_line, scores, false);
            ((ImageView) row.findViewById(R.id.sportIcon)).setImageResource(SportsRepository.iconFor(item.sport));
            ((TextView) row.findViewById(R.id.sportHeadline)).setText(item.headline);
            TextView status = row.findViewById(R.id.sportStatus);
            status.setText(item.live ? getString(R.string.sports_live) : "");
            status.setVisibility(item.live ? View.VISIBLE : View.GONE);
            row.findViewById(R.id.sportLiveDot).setVisibility(item.live ? View.VISIBLE : View.GONE);
            TextView winner = row.findViewById(R.id.sportWinner);
            if (!item.winner.isEmpty()) {
                winner.setText(SportsRepository.trophyLine(this, item.winner));
                winner.setVisibility(View.VISIBLE);
            } else {
                winner.setVisibility(View.GONE);
            }
            if (i > 0) row.setPadding(0, dp(6), 0, 0);
            scores.addView(row);
            if (i > 0) description.append("; ");
            description.append(SportsRepository.label(this, item.sport)).append(' ').append(item.headline);
            if (!item.detail.isEmpty()) description.append(", ").append(item.detail);
            if (item.live) description.append(", ").append(getString(R.string.sports_live));
            if (!item.winner.isEmpty()) description.append(", ").append(item.winner).append(' ');
        }
        scores.setContentDescription(description);
    }

    /** The Now Bar's Now Playing card; with nothing playing it says so instead of leaving a blank slide. */
    private void updateNowPlayingTile() {
        View tile = findViewById(R.id.tileNowPlaying);
        if (tile == null) return;
        SharedPreferences prefs = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        boolean enabled = prefs.getBoolean(Config.NOW_PLAYING_ENABLED_KEY, false);
        String title = enabled ? prefs.getString(Config.NOW_PLAYING_TITLE_KEY, "") : "";
        TextView titleView = tile.findViewById(R.id.ccNpTitle);
        TextView artist = tile.findViewById(R.id.ccNpArtist);
        ImageView toggle = tile.findViewById(R.id.ccNpToggle);
        if (title.isEmpty()) {
            recycleArt();
            titleView.setText(R.string.cc_nothing_playing);
            artist.setVisibility(View.GONE);
            toggle.setVisibility(View.GONE);
            tile.findViewById(R.id.ccNpProgressRow).setVisibility(View.GONE);
            tile.findViewById(R.id.ccNpControls).setVisibility(View.GONE);
            ((ImageView) tile.findViewById(R.id.ccNpArt)).setImageDrawable(null);
            tile.findViewById(R.id.ccNpPlaceholder).setVisibility(View.VISIBLE);
            tile.setContentDescription(getString(R.string.cc_nothing_playing));
            return;
        }
        tile.findViewById(R.id.ccNpProgressRow).setVisibility(View.VISIBLE);
        tile.findViewById(R.id.ccNpControls).setVisibility(View.VISIBLE);
        titleView.setText(title);
        String artistText = prefs.getString(Config.NOW_PLAYING_ARTIST_KEY, "");
        artist.setText(artistText);
        artist.setVisibility(artistText.isEmpty() ? View.GONE : View.VISIBLE);
        toggle.setVisibility(View.VISIBLE);
        boolean playing = prefs.getBoolean(Config.NOW_PLAYING_PLAYING_KEY, false);
        toggle.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
        toggle.setContentDescription(getString(playing ? R.string.now_playing_pause : R.string.now_playing_play));
        long duration = prefs.getLong(Config.NOW_PLAYING_DURATION_KEY, 0L);
        long position = NowPlayingProgress.position(
                prefs.getLong(Config.NOW_PLAYING_POSITION_KEY, 0L),
                prefs.getLong(Config.NOW_PLAYING_UPDATED_AT_KEY, 0L),
                prefs.getFloat(Config.NOW_PLAYING_SPEED_KEY, 1f), duration, playing,
                android.os.SystemClock.elapsedRealtime());
        ((TextView) tile.findViewById(R.id.ccNpElapsed)).setText(NowPlayingProgress.time(position));
        ((TextView) tile.findViewById(R.id.ccNpRemaining)).setText(duration > 0
                ? "-" + NowPlayingProgress.time(Math.max(0L, duration - position)) : "—:—");
        android.widget.ProgressBar progress = tile.findViewById(R.id.ccNpProgress);
        progress.setProgress(duration > 0 ? (int) Math.max(0L, Math.min(1000L, position * 1000L / duration)) : 0);
        int artVersion = prefs.getInt(Config.NOW_PLAYING_ART_VERSION_KEY, 0);
        if (artVersion != artShown) {
            recycleArt();
            artShown = artVersion;
            artBitmap = NowPlayingArt.load(this);
            ((ImageView) tile.findViewById(R.id.ccNpArt)).setImageBitmap(artBitmap);
            tile.findViewById(R.id.ccNpPlaceholder)
                    .setVisibility(artBitmap == null ? View.VISIBLE : View.GONE);
        }
        StringBuilder description = new StringBuilder(title);
        if (!artistText.isEmpty()) description.append(", ").append(artistText);
        tile.setContentDescription(description);
    }

    private void recycleArt() {
        if (artBitmap != null) {
            ImageView art = findViewById(R.id.ccNpArt);
            if (art != null) art.setImageDrawable(null);
            artBitmap.recycle();
            artBitmap = null;
        }
        artShown = -1;
    }

    private void openSystem(String action) {
        try {
            startActivity(SystemSettings.intent(this, action));
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, R.string.not_available, Toast.LENGTH_LONG).show();
        }
        finish();
    }

    private void openLauncherSettings() {
        startActivity(new Intent(this, MainActivity.class).setAction(MainActivity.ACTION_LAUNCHER_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }

    private void openSportsSettings() {
        startActivity(new Intent(this, SportsSettingsActivity.class));
        finish();
    }

    private void openProfiles() {
        startActivity(new Intent(this, ProfilesActivity.class));
        finish();
    }

    private void scaleOnFocus(View view, float scale) {
        view.setOnFocusChangeListener((v, focused) -> {
            v.animate().scaleX(focused ? scale : 1f).scaleY(focused ? scale : 1f)
                    .setDuration(reducedMotion ? Motion.REDUCED_MS : 160).start();
            v.setTranslationZ(focused ? dp(8) : 0);
        });
    }

    private void playEntrance() {
        View panel = findViewById(R.id.ccPanel);
        if (reducedMotion || !getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE)
                .getBoolean("animations", true)) return;
        panel.setAlpha(0f);
        panel.setScaleX(0.94f);
        panel.setScaleY(0.94f);
        panel.setTranslationY(-dp(10));
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(220).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
    }

    /**
     * Android 10+ only tells an app its Wi-Fi name with precise location, so the pill reads "Connected" until
     * the owner allows it. Asked once per run, from the panel that shows the name.
     */
    private void askForWifiName() {
        if (wifiNameAsked || Build.VERSION.SDK_INT < 23) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            return;
        }
        ConnectivityManager manager = getSystemService(ConnectivityManager.class);
        NetworkCapabilities capabilities = manager == null ? null
                : manager.getNetworkCapabilities(manager.getActiveNetwork());
        if (capabilities == null || !capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return;
        wifiNameAsked = true;
        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_WIFI_NAME);
    }

    private String wifiStatus() {
        ConnectivityManager manager = getSystemService(ConnectivityManager.class);
        NetworkCapabilities capabilities = manager == null ? null
                : manager.getNetworkCapabilities(manager.getActiveNetwork());
        if (capabilities == null || !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
            return getString(R.string.cc_wifi_off);
        }
        WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        WifiInfo info = wifi == null ? null : wifi.getConnectionInfo();
        String ssid = info == null ? null : info.getSSID();
        if (ssid != null && ssid.length() > 1 && ssid.startsWith("\"") && ssid.endsWith("\"")) {
            ssid = ssid.substring(1, ssid.length() - 1);
        }
        if (ssid == null || ssid.isEmpty() || ssid.contains("<unknown")) ssid = null;
        return ssid != null ? ssid : getString(R.string.connected);
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    private void registerUpdates() {
        if (weatherRegistered) return;
        IntentFilter weather = new IntentFilter(WeatherClient.ACTION_UPDATED);
        IntentFilter sports = new IntentFilter(SportsRepository.ACTION_UPDATED);
        IntentFilter nowPlaying = new IntentFilter(NowPlayingListener.ACTION_UPDATED);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(weatherReceiver, weather, Context.RECEIVER_NOT_EXPORTED);
            registerReceiver(sportsReceiver, sports, Context.RECEIVER_NOT_EXPORTED);
            registerReceiver(nowPlayingReceiver, nowPlaying, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(weatherReceiver, weather);
            registerReceiver(sportsReceiver, sports);
            registerReceiver(nowPlayingReceiver, nowPlaying);
        }
        weatherRegistered = true;
        sportsRegistered = true;
        nowPlayingRegistered = true;
    }

    private void unregisterUpdates() {
        if (weatherRegistered) {
            unregisterReceiver(weatherReceiver);
            weatherRegistered = false;
        }
        if (sportsRegistered) {
            unregisterReceiver(sportsReceiver);
            sportsRegistered = false;
        }
        if (nowPlayingRegistered) {
            unregisterReceiver(nowPlayingReceiver);
            nowPlayingRegistered = false;
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override protected void onDestroy() {
        unregisterUpdates();
        recycleArt();
        super.onDestroy();
    }
}
