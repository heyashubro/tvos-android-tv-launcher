package com.gathin.tvhome;

import java.util.Locale;

/** Where the Now Playing bar sits between the session's last state report and now. */
final class NowPlayingProgress {
    private NowPlayingProgress() { }

    /**
     * The position to draw: the session's reported position plus the time played since its update, never
     * past the end. Paused or buffering playback stays on the reported position.
     */
    static long position(long reported, long updatedAtElapsed, float speed, long duration,
                         boolean playing, long nowElapsed) {
        long position = Math.max(0, reported);
        if (playing && speed > 0 && updatedAtElapsed > 0 && nowElapsed > updatedAtElapsed) {
            position += Math.round((nowElapsed - updatedAtElapsed) * speed);
        }
        if (duration > 0 && position > duration) position = duration;
        return position;
    }

    /** "m:ss", or "h:mm:ss" for a track over an hour. */
    static String time(long millis) {
        long seconds = Math.max(0, millis) / 1000;
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long rest = seconds % 60;
        return hours > 0 ? String.format(Locale.US, "%d:%02d:%02d", hours, minutes, rest)
                : String.format(Locale.US, "%d:%02d", minutes, rest);
    }
}
