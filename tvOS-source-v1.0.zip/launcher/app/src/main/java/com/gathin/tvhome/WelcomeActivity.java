package com.gathin.tvhome;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * The setup assistant: welcome, remote tips, network, Glance, a profile, and a finish. It is the first-run
 * screen and can be run again from Launcher settings; Back, Skip and Finish all mark it done so it never
 * opens twice by itself.
 */
public final class WelcomeActivity extends LauncherActivity {

    private static final int STEP_WELCOME = 0;
    private static final int STEP_REMOTE = 1;
    private static final int STEP_NETWORK = 2;
    private static final int STEP_GLANCE = 3;
    private static final int STEP_PROFILE = 4;
    private static final int STEP_DONE = 5;
    private static final int STEP_COUNT = 6;
    private static final int REQUEST_PHOTOS = 45;

    private static final int[] STEP_TITLES = {
            R.string.wizard_welcome_title, R.string.wizard_remote_title, R.string.wizard_network_title,
            R.string.wizard_glance_title, R.string.wizard_profile_title, R.string.wizard_all_set_title,
    };
    private static final int[] STEP_BODIES = {
            R.string.wizard_welcome_body, R.string.wizard_remote_body, R.string.wizard_network_body,
            R.string.wizard_glance_body, R.string.wizard_profile_body, R.string.wizard_all_set_body,
    };
    private static final int[] STEP_ICONS = {
            R.drawable.ic_apps, R.drawable.ic_remote, R.drawable.ic_wifi,
            R.drawable.ic_picture, R.drawable.ic_person, R.drawable.ic_check,
    };

    private SharedPreferences prefs;
    private boolean animations;
    private boolean reducedMotion;
    private int accent;
    private int step = STEP_WELCOME;
    private int avatar;
    private boolean photoDenied;
    private View card, remote, network, glance, profile;
    private ImageView icon;
    private TextView title, body, networkStatus, networkButton, glanceToggle, photoAccess, photoHint;
    private EditText nameField;
    private LinearLayout avatarRow, dots;
    private TextView back, skip, next;
    private final List<ImageView> avatarViews = new ArrayList<>();
    private List<Integer> avatarChoices;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        Config config = Config.load(this);
        animations = config.animations;
        reducedMotion = config.reducedMotion;
        TypedValue accentValue = new TypedValue();
        getTheme().resolveAttribute(R.attr.accent, accentValue, true);
        accent = accentValue.data;

        setContentView(R.layout.activity_welcome);
        card = findViewById(R.id.wizardCard);
        icon = findViewById(R.id.wizardIcon);
        title = findViewById(R.id.wizardTitle);
        body = findViewById(R.id.wizardBody);
        remote = findViewById(R.id.wizardRemote);
        network = findViewById(R.id.wizardNetwork);
        networkStatus = findViewById(R.id.wizardNetworkStatus);
        networkButton = findViewById(R.id.wizardNetworkButton);
        glance = findViewById(R.id.wizardGlance);
        glanceToggle = findViewById(R.id.wizardGlanceToggle);
        photoAccess = findViewById(R.id.wizardPhotoAccess);
        photoHint = findViewById(R.id.wizardPhotoHint);
        profile = findViewById(R.id.wizardProfile);
        nameField = findViewById(R.id.wizardProfileName);
        avatarRow = findViewById(R.id.wizardAvatarRow);
        dots = findViewById(R.id.wizardDots);
        back = findViewById(R.id.wizardBack);
        skip = findViewById(R.id.wizardSkip);
        next = findViewById(R.id.wizardNext);

        ProfileStore.syncAccount(this);
        ProfileStore.Profile active = ProfileStore.active(this);
        avatar = active.avatar;
        nameField.setText(active.name);
        buildAvatars();
        buildDots();

        back.setOnClickListener(v -> showStep(step - 1, true));
        skip.setOnClickListener(v -> finishSetup());
        next.setOnClickListener(v -> {
            if (step != STEP_DONE) showStep(step + 1, true);
            else finishSetup();
        });
        networkButton.setOnClickListener(v -> openNetworkSettings());
        glanceToggle.setOnClickListener(v -> toggleGlance());
        photoAccess.setOnClickListener(v -> requestPhotos());

        showStep(STEP_WELCOME, false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (step == STEP_NETWORK) renderNetwork();
        if (step == STEP_GLANCE) renderGlance();
    }

    @Override
    public void onBackPressed() {
        if (step > STEP_WELCOME) showStep(step - 1, true);
        else finishSetup();
    }

    private void showStep(int target, boolean animate) {
        if (target < 0 || target >= STEP_COUNT) {
            finishSetup();
            return;
        }
        int from = step;
        if (from == STEP_PROFILE && target != STEP_PROFILE) saveProfile();
        step = target;
        render();
        if (animate && animations && !reducedMotion && card.getWidth() > 0) {
            card.animate().cancel();
            card.setAlpha(0f);
            card.setTranslationX((target > from ? 1 : -1) * dp(26));
            card.animate().alpha(1f).translationX(0f).setDuration(200)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
        View focus = focusForStep();
        if (focus != null) focus.post(focus::requestFocus);
    }

    private void render() {
        title.setText(STEP_TITLES[step]);
        body.setText(STEP_BODIES[step]);
        remote.setVisibility(step == STEP_REMOTE ? View.VISIBLE : View.GONE);
        network.setVisibility(step == STEP_NETWORK ? View.VISIBLE : View.GONE);
        glance.setVisibility(step == STEP_GLANCE ? View.VISIBLE : View.GONE);
        profile.setVisibility(step == STEP_PROFILE ? View.VISIBLE : View.GONE);
        back.setVisibility(step == STEP_WELCOME ? View.INVISIBLE : View.VISIBLE);
        skip.setVisibility(step == STEP_DONE ? View.GONE : View.VISIBLE);
        next.setText(step == STEP_DONE ? R.string.wizard_done : R.string.wizard_next);
        if (step == STEP_PROFILE) {
            icon.setVisibility(View.GONE);
        } else {
            icon.setVisibility(View.VISIBLE);
            icon.setImageTintList(ColorStateList.valueOf(accent));
            icon.setImageResource(STEP_ICONS[step]);
        }
        if (step == STEP_NETWORK) renderNetwork();
        if (step == STEP_GLANCE) renderGlance();
        renderDots();
    }

    private View focusForStep() {
        if (step == STEP_NETWORK) return networkButton;
        if (step == STEP_GLANCE) return glanceToggle;
        if (step == STEP_PROFILE) return nameField;
        return next;
    }

    private void renderNetwork() {
        networkStatus.setText(networkStatusText());
    }

    private String networkStatusText() {
        ConnectivityManager manager = getSystemService(ConnectivityManager.class);
        Network active = manager == null ? null : manager.getActiveNetwork();
        NetworkCapabilities caps = active == null ? null : manager.getNetworkCapabilities(active);
        if (caps == null) return getString(R.string.wizard_network_off);
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            WifiManager wifi = getSystemService(WifiManager.class);
            WifiInfo info = wifi == null ? null : wifi.getConnectionInfo();
            String ssid = info == null ? null : info.getSSID();
            if (ssid != null && ssid.length() > 2 && !ssid.contains("unknown")) {
                if (ssid.startsWith("\"") && ssid.endsWith("\"")) ssid = ssid.substring(1, ssid.length() - 1);
                return getString(R.string.wizard_network_connected, ssid);
            }
            return getString(R.string.wizard_network_wifi);
        }
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
            return getString(R.string.wizard_network_ethernet);
        }
        return getString(R.string.wizard_network_other);
    }

    private void openNetworkSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
        } catch (ActivityNotFoundException | SecurityException e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (ActivityNotFoundException | SecurityException ignored) {
            }
        }
    }

    private void renderGlance() {
        boolean on = prefs.getBoolean(Config.GLANCE_ENABLED_KEY, false);
        glanceToggle.setText(getString(R.string.glance_state, getString(on ? R.string.on : R.string.off)));
        glanceToggle.setSelected(on);
        boolean granted = hasPhotoAccess();
        photoAccess.setVisibility(granted ? View.GONE : View.VISIBLE);
        int hint;
        if (granted) hint = R.string.wizard_photo_ready;
        else if (photoDenied) hint = R.string.wizard_photo_denied;
        else if (on) hint = R.string.wizard_photo_needed;
        else hint = R.string.wizard_photo_optional;
        photoHint.setText(hint);
    }

    private void toggleGlance() {
        boolean on = prefs.getBoolean(Config.GLANCE_ENABLED_KEY, false);
        if (on) {
            prefs.edit().putBoolean(Config.GLANCE_ENABLED_KEY, false).apply();
            renderGlance();
            return;
        }
        if (hasPhotoAccess()) enableGlance();
        else requestPhotos();
    }

    private void enableGlance() {
        prefs.edit().putBoolean(Config.GLANCE_ENABLED_KEY, true).apply();
        renderGlance();
    }

    private void requestPhotos() {
        requestPermissions(new String[]{photoPermission()}, REQUEST_PHOTOS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_PHOTOS) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            photoDenied = false;
            enableGlance();
        } else {
            photoDenied = true;
            renderGlance();
        }
        glanceToggle.post(glanceToggle::requestFocus);
    }

    private boolean hasPhotoAccess() {
        return checkSelfPermission(photoPermission()) == PackageManager.PERMISSION_GRANTED;
    }

    private String photoPermission() {
        return Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    private void buildAvatars() {
        avatarChoices = ProfileStore.avatarChoices(this);
        for (int i = 0; i < avatarChoices.size(); i++) {
            int index = avatarChoices.get(i);
            ImageView view = new ImageView(this);
            view.setImageDrawable(index == ProfileStore.AVATAR_ACCOUNT
                    ? AccountIdentity.avatar(this) : getDrawable(ProfileStore.avatarRes(index)));
            view.setScaleType(ImageView.ScaleType.CENTER_CROP);
            view.setBackgroundResource(R.drawable.profile_avatar_choice);
            view.setForeground(getDrawable(R.drawable.profile_avatar_focus));
            view.setClipToOutline(true);
            view.setFocusable(true);
            view.setClickable(true);
            view.setContentDescription(index == ProfileStore.AVATAR_ACCOUNT
                    ? getString(R.string.profile_account_avatar)
                    : getString(R.string.profile_choose_avatar) + " " + (index + 1));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(46), dp(46));
            params.setMarginStart(dp(3));
            params.setMarginEnd(dp(3));
            view.setLayoutParams(params);
            view.setOnClickListener(v -> selectAvatar(index));
            view.setOnFocusChangeListener((v, focused) -> {
                if (focused) selectAvatar(index);
                v.animate().scaleX(focused ? 1.06f : 1f).scaleY(focused ? 1.06f : 1f)
                        .setDuration(reducedMotion ? Motion.REDUCED_MS : 140).start();
            });
            avatarRow.addView(view);
            avatarViews.add(view);
        }
        selectAvatar(avatar);
    }

    private void selectAvatar(int index) {
        avatar = index;
        for (int i = 0; i < avatarViews.size(); i++) avatarViews.get(i).setActivated(avatarChoices.get(i) == index);
        if (step == STEP_PROFILE) {
            icon.setImageDrawable(index == ProfileStore.AVATAR_ACCOUNT
                    ? AccountIdentity.avatar(this) : getDrawable(ProfileStore.avatarRes(index)));
        }
    }

    private void buildDots() {
        for (int i = 0; i < STEP_COUNT; i++) {
            View dot = new View(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(7), dp(7));
            params.setMarginStart(dp(4));
            params.setMarginEnd(dp(4));
            dot.setLayoutParams(params);
            dots.addView(dot);
        }
    }

    private void renderDots() {
        for (int i = 0; i < dots.getChildCount(); i++) {
            View dot = dots.getChildAt(i);
            ViewGroup.LayoutParams params = dot.getLayoutParams();
            int size = dp(i == step ? 10 : 7);
            params.width = size;
            params.height = size;
            dot.setLayoutParams(params);
            GradientDrawable background = new GradientDrawable();
            background.setShape(GradientDrawable.OVAL);
            background.setColor(i == step ? accent : 0x40FFFFFF);
            dot.setBackground(background);
        }
    }

    private void saveProfile() {
        if (ProfileStore.isGuest(this)) return;
        ProfileStore.Profile active = ProfileStore.active(this);
        String name = nameField.getText().toString().trim();
        boolean changed = false;
        if (!name.isEmpty() && !name.equals(active.name)) {
            active.name = name;
            changed = true;
        }
        if (active.avatar != avatar) {
            active.avatar = avatar;
            changed = true;
        }
        if (changed) ProfileStore.save(this, active);
    }

    private void finishSetup() {
        if (step == STEP_PROFILE) saveProfile();
        prefs.edit().putBoolean(Config.WELCOME_SHOWN_KEY, true)
                .putLong(Config.SETTINGS_REVISION_KEY, prefs.getLong(Config.SETTINGS_REVISION_KEY, 0) + 1)
                .apply();
        setResult(RESULT_OK);
        finish();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
