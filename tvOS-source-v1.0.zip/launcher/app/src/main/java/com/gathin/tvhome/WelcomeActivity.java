package com.gathin.tvhome;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** One-time remote-friendly welcome and appearance setup. */
public final class WelcomeActivity extends Activity {
    private SharedPreferences prefs;
    private int step = 0;
    private TextView title, body, stepLabel, darkButton, lightButton, nextButton, skipButton;
    private boolean dark = true;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        dark = prefs.getBoolean(Config.DARK_MODE_KEY, true);
        buildUi();
        render();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_VERTICAL);
        root.setPadding(dp(96), dp(48), dp(96), dp(48));
        root.setBackgroundColor(0xFF101419);
        title = new TextView(this); title.setTextSize(52); title.setTextColor(Color.WHITE); title.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        body = new TextView(this); body.setTextSize(26); body.setTextColor(0xFFD0D6DE); body.setPadding(0, dp(12), 0, dp(18));
        stepLabel = new TextView(this); stepLabel.setTextSize(18); stepLabel.setTextColor(0xFFACB8C1);
        darkButton = button(getString(R.string.appearance_dark)); lightButton = button(getString(R.string.appearance_light));
        darkButton.setOnClickListener(v -> setMode(true)); lightButton.setOnClickListener(v -> setMode(false));
        LinearLayout modes = new LinearLayout(this); modes.setOrientation(LinearLayout.HORIZONTAL); modes.addView(darkButton, weighted()); modes.addView(lightButton, weighted());
        nextButton = button(getString(R.string.wizard_next)); skipButton = button(getString(R.string.wizard_skip));
        nextButton.setOnClickListener(v -> { if (step < 2) { step++; render(); } else finishSetup(); });
        skipButton.setOnClickListener(v -> finishSetup());
        root.addView(title); root.addView(body); root.addView(stepLabel); root.addView(modes); root.addView(nextButton); root.addView(skipButton);
        setContentView(root);
    }

    private TextView button(String text) {
        TextView v = new TextView(this); v.setText(text); v.setTextSize(22); v.setTextColor(Color.WHITE);
        v.setFocusable(true); v.setClickable(true); v.setGravity(Gravity.CENTER_VERTICAL); v.setPadding(dp(20), 0, dp(20), 0);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable(); bg.setColor(0xFF252B34); bg.setCornerRadius(dp(12)); v.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(62)); lp.topMargin = dp(10); v.setLayoutParams(lp); return v;
    }
    private LinearLayout.LayoutParams weighted() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(62), 1); p.setMargins(0, dp(10), dp(10), 0); return p; }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }
    private void setMode(boolean value) { dark = value; prefs.edit().putBoolean(Config.DARK_MODE_KEY, value).apply(); render(); }
    private void render() {
        int titles[] = {R.string.wizard_welcome_title, R.string.wizard_appearance_title, R.string.wizard_glance_title};
        int bodies[] = {R.string.wizard_welcome_body, R.string.wizard_appearance_body, R.string.wizard_glance_body};
        title.setText(titles[step]); body.setText(bodies[step]); stepLabel.setText(getString(R.string.wizard_step, step + 1, 3));
        stepLabel.setVisibility(step == 0 ? View.GONE : View.VISIBLE);
        darkButton.setVisibility(step == 1 ? View.VISIBLE : View.GONE); lightButton.setVisibility(step == 1 ? View.VISIBLE : View.GONE);
        nextButton.setText(step == 2 ? R.string.wizard_done : R.string.wizard_next);
        if (step == 0) nextButton.requestFocus();
        else if (step == 1) darkButton.requestFocus(); else nextButton.requestFocus();
    }
    private void finishSetup() { prefs.edit().putBoolean(Config.WELCOME_SHOWN_KEY, true).apply(); setResult(RESULT_OK); finish(); }
    @Override public void onBackPressed() { finishSetup(); }
}
