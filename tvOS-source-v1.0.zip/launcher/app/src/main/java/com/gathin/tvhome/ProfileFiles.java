package com.gathin.tvhome;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Where a profile's home layout, shortcuts and wallpaper live. The default profile keeps the legacy paths. */
final class ProfileFiles {

    private ProfileFiles() { }

    static File dir(Context context, String id) {
        if (ProfileStore.DEFAULT_ID.equals(id)) return context.getFilesDir();
        File dir = new File(new File(context.getFilesDir(), "profiles"), id);
        if (!dir.isDirectory()) dir.mkdirs();
        return dir;
    }

    static File dir(Context context) {
        return dir(context, ProfileStore.activeId(context));
    }

    static File order(Context context, String id) {
        return new File(dir(context, id), Order.FILE_NAME);
    }

    static File order(Context context) {
        return new File(dir(context), Order.FILE_NAME);
    }

    static File library(Context context, boolean removed) {
        return new File(dir(context), removed ? "library_home_removed.txt" : "library_apps.txt");
    }

    static File wallpaper(Context context) {
        return new File(dir(context), Config.USER_WALLPAPER_FILE);
    }

    /** Copies the layout files a new profile starts from; a missing wallpaper stays missing. */
    static void copy(Context context, String from, String to) {
        copyFile(order(context, from), order(context, to));
        for (String name : new String[]{"library_apps.txt", "library_home_removed.txt", Config.USER_WALLPAPER_FILE}) {
            copyFile(new File(dir(context, from), name), new File(dir(context, to), name));
        }
    }

    static void delete(Context context, String id) {
        File dir = dir(context, id);
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (ProfileStore.DEFAULT_ID.equals(id)) {
                String name = file.getName();
                if (!name.equals(Order.FILE_NAME) && !name.equals("library_apps.txt")
                        && !name.equals("library_home_removed.txt") && !name.equals(Config.USER_WALLPAPER_FILE)) continue;
            }
            if (file.isDirectory()) deleteTree(file); else file.delete();
        }
    }

    private static void deleteTree(File file) {
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteTree(child);
        file.delete();
    }

    private static void copyFile(File from, File to) {
        if (!from.isFile()) return;
        if (!to.getParentFile().isDirectory()) to.getParentFile().mkdirs();
        try (InputStream in = new FileInputStream(from); OutputStream out = new FileOutputStream(to)) {
            byte[] buffer = new byte[16 * 1024];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
        } catch (IOException ignored) {
        }
    }
}
