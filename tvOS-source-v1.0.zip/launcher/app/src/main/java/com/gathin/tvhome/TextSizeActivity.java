package com.gathin.tvhome;

import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/** Apple TV-style Text Size: seven steps, a dotted slider, and a sample card that grows as the owner moves. */
public final class TextSizeActivity extends LauncherActivity {
    private static final float SAMPLE_GLYPH_SP = 20f;
    private static final float SAMPLE_TITLE_SP = 24f;
    private static final float SAMPLE_BODY_SP = 15f;

    private SeekBar slider;
    private LinearLayout dots;
    private TextView sampleGlyph;
    private TextView sampleTitle;
    private TextView sampleBody;
    private TextView percent;
    private float factorAtCreate;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_text_size);
        factorAtCreate = TextScale.factor(TextScale.step(this));
        slider = findViewById(R.id.textSizeSlider);
        dots = findViewById(R.id.textSizeDots);
        sampleGlyph = findViewById(R.id.textSizeSampleGlyph);
        sampleTitle = findViewById(R.id.textSizeSampleTitle);
        sampleBody = findViewById(R.id.textSizeSampleBody);
        percent = findViewById(R.id.textSizePercent);
        slider.setMax(TextScale.STEPS - 1);
        slider.setProgress(TextScale.step(this));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) applyStep(progress, true);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        applyStep(TextScale.step(this), false);
        slider.requestFocus();
    }

    /** The screen keeps the size it opened with, so the sample is scaled relative to that factor. */
    private void applyStep(int step, boolean save) {
        float ratio = TextScale.factor(step) / factorAtCreate;
        sampleGlyph.setTextSize(TypedValue.COMPLEX_UNIT_SP, SAMPLE_GLYPH_SP * ratio);
        sampleTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, SAMPLE_TITLE_SP * ratio);
        sampleBody.setTextSize(TypedValue.COMPLEX_UNIT_SP, SAMPLE_BODY_SP * ratio);
        percent.setText(getString(R.string.text_size_percent, TextScale.percent(step)));
        showDots(step);
        if (!save) return;
        SharedPreferences prefs = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        TextScale.setStep(prefs, step);
        prefs.edit().putLong(Config.SETTINGS_REVISION_KEY,
                prefs.getLong(Config.SETTINGS_REVISION_KEY, 0) + 1).apply();
    }

    private void showDots(int step) {
        int inactive = 0x4DFFFFFF;
        TypedValue accent = new TypedValue();
        getTheme().resolveAttribute(R.attr.accent, accent, true);
        dots.removeAllViews();
        for (int i = 0; i < TextScale.STEPS; i++) {
            View dot = new View(this);
            GradientDrawable shape = new GradientDrawable();
            shape.setShape(GradientDrawable.OVAL);
            shape.setColor(i == step ? accent.data : inactive);
            dot.setBackground(shape);
            int size = dp(i == step ? 8 : 6);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
            params.setMarginStart(dp(6));
            params.setMarginEnd(dp(6));
            dots.addView(dot, params);
        }
    }

    /** Its own preview updates without a repaint; the screen never restarts under the owner. */
    @Override
    protected boolean recreateOnAppearanceChange() {
        return false;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
