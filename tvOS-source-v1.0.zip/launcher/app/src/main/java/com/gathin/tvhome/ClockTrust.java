package com.gathin.tvhome;

/**
 * Whether the system clock can be trusted yet. A TV that boots without an RTC (or before the network
 * sync lands) reports a 1970 date; the top bar must keep its actions usable meanwhile and recover in
 * place instead of hiding itself. Retries back off so a long offline boot does not wake the CPU every
 * second for hours.
 */
final class ClockTrust {
    /** 2025-01-01T00:00:00Z: the earliest time a launcher release can ship after, so a 1970/2024 RTC is wrong. */
    static final long VALID_AFTER_MS = 1_735_689_600_000L;
    private static final long[] RETRY_MS = {1_000L, 2_000L, 5_000L, 15_000L, 30_000L};

    private ClockTrust() {}

    static boolean valid(long nowMs) {
        return nowMs >= VALID_AFTER_MS;
    }

    static long retryDelayMs(int attempt) {
        return RETRY_MS[Math.max(0, Math.min(RETRY_MS.length - 1, attempt))];
    }
}
