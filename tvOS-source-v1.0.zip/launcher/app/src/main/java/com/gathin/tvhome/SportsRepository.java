package com.gathin.tvhome;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The scores under Now Playing: one line per chosen sport, from free public feeds. Football comes from ESPN's
 * scoreboard, cricket from the public Cricbuzz live page and Formula 1 from Jolpica. Results are cached so the
 * launcher can show them offline, refreshed every minute, and every ten seconds while a match is in play.
 */
final class SportsRepository {
    static final String ACTION_UPDATED = "com.gathin.tvhome.SPORTS_UPDATED";

    static final String MASTER_KEY = "sports_enabled";
    static final String FOOTBALL_KEY = "sports_football";
    static final String CRICKET_KEY = "sports_cricket";
    static final String F1_KEY = "sports_f1";
    static final String FOOTBALL_LEAGUE_KEY = "sports_football_league";
    static final String COUNTRY_KEY = "sports_country";
    static final String ORDER_KEY = "sports_order";
    /** The winner burst: on or off, how big (0 subtle, 1 normal, 2 party) and which emoji pack. */
    static final String CELEBRATION_KEY = "sports_celebration";
    static final String CELEBRATION_SIZE_KEY = "sports_celebration_size";
    static final String CELEBRATION_STYLE_KEY = "sports_celebration_style";

    static final String FOOTBALL = "football", CRICKET = "cricket", F1 = "f1";
    private static final String[] ALL = {FOOTBALL, CRICKET, F1};

    static final String[] LEAGUE_SLUGS = {
            "eng.1", "esp.1", "ita.1", "ger.1", "fra.1", "por.1", "ned.1", "sco.1", "tur.1",
            "ksa.1", "usa.1", "mex.1", "bra.1", "arg.1", "ind.1", "aus.1", "uefa.champions",
    };

    /** One entry in the Country picker: its football league and, where it plays, its cricket side. */
    static final class Country {
        final String id;
        final int labelRes;
        final String league;
        final String team;
        final String teamCode;

        Country(String id, int labelRes, String league, String team, String teamCode) {
            this.id = id;
            this.labelRes = labelRes;
            this.league = league;
            this.team = team;
            this.teamCode = teamCode;
        }
    }

    static final Country[] COUNTRIES = {
            new Country("world", R.string.sports_country_world, null, null, null),
            new Country("europe", R.string.sports_country_europe, "uefa.champions", null, null),
            new Country("eng", R.string.sports_country_eng, "eng.1", "England", "ENG"),
            new Country("esp", R.string.sports_country_esp, "esp.1", null, null),
            new Country("ita", R.string.sports_country_ita, "ita.1", null, null),
            new Country("ger", R.string.sports_country_ger, "ger.1", null, null),
            new Country("fra", R.string.sports_country_fra, "fra.1", null, null),
            new Country("por", R.string.sports_country_por, "por.1", null, null),
            new Country("ned", R.string.sports_country_ned, "ned.1", null, null),
            new Country("sco", R.string.sports_country_sco, "sco.1", null, null),
            new Country("tur", R.string.sports_country_tur, "tur.1", null, null),
            new Country("ksa", R.string.sports_country_ksa, "ksa.1", null, null),
            new Country("usa", R.string.sports_country_usa, "usa.1", null, null),
            new Country("mex", R.string.sports_country_mex, "mex.1", null, null),
            new Country("bra", R.string.sports_country_bra, "bra.1", null, null),
            new Country("arg", R.string.sports_country_arg, "arg.1", null, null),
            new Country("ind", R.string.sports_country_ind, "ind.1", "India", "IND"),
            new Country("aus", R.string.sports_country_aus, "aus.1", "Australia", "AUS"),
            new Country("pak", R.string.sports_country_pak, null, "Pakistan", "PAK"),
            new Country("rsa", R.string.sports_country_rsa, null, "South Africa", "SA"),
            new Country("nzl", R.string.sports_country_nzl, null, "New Zealand", "NZ"),
            new Country("win", R.string.sports_country_win, null, "West Indies", "WI"),
            new Country("sri", R.string.sports_country_sri, null, "Sri Lanka", "SL"),
            new Country("ban", R.string.sports_country_ban, null, "Bangladesh", "BAN"),
    };

    private static final String CACHE = "sports_cache";
    /** One minute between reads when nothing is in play, so a match starting soon is picked up promptly. */
    private static final long CACHE_MS = 60_000L;
    /** A match in play is re-read every ten seconds; the Home card itself redraws every second. */
    private static final long LIVE_CACHE_MS = 10_000L;
    private static final long MIN_GAP_MS = 30_000L;
    private static final long LIVE_MIN_GAP_MS = 8_000L;
    /** A full-time score stays on the card for a day; afterwards only the winner line survives. */
    private static final long ENDED_KEEP_MS = 24 * 60 * 60_000L;
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final AtomicBoolean RUNNING = new AtomicBoolean();
    private static volatile long lastRequestAt;

    static final int STATUS_UPCOMING = 1;
    static final int STATUS_LIVE = 2;
    static final int STATUS_ENDED = 3;

    static final class Item {
        final String sport;
        final String headline;
        final String detail;
        final boolean live;
        final int status;
        /** The side that won, empty while the match is live, upcoming or a draw. */
        final String winner;
        /** The winner matters to the owner (their country or its league). */
        final boolean userWin;
        /** Upcoming kick-off, epoch millis, 0 when unknown. */
        final long startAt;

        Item(String sport, String headline, String detail, boolean live, int status,
                String winner, boolean userWin, long startAt) {
            this.sport = sport;
            this.headline = headline;
            this.detail = detail;
            this.live = live;
            this.status = status;
            this.winner = winner;
            this.userWin = userWin;
            this.startAt = startAt;
        }

        /** A cheaper Item for callers that only show the score line (Control Center, Glance). */
        Item(String sport, String headline, String detail, boolean live) {
            this(sport, headline, detail, live,
                    live ? STATUS_LIVE : STATUS_ENDED, "", false, 0L);
        }
    }

    /** Internal parser result: the Item plus the event identity that decides when a result is stale. */
    private static final class Fetch {
        final Item item;
        final String eventKey;

        Fetch(Item item, String eventKey) {
            this.item = item;
            this.eventKey = eventKey;
        }
    }

    private SportsRepository() { }

    static SharedPreferences choices(Context context) {
        return context.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE);
    }

    private static SharedPreferences cache(Context context) {
        return context.getApplicationContext().getSharedPreferences(CACHE, Context.MODE_PRIVATE);
    }

    static boolean enabled(Context context) {
        return choices(context).getBoolean(MASTER_KEY, true) && anySport(context);
    }

    static boolean anySport(Context context) {
        SharedPreferences p = choices(context);
        return p.getBoolean(FOOTBALL_KEY, true) || p.getBoolean(CRICKET_KEY, true)
                || p.getBoolean(F1_KEY, true);
    }

    static boolean isSportEnabled(Context context, String sport) {
        String key = sport.equals(FOOTBALL) ? FOOTBALL_KEY : sport.equals(CRICKET) ? CRICKET_KEY : F1_KEY;
        return choices(context).getBoolean(key, true);
    }

    static String label(Context context, String sport) {
        return context.getString(sport.equals(FOOTBALL) ? R.string.sports_football
                : sport.equals(CRICKET) ? R.string.sports_cricket : R.string.sports_f1);
    }

    static int iconFor(String sport) {
        return sport.equals(FOOTBALL) ? R.drawable.ic_football
                : sport.equals(CRICKET) ? R.drawable.ic_cricket : R.drawable.ic_checkered_flag;
    }

    static String league(Context context) {
        return choices(context).getString(FOOTBALL_LEAGUE_KEY, LEAGUE_SLUGS[0]);
    }

    static String leagueLabel(Context context, String slug) {
        switch (slug) {
            case "esp.1": return context.getString(R.string.sports_league_esp);
            case "ita.1": return context.getString(R.string.sports_league_ita);
            case "ger.1": return context.getString(R.string.sports_league_ger);
            case "fra.1": return context.getString(R.string.sports_league_fra);
            case "por.1": return context.getString(R.string.sports_league_por);
            case "ned.1": return context.getString(R.string.sports_league_ned);
            case "sco.1": return context.getString(R.string.sports_league_sco);
            case "tur.1": return context.getString(R.string.sports_league_tur);
            case "ksa.1": return context.getString(R.string.sports_league_ksa);
            case "usa.1": return context.getString(R.string.sports_league_usa);
            case "mex.1": return context.getString(R.string.sports_league_mex);
            case "bra.1": return context.getString(R.string.sports_league_bra);
            case "arg.1": return context.getString(R.string.sports_league_arg);
            case "ind.1": return context.getString(R.string.sports_league_ind);
            case "aus.1": return context.getString(R.string.sports_league_aus);
            case "uefa.champions": return context.getString(R.string.sports_league_uefa_champions);
            default: return context.getString(R.string.sports_league_eng);
        }
    }

    static Country country(Context context) {
        String id = choices(context).getString(COUNTRY_KEY, COUNTRIES[0].id);
        for (Country country : COUNTRIES) {
            if (country.id.equals(id)) return country;
        }
        return COUNTRIES[0];
    }

    static String countryLabel(Context context, Country country) {
        return context.getString(country.labelRes);
    }

    /** The country drives football (its league) and cricket (whose matches come first). World leaves both alone. */
    static void chooseCountry(Context context, Country country) {
        SharedPreferences.Editor edit = choices(context).edit().putString(COUNTRY_KEY, country.id);
        if (country.league != null) edit.putString(FOOTBALL_LEAGUE_KEY, country.league);
        edit.apply();
    }

    /** The chosen sports in the owner's order. */
    static List<String> order(Context context) {
        List<String> order = new ArrayList<>();
        String saved = choices(context).getString(ORDER_KEY, "");
        for (String part : saved.split(",")) {
            if (Arrays.asList(ALL).contains(part) && !order.contains(part)) order.add(part);
        }
        for (String sport : ALL) if (!order.contains(sport)) order.add(sport);
        return order;
    }

    static void moveFirst(Context context, String sport) {
        List<String> order = order(context);
        order.remove(sport);
        order.add(0, sport);
        choices(context).edit().putString(ORDER_KEY, String.join(",", order)).apply();
    }

    static List<Item> items(Context context) {
        List<Item> items = new ArrayList<>();
        if (!enabled(context)) return items;
        SharedPreferences p = cache(context);
        long now = System.currentTimeMillis();
        for (String sport : order(context)) {
            if (!isSportEnabled(context, sport)) continue;
            String headline = p.getString(sport + ".headline", "");
            if (headline.isEmpty()) continue;
            int status = p.getInt(sport + ".status", 0);
            String winner = p.getString(sport + ".winner", "");
            boolean userWin = p.getBoolean(sport + ".userWin", false);
            long startAt = p.getLong(sport + ".startAt", 0L);
            long endedAt = p.getLong(sport + ".endedAt", 0L);
            String detail = p.getString(sport + ".detail", "");
            if (status == STATUS_ENDED && endedAt > 0 && now - endedAt > ENDED_KEEP_MS) {
                // Yesterday's score retires; the winner alone is remembered until the next match starts.
                if (winner.isEmpty()) continue;
                headline = trophyLine(context, winner);
                detail = "";
            }
            items.add(new Item(sport, headline, detail, p.getBoolean(sport + ".live", false),
                    status, winner, userWin, startAt));
        }
        return items;
    }

    /** "🏆 India won" — the trophy line that survives after the full-time score retires. */
    static String trophyLine(Context context, String winner) {
        return "\uD83C\uDFC6 " + winner + " " + context.getString(R.string.sports_won);
    }

    /**
     * The order the cards show: a match in play leads, then a win for the owner's side, then the chosen order.
     * The sort is stable, so everything else keeps the order set in Sports settings.
     */
    static List<Item> leadLive(List<Item> items) {
        List<Item> ordered = new ArrayList<>(items);
        ordered.sort((a, b) -> {
            if (a.live != b.live) return a.live ? -1 : 1;
            if (a.userWin != b.userWin) return a.userWin ? -1 : 1;
            return 0;
        });
        return ordered;
    }

    /** The first chosen score for Control Center, or why there is none. */
    static String summary(Context context) {
        if (!choices(context).getBoolean(MASTER_KEY, true)) return context.getString(R.string.sports_off);
        List<Item> items = leadLive(items(context));
        if (items.isEmpty()) return context.getString(R.string.sports_empty);
        Item item = items.get(0);
        return item.detail.isEmpty() ? item.headline : item.headline + " · " + item.detail;
    }

    static long cachedAt(Context context) {
        return cache(context).getLong("updatedAt", 0L);
    }

    /**
     * True while the cached card holds a chosen sport in play. Only then do the feeds get the faster live
     * cadence; a card of finished or upcoming fixtures stays on the five-minute cache.
     */
    static boolean hasLive(Context context) {
        SharedPreferences p = cache(context);
        for (String sport : ALL) {
            if (isSportEnabled(context, sport) && p.getBoolean(sport + ".live", false)) return true;
        }
        return false;
    }

    static void refresh(Context context, boolean force) {
        final Context app = context.getApplicationContext();
        if (!enabled(app)) return;
        long now = System.currentTimeMillis();
        boolean live = hasLive(app);
        long cacheMs = live ? LIVE_CACHE_MS : CACHE_MS;
        if (!force && now - cachedAt(app) < cacheMs) return;
        long gapMs = live ? LIVE_MIN_GAP_MS : MIN_GAP_MS;
        if (now - lastRequestAt < gapMs || !RUNNING.compareAndSet(false, true)) return;
        lastRequestAt = now;
        WORKER.execute(() -> {
            try {
                SharedPreferences cache = cache(app);
                SharedPreferences.Editor edit = cache.edit();
                for (String sport : order(app)) {
                    if (!isSportEnabled(app, sport)) continue;
                    try {
                        Fetch fetch = sport.equals(FOOTBALL) ? football(app)
                                : sport.equals(CRICKET) ? cricket(app) : formulaOne(app);
                        if (fetch == null) {
                            edit.remove(sport + ".headline").remove(sport + ".detail")
                                    .putBoolean(sport + ".live", false);
                            continue;
                        }
                        Item item = fetch.item;
                        long endedAt = cache.getLong(sport + ".endedAt", 0L);
                        if (!fetch.eventKey.isEmpty()
                                && !fetch.eventKey.equals(cache.getString(sport + ".event", ""))) {
                            endedAt = 0L;   // a new match: the previous result is history
                        }
                        if (item.status == STATUS_ENDED && endedAt == 0L) {
                            endedAt = System.currentTimeMillis();
                        }
                        edit.putString(sport + ".headline", item.headline)
                                .putString(sport + ".detail", item.detail)
                                .putBoolean(sport + ".live", item.live)
                                .putInt(sport + ".status", item.status)
                                .putString(sport + ".winner", item.winner)
                                .putBoolean(sport + ".userWin", item.userWin)
                                .putLong(sport + ".startAt", item.startAt)
                                .putLong(sport + ".endedAt", endedAt)
                                .putString(sport + ".event", fetch.eventKey);
                    } catch (Exception ignored) {
                        // Keep the last good line for this sport; a feed can be briefly unreachable.
                    }
                }
                edit.putLong("updatedAt", System.currentTimeMillis()).apply();
                MAIN.post(() -> app.sendBroadcast(
                        new Intent(ACTION_UPDATED).setPackage(app.getPackageName())));
            } finally {
                RUNNING.set(false);
            }
        });
    }

    private static Fetch football(Context context) throws Exception {
        String slug = league(context);
        JSONObject root = getJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"
                + slug + "/scoreboard");
        JSONArray events = root.optJSONArray("events");
        if (events == null || events.length() == 0) return null;
        JSONObject chosen = null;
        String chosenState = "";
        for (int i = 0; i < events.length(); i++) {
            JSONObject event = events.optJSONObject(i);
            String state = state(event);
            if (chosen == null || rank(state) > rank(chosenState)) {
                chosen = event;
                chosenState = state;
            }
            if ("in".equals(state)) break;
        }
        if (chosen == null) return null;
        String eventKey = chosen.optString("id", "");
        JSONArray competitions = chosen.optJSONArray("competitions");
        JSONObject competition = competitions == null ? null : competitions.optJSONObject(0);
        JSONArray competitors = competition == null ? null : competition.optJSONArray("competitors");
        if (competitors == null) return null;
        String home = "", away = "", homeScore = "", awayScore = "", winner = "";
        for (int i = 0; i < competitors.length(); i++) {
            JSONObject team = competitors.optJSONObject(i);
            if (team == null) continue;
            JSONObject names = team.optJSONObject("team");
            String name = names == null ? "" : names.optString("shortDisplayName",
                    names.optString("displayName", ""));
            if (name.isEmpty()) continue;
            if (team.optBoolean("winner")) winner = name;
            if ("home".equals(team.optString("homeAway"))) {
                home = name;
                homeScore = team.optString("score", "");
            } else {
                away = name;
                awayScore = team.optString("score", "");
            }
        }
        if (home.isEmpty() || away.isEmpty()) return null;
        JSONObject status = chosen.optJSONObject("status");
        JSONObject type = status == null ? null : status.optJSONObject("type");
        String shortDetail = type == null ? "" : type.optString("shortDetail",
                type.optString("detail", ""));
        String state = type == null ? chosenState : type.optString("state", chosenState);
        boolean live = "in".equals(state);
        boolean upcoming = "pre".equals(state);
        long startAt = parseIso(chosen.optString("date", ""));
        String headline = upcoming || homeScore.isEmpty() || awayScore.isEmpty()
                ? home + " v " + away
                : home + " " + homeScore + " – " + awayScore + " " + away;
        String detail = leagueLabel(context, slug);
        if (upcoming && startAt > 0) {
            detail += " · " + formatKickOff(startAt);
        } else if (!shortDetail.isEmpty()) {
            detail += " · " + shortDetail;
        }
        // A decided match in the owner's own league is their win too.
        Country country = country(context);
        boolean userWin = !winner.isEmpty() && country.league != null && country.league.equals(slug);
        int itemStatus = live ? STATUS_LIVE : upcoming ? STATUS_UPCOMING : STATUS_ENDED;
        return new Fetch(new Item(FOOTBALL, headline, detail, live, itemStatus, winner, userWin, startAt),
                eventKey);
    }

    /** "Fri 11 Oct · 21:00" — the kick-off line an upcoming match carries. */
    static String formatKickOff(long startAt) {
        try {
            return java.time.Instant.ofEpochMilli(startAt).atZone(ZoneId.systemDefault())
                    .format(DateTimeFormatter.ofPattern("EEE d MMM · HH:mm", Locale.getDefault()));
        } catch (Exception ignored) {
            return "";
        }
    }

    private static long parseIso(String text) {
        if (text == null || text.isEmpty()) return 0L;
        try {
            return OffsetDateTime.parse(text).toInstant().toEpochMilli();
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private static String state(JSONObject event) {
        JSONObject status = event.optJSONObject("status");
        JSONObject type = status == null ? null : status.optJSONObject("type");
        return type == null ? "" : type.optString("state", "");
    }

    private static int rank(String state) {
        return "in".equals(state) ? 3 : "post".equals(state) ? 2 : "pre".equals(state) ? 1 : 0;
    }

    private static Fetch cricket(Context context) throws Exception {
        String body = getText("https://www.cricbuzz.com/cricket-match/live-scores");
        List<JSONObject> matches = cricketMatches(decodeNextPayload(body));
        if (matches.isEmpty()) matches = cricketMatches(body);
        Country country = country(context);
        JSONObject best = null;
        int bestRank = -1;
        for (JSONObject match : matches) {
            JSONObject info = match.optJSONObject("matchInfo");
            if (info == null) continue;
            String state = info.optString("state", "").toLowerCase(Locale.ROOT);
            boolean live = state.contains("progress") || state.contains("live") || state.contains("break");
            boolean upcoming = state.contains("upcoming") || state.contains("preview");
            boolean home = country.team != null && involves(info, country);
            // A live match from the chosen country beats everything, a live match anywhere comes next.
            int rank = live ? 4 : state.contains("complete") ? 2 : upcoming ? 1 : 0;
            if (home) rank += 3;
            if (rank > bestRank) {
                best = match;
                bestRank = rank;
            }
            if (home && live) break;
        }
        if (best == null) return null;
        JSONObject info = best.optJSONObject("matchInfo");
        if (info == null) return null;
        String eventKey = info.optString("matchId", "");
        long startAt = parseStartDate(info.optString("startDate", ""));
        JSONObject team1 = info.optJSONObject("team1");
        JSONObject team2 = info.optJSONObject("team2");
        String short1 = team1 == null ? "" : team1.optString("teamSName",
                team1.optString("teamName", ""));
        String short2 = team2 == null ? "" : team2.optString("teamSName",
                team2.optString("teamName", ""));
        String status = info.optString("status", "").trim();
        String score = scoreLine(best.optJSONObject("matchScore"), short1, short2);
        String headline = !score.isEmpty() ? score : status;
        if (headline.isEmpty()) return null;
        String desc = info.optString("matchDesc", "");
        String detail = desc;
        String state = info.optString("state", "").toLowerCase(Locale.ROOT);
        boolean live = state.contains("progress") || state.contains("live") || state.contains("break");
        boolean upcoming = state.contains("upcoming") || state.contains("preview");
        boolean ended = state.contains("complete");
        if (!score.isEmpty() && !status.isEmpty()) {
            detail += (detail.isEmpty() ? "" : " · ") + status;
        }
        if (upcoming && startAt > 0) {
            detail += (detail.isEmpty() ? "" : " · ") + formatKickOff(startAt);
        }
        if (detail.isEmpty()) detail = info.optString("seriesName", "");
        // "India won by 7 wickets": the side before " won" took the match.
        String winner = "";
        int wonAt = status.indexOf(" won");
        if (ended && wonAt > 0) winner = status.substring(0, wonAt).trim();
        boolean userWin = !winner.isEmpty() && country.team != null
                && winner.toLowerCase(Locale.ROOT).contains(country.team.toLowerCase(Locale.ROOT));
        int itemStatus = live ? STATUS_LIVE : upcoming ? STATUS_UPCOMING
                : ended ? STATUS_ENDED : 0;
        return new Fetch(new Item(CRICKET, headline, detail, live, itemStatus, winner, userWin, startAt),
                eventKey);
    }

    /** Cricbuzz carries the GMT epoch millis of the first ball as a string. */
    private static long parseStartDate(String text) {
        if (text == null || text.isEmpty()) return 0L;
        try {
            return Long.parseLong(text.trim());
        } catch (Exception ignored) {
            return 0L;
        }
    }

    /**
     * Every match object in a Cricbuzz currentMatchesList, across its type and series groupings. The value is
     * an object, not the match array itself, which the old top-level extraction mistook for one.
     */
    private static List<JSONObject> cricketMatches(String text) {
        List<JSONObject> found = new ArrayList<>();
        JSONObject root = objectAfter(text, "currentMatchesList");
        if (root == null) return found;
        JSONArray types = root.optJSONArray("typeMatches");
        if (types == null) return found;
        for (int i = 0; i < types.length(); i++) {
            JSONObject type = types.optJSONObject(i);
            JSONArray series = type == null ? null : type.optJSONArray("seriesMatches");
            if (series == null) continue;
            for (int j = 0; j < series.length(); j++) {
                JSONObject entry = series.optJSONObject(j);
                JSONObject wrapper = entry == null ? null : entry.optJSONObject("seriesAdWrapper");
                JSONArray matches = wrapper == null ? null : wrapper.optJSONArray("matches");
                if (matches == null) continue;
                for (int k = 0; k < matches.length(); k++) {
                    JSONObject match = matches.optJSONObject(k);
                    if (match != null) found.add(match);
                }
            }
        }
        return found;
    }

    /** True when either side is the chosen country (its full name or its scorecard code). */
    private static boolean involves(JSONObject info, Country country) {
        for (String key : new String[]{"team1", "team2"}) {
            JSONObject team = info.optJSONObject(key);
            if (team == null) continue;
            String name = team.optString("teamName", "").toLowerCase(Locale.ROOT);
            String code = team.optString("teamSName", "");
            if ((!name.isEmpty() && name.contains(country.team.toLowerCase(Locale.ROOT)))
                    || code.equalsIgnoreCase(country.teamCode)) {
                return true;
            }
        }
        return false;
    }

    private static String scoreLine(JSONObject score, String team1, String team2) {
        if (score == null) return "";
        String first = innings(score.optJSONObject("team1Score"));
        String second = innings(score.optJSONObject("team2Score"));
        if (first.isEmpty() && second.isEmpty()) return "";
        if (first.isEmpty()) return team2 + " " + second;
        if (second.isEmpty()) return team1 + " " + first;
        return team1 + " " + first + " · " + team2 + " " + second;
    }

    private static String innings(JSONObject teamScore) {
        if (teamScore == null) return "";
        JSONObject first = teamScore.optJSONObject("inngs1");
        if (first == null) return "";
        int runs = first.optInt("runs", -1);
        if (runs < 0) return "";
        int wickets = first.optInt("wickets", -1);
        String overs = first.optString("overs", "");
        String line = String.valueOf(runs);
        if (wickets >= 0 && wickets < 10) line += "/" + wickets;
        if (!overs.isEmpty()) line += " (" + overs + ")";
        return line;
    }

    private static Fetch formulaOne(Context context) throws Exception {
        JSONObject last = getJson("https://api.jolpi.ca/ergast/f1/current/last/results.json");
        JSONObject race = firstRace(last);
        if (race != null) {
            JSONArray results = race.optJSONArray("Results");
            if (results != null && results.length() > 0) {
                String raceName = race.optString("raceName", "");
                String winner = driverName(results.optJSONObject(0));
                if (!winner.isEmpty()) {
                    String headline = winner + " wins " + raceName;
                    String detail = "";
                    if (results.length() > 1) {
                        String second = driverName(results.optJSONObject(1));
                        if (!second.isEmpty()) detail = "P2 " + second;
                    }
                    if (results.length() > 2) {
                        String third = driverName(results.optJSONObject(2));
                        if (!third.isEmpty()) detail += (detail.isEmpty() ? "" : " · ") + "P3 " + third;
                    }
                    long startAt = parseRaceStart(race);
                    String round = race.optString("round", "");
                    return new Fetch(new Item(F1, headline, detail, false, STATUS_ENDED,
                            winner, false, startAt), "last-" + round);
                }
            }
        }
        JSONObject next = getJson("https://api.jolpi.ca/ergast/f1/current/next.json");
        JSONObject upcoming = firstRace(next);
        if (upcoming == null) return null;
        String raceName = upcoming.optString("raceName", "");
        if (raceName.isEmpty()) return null;
        long startAt = parseRaceStart(upcoming);
        String when = startAt > 0 ? formatKickOff(startAt) : raceDate(upcoming);
        String round = upcoming.optString("round", "");
        return new Fetch(new Item(F1, raceName, when, false, STATUS_UPCOMING, "", false, startAt),
                "next-" + round);
    }

    private static long parseRaceStart(JSONObject race) {
        String date = race.optString("date", "");
        String time = race.optString("time", "");
        if (date.isEmpty()) return 0L;
        try {
            return OffsetDateTime.parse(date + "T" + (time.isEmpty() ? "00:00:00Z" : time))
                    .toInstant().toEpochMilli();
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private static JSONObject firstRace(JSONObject root) {
        JSONObject data = root.optJSONObject("MRData");
        JSONObject table = data == null ? null : data.optJSONObject("RaceTable");
        JSONArray races = table == null ? null : table.optJSONArray("Races");
        return races == null || races.length() == 0 ? null : races.optJSONObject(0);
    }

    private static String driverName(JSONObject result) {
        if (result == null) return "";
        JSONObject driver = result.optJSONObject("Driver");
        if (driver == null) return "";
        String family = driver.optString("familyName", "");
        return family.isEmpty() ? driver.optString("code", "") : family;
    }

    private static String raceDate(JSONObject race) {
        String date = race.optString("date", "");
        String time = race.optString("time", "");
        if (date.isEmpty()) return "";
        try {
            OffsetDateTime at = OffsetDateTime.parse(date + "T" + (time.isEmpty() ? "00:00:00Z" : time));
            return at.atZoneSameInstant(ZoneId.systemDefault())
                    .format(DateTimeFormatter.ofPattern("d MMM · HH:mm"));
        } catch (Exception ignored) {
            return date;
        }
    }

    private static String decodeNextPayload(String body) {
        StringBuilder out = new StringBuilder();
        int from = 0;
        while (true) {
            int at = body.indexOf("self.__next_f.push(", from);
            if (at < 0) break;
            int start = body.indexOf('[', at);
            if (start < 0) break;
            int end = matching(body, start, '[', ']');
            if (end < 0) break;
            try {
                JSONArray chunk = new JSONArray(body.substring(start, end + 1));
                out.append(chunk.optString(1, ""));
            } catch (Exception ignored) {
                // A chunk that is not plain JSON: keep going, another one may hold the matches.
            }
            from = end + 1;
        }
        return out.toString();
    }

    private static JSONArray arrayAfter(String text, String key) {
        if (text == null || text.isEmpty()) return null;
        int at = text.indexOf(key);
        if (at < 0) return null;
        int colon = text.indexOf(':', at + key.length());
        if (colon < 0) return null;
        int start = text.indexOf('[', colon);
        if (start < 0) return null;
        int end = matching(text, start, '[', ']');
        if (end < 0) return null;
        try {
            return new JSONArray(text.substring(start, end + 1));
        } catch (Exception ignored) {
            return null;
        }
    }

    private static JSONObject objectAfter(String text, String key) {
        if (text == null || text.isEmpty()) return null;
        int from = 0;
        while (true) {
            int at = text.indexOf(key, from);
            if (at < 0) return null;
            int colon = text.indexOf(':', at + key.length());
            if (colon < 0) return null;
            int start = text.indexOf('{', colon);
            if (start < 0) return null;
            int end = matching(text, start, '{', '}');
            if (end < 0) return null;
            try {
                return new JSONObject(text.substring(start, end + 1));
            } catch (Exception ignored) {
                from = end + 1;
            }
        }
    }

    /** Index of the bracket that closes the one at openIndex, skipping brackets inside strings. */
    private static int matching(String text, int openIndex, char open, char close) {
        int depth = 0;
        boolean inString = false, escape = false;
        for (int i = openIndex; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (inString) {
                if (escape) escape = false;
                else if (ch == '\\') escape = true;
                else if (ch == '"') inString = false;
                continue;
            }
            if (ch == '"') inString = true;
            else if (ch == open) depth++;
            else if (ch == close && --depth == 0) return i;
        }
        return -1;
    }

    private static JSONObject getJson(String address) throws Exception {
        return new JSONObject(getText(address));
    }

    private static String getText(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(12_000);
        connection.setReadTimeout(12_000);
        connection.setRequestProperty("Accept", "application/json, text/html;q=0.9,*/*;q=0.8");
        connection.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
        connection.setRequestProperty("User-Agent",
                "Mozilla/5.0 (Linux; Android 11; Android TV) AppleWebKit/537.36 "
                        + "(KHTML, like Gecko) Chrome/122.0 Safari/537.36");
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) body.append(line).append('\n');
            return body.toString();
        } finally {
            connection.disconnect();
        }
    }
}
