package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * The apps Home opened, newest first, for the sheet behind Back. Android's own task history is not readable
 * without privileged access, so this is the launcher's own list: apps started any other way (a remote's own
 * Netflix button) are not here.
 */
final class RecentsStore {
    private static final String PREFS = "recent_apps";
    private static final String KEY = "items";
    private static final int LIMIT = 10;

    static final class Entry {
        final String pkg;
        final long at;

        Entry(String pkg, long at) {
            this.pkg = pkg;
            this.at = at;
        }
    }

    private RecentsStore() { }

    static void record(Context context, String pkg) {
        if (pkg == null || pkg.isEmpty() || pkg.equals(context.getPackageName())) return;
        List<Entry> entries = items(context);
        entries.removeIf(entry -> entry.pkg.equals(pkg));
        entries.add(0, new Entry(pkg, System.currentTimeMillis()));
        while (entries.size() > LIMIT) entries.remove(entries.size() - 1);
        JSONArray array = new JSONArray();
        for (Entry entry : entries) {
            try {
                array.put(new JSONObject().put("pkg", entry.pkg).put("at", entry.at));
            } catch (Exception ignored) {
                // Plain strings and longs: nothing to fail, and one bad row must not drop the list.
            }
        }
        prefs(context).edit().putString(KEY, array.toString()).apply();
    }

    static List<Entry> items(Context context) {
        List<Entry> entries = new ArrayList<>();
        String raw = prefs(context).getString(KEY, "");
        if (raw.isEmpty()) return entries;
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject row = array.optJSONObject(i);
                if (row == null) continue;
                String pkg = row.optString("pkg", "");
                if (!pkg.isEmpty()) entries.add(new Entry(pkg, row.optLong("at", 0L)));
            }
        } catch (Exception ignored) {
            // A damaged list reads as empty rather than crashing Home.
        }
        return entries;
    }

    static void clear(Context context) {
        prefs(context).edit().remove(KEY).apply();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
