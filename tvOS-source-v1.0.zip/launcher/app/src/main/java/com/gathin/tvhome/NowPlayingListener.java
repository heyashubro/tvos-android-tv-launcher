package com.gathin.tvhome;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.service.notification.NotificationListenerService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/** Reads active media sessions only after the TV owner grants Notification Access in Android Settings. */
public final class NowPlayingListener extends NotificationListenerService {
    static final String ACTION_UPDATED = "com.gathin.tvhome.NOW_PLAYING_UPDATED";
    static final String ACTION_TOGGLE = "com.gathin.tvhome.NOW_PLAYING_TOGGLE";
    static final String ACTION_NEXT = "com.gathin.tvhome.NOW_PLAYING_NEXT";
    static final String ACTION_PREVIOUS = "com.gathin.tvhome.NOW_PLAYING_PREVIOUS";

    /** Insertion order, so two playing sessions never trade places between readings. */
    private final Map<String, MediaController> controllers = new LinkedHashMap<>();
    private final MediaController.Callback controllerCallback = new MediaController.Callback() {
        @Override public void onPlaybackStateChanged(PlaybackState state) { publishActiveSessions(); }
        @Override public void onMetadataChanged(MediaMetadata metadata) { publishActiveSessions(); }
    };
    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsChanged = this::attachControllers;
    private MediaSessionManager manager;
    private MediaController selected;
    private String lastSignature;

    /** Sends a transport command through this service, which holds the session controllers. */
    static void sendCommand(Context context, String action) {
        try {
            context.startService(new Intent(context, NowPlayingListener.class).setAction(action));
        } catch (Exception ignored) { }   // background-start limits; the TV is on Home when this runs
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) runCommand(intent.getAction());
        return START_NOT_STICKY;
    }

    private void runCommand(String action) {
        try {
            MediaController controller = selected != null ? selected : pickSession();
            MediaController.TransportControls controls = controller == null ? null : controller.getTransportControls();
            if (controls == null) return;
            if (ACTION_TOGGLE.equals(action)) {
                PlaybackState state = controller.getPlaybackState();
                if (state != null && state.getState() == PlaybackState.STATE_PLAYING) controls.pause();
                else controls.play();
            } else if (ACTION_NEXT.equals(action)) {
                controls.skipToNext();
            } else if (ACTION_PREVIOUS.equals(action)) {
                controls.skipToPrevious();
            }
        } catch (SecurityException | IllegalStateException | IllegalArgumentException ignored) { }
        finally { stopSelf(); }   // the system still keeps the notification listener bound
    }

    @Override public void onListenerConnected() {
        super.onListenerConnected();
        manager = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
        if (manager == null) return;
        ComponentName component = new ComponentName(this, NowPlayingListener.class);
        manager.addOnActiveSessionsChangedListener(sessionsChanged, component);
        attachControllers(manager.getActiveSessions(component));
    }

    private void attachControllers(java.util.List<MediaController> active) {
        for (MediaController controller : new ArrayList<>(controllers.values())) {
            try { controller.unregisterCallback(controllerCallback); } catch (Exception ignored) { }
        }
        controllers.clear();
        if (active != null) for (MediaController controller : active) {
            controllers.put(controller.getSessionToken().toString(), controller);
            controller.registerCallback(controllerCallback);
        }
        publishActiveSessions();
    }

    /**
     * Playing beats buffering, which beats paused, so the card stays usable while paused. Within one class the
     * session that reported the newest position wins: a TV can hold a stale playing session (the Live TV app
     * that never stops) next to the one that just changed track, and picking the first found left the card on
     * the old song's artwork.
     */
    private MediaController pickSession() {
        MediaController playing = null, buffering = null, paused = null;
        long playingAt = -1, bufferingAt = -1, pausedAt = -1;
        for (MediaController controller : controllers.values()) {
            PlaybackState state = controller.getPlaybackState();
            MediaMetadata metadata = controller.getMetadata();
            if (state == null || metadata == null
                    || safe(metadata.getString(MediaMetadata.METADATA_KEY_TITLE)).isEmpty()) continue;
            long fresh = state.getLastPositionUpdateTime();
            int status = state.getState();
            if (status == PlaybackState.STATE_PLAYING) {
                if (playing == null || fresh > playingAt) { playing = controller; playingAt = fresh; }
            } else if (status == PlaybackState.STATE_BUFFERING) {
                if (buffering == null || fresh > bufferingAt) { buffering = controller; bufferingAt = fresh; }
            } else if (status == PlaybackState.STATE_PAUSED) {
                if (paused == null || fresh > pausedAt) { paused = controller; pausedAt = fresh; }
            }
        }
        return playing != null ? playing : buffering != null ? buffering : paused;
    }

    private void publishActiveSessions() {
        MediaController controller = pickSession();
        selected = controller;
        MediaMetadata metadata = controller == null ? null : controller.getMetadata();
        PlaybackState state = controller == null ? null : controller.getPlaybackState();
        String title = metadata == null ? "" : safe(metadata.getString(MediaMetadata.METADATA_KEY_TITLE));
        String artist = metadata == null ? "" : safe(metadata.getString(MediaMetadata.METADATA_KEY_ARTIST));
        if (artist.isEmpty() && metadata != null) artist = safe(metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST));
        if (artist.isEmpty() && metadata != null) artist = safe(metadata.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE));
        String packageName = controller == null ? "" : controller.getPackageName();
        boolean playing = state != null && state.getState() == PlaybackState.STATE_PLAYING;
        long position = state == null ? 0 : Math.max(0, state.getPosition());
        float speed = state == null ? 0 : state.getPlaybackSpeed();
        long updatedAt = state == null ? 0 : state.getLastPositionUpdateTime();
        long duration = metadata == null ? 0 : Math.max(0, metadata.getLong(MediaMetadata.METADATA_KEY_DURATION));

        SharedPreferences prefs = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        String previousTitle = prefs.getString(Config.NOW_PLAYING_TITLE_KEY, "");
        String previousPackage = prefs.getString(Config.NOW_PLAYING_PACKAGE_KEY, "");
        String previousMediaId = prefs.getString(Config.NOW_PLAYING_MEDIA_ID_KEY, "");
        int artVersion = prefs.getInt(Config.NOW_PLAYING_ART_VERSION_KEY, 0);
        String mediaId = metadata == null ? "" : safe(metadata.getString(MediaMetadata.METADATA_KEY_MEDIA_ID));
        boolean trackChanged = !title.equals(previousTitle) || !packageName.equals(previousPackage)
                || (!mediaId.isEmpty() && !mediaId.equals(previousMediaId));
        // Some apps publish the new title first and the artwork one metadata change later: without this the
        // card kept the previous cover until the next track.
        boolean artArrivedLate = controller != null && !trackChanged && !NowPlayingArt.exists(this)
                && NowPlayingArt.hasBitmap(metadata);
        if (controller != null && (trackChanged || artArrivedLate)) {
            // A new track: replace or clear the cached art in the same step as the new metadata.
            if (!NowPlayingArt.save(this, metadata)) NowPlayingArt.delete(this);
            artVersion++;
        } else if (controller == null && !previousTitle.isEmpty()) {
            NowPlayingArt.delete(this);
            artVersion++;
        }

        String signature = title + '\n' + artist + '\n' + packageName + '\n' + playing + '\n' + position
                + '\n' + duration + '\n' + speed + '\n' + updatedAt + '\n' + artVersion;
        if (signature.equals(lastSignature)) return;   // a notification from another app, not playback
        lastSignature = signature;
        prefs.edit()
                .putString(Config.NOW_PLAYING_TITLE_KEY, title)
                .putString(Config.NOW_PLAYING_ARTIST_KEY, artist)
                .putString(Config.NOW_PLAYING_PACKAGE_KEY, packageName)
                .putString(Config.NOW_PLAYING_MEDIA_ID_KEY, mediaId)
                .putBoolean(Config.NOW_PLAYING_PLAYING_KEY, playing)
                .putLong(Config.NOW_PLAYING_POSITION_KEY, position)
                .putLong(Config.NOW_PLAYING_DURATION_KEY, duration)
                .putFloat(Config.NOW_PLAYING_SPEED_KEY, speed)
                .putLong(Config.NOW_PLAYING_UPDATED_AT_KEY, updatedAt)
                .putInt(Config.NOW_PLAYING_ART_VERSION_KEY, artVersion).apply();
        sendBroadcast(new Intent(ACTION_UPDATED).setPackage(getPackageName()));
    }

    private static String safe(String value) { return value == null ? "" : value.trim(); }

    @Override public void onNotificationPosted(android.service.notification.StatusBarNotification notification) {
        publishActiveSessions();
    }

    @Override public void onNotificationRemoved(android.service.notification.StatusBarNotification notification) {
        publishActiveSessions();
    }

    @Override public void onListenerDisconnected() {
        if (manager != null) {
            try { manager.removeOnActiveSessionsChangedListener(sessionsChanged); } catch (Exception ignored) { }
        }
        attachControllers(null);
        manager = null;
        super.onListenerDisconnected();
    }

    @Override public void onDestroy() {
        if (manager != null) {
            try { manager.removeOnActiveSessionsChangedListener(sessionsChanged); } catch (Exception ignored) { }
        }
        for (MediaController controller : controllers.values()) {
            try { controller.unregisterCallback(controllerCallback); } catch (Exception ignored) { }
        }
        controllers.clear();
        super.onDestroy();
    }
}
