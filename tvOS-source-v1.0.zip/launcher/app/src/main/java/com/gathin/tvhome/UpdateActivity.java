package com.gathin.tvhome;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

/** Launcher settings, About: this build against the project's latest GitHub release. */
public final class UpdateActivity extends LauncherActivity {

    private TextView status;
    private TextView latest;
    private TextView checkButton;
    private TextView releaseButton;
    private String releaseUrl;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_update);
        status = findViewById(R.id.updateStatus);
        latest = findViewById(R.id.updateLatest);
        checkButton = findViewById(R.id.updateCheckButton);
        releaseButton = findViewById(R.id.updateReleaseButton);
        ((TextView) findViewById(R.id.updateBuild)).setText(getString(
                R.string.update_current, versionName(), versionCode()));
        checkButton.setOnClickListener(v -> check());
        releaseButton.setOnClickListener(v -> openRelease());
        check();
        checkButton.post(checkButton::requestFocus);
    }

    private void check() {
        status.setText(R.string.update_checking);
        latest.setText("");
        releaseUrl = null;
        releaseButton.setVisibility(View.GONE);
        UpdateChecker.check(this, new UpdateChecker.Listener() {
            @Override public void onChecked(String tag, String url, Integer upstreamVersionCode) {
                releaseUrl = url;
                latest.setText(getString(R.string.update_latest, tag));
                boolean newer = upstreamVersionCode != null && upstreamVersionCode > versionCode();
                status.setText(newer ? getString(R.string.update_available, tag)
                        : getString(R.string.update_up_to_date));
                releaseButton.setVisibility(View.VISIBLE);
                releaseButton.requestFocus();
            }

            @Override public void onFailed() {
                status.setText(R.string.update_failed);
                checkButton.requestFocus();
            }
        });
    }

    private void openRelease() {
        if (releaseUrl == null) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(releaseUrl)));
        } catch (ActivityNotFoundException | SecurityException missing) {
            Toast.makeText(this, R.string.not_available, Toast.LENGTH_LONG).show();
        }
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "";
        }
    }

    private int versionCode() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            return android.os.Build.VERSION.SDK_INT >= 28 ? (int) info.getLongVersionCode() : info.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            return 0;
        }
    }
}
