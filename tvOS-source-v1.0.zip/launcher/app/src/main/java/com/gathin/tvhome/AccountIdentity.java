package com.gathin.tvhome;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;

import java.util.Locale;

/**
 * The account signed in to the TV: its email, a display name taken from the address, and a profile picture
 * drawn from the address (initial on a colour of its own). Android has no public API for the account's real
 * Google photo, so the launcher paints an identity avatar instead of showing a generic silhouette.
 */
final class AccountIdentity {

    private static final int[] COLORS = {
            0xFF5B8DEF, 0xFFEF6C57, 0xFF3FB59A, 0xFF9B6DD6, 0xFFE0A03C, 0xFFD95D95, 0xFF3AA7C9,
    };

    private static boolean looked;
    private static String cached;

    private AccountIdentity() { }

    /** The primary signed-in email, or null when the TV has no account the launcher can read. */
    static String email(Context context) {
        if (!looked) {
            cached = readEmail(context);
            looked = true;
        }
        return cached;
    }

    private static String readEmail(Context context) {
        try {
            AccountManager manager = AccountManager.get(context);
            String email = firstEmail(manager.getAccountsByType("com.google"));
            if (email == null) email = firstEmail(manager.getAccounts());
            return email;
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static String firstEmail(Account[] accounts) {
        if (accounts == null) return null;
        for (Account account : accounts) {
            String name = account == null ? null : account.name;
            if (name == null) continue;
            name = name.trim();
            if (name.indexOf('@') > 0 && !name.endsWith("@android")) return name;
        }
        return null;
    }

    /** "john.doe1985@gmail.com" → "John Doe1985": the local part, readable and capitalized. */
    static String name(String email) {
        if (email == null) return null;
        int at = email.indexOf('@');
        String local = at > 0 ? email.substring(0, at) : email;
        int plus = local.indexOf('+');
        if (plus > 0) local = local.substring(0, plus);
        StringBuilder name = new StringBuilder();
        for (String part : local.split("[._\\-\\s]+")) {
            if (part.isEmpty()) continue;
            if (name.length() > 0) name.append(' ');
            name.append(Character.toUpperCase(part.charAt(0)));
            if (part.length() > 1) name.append(part.substring(1));
        }
        String result = name.toString().trim();
        if (result.isEmpty()) return null;
        return result.length() > 24 ? result.substring(0, 24) : result;
    }

    /** The letter (or two) in the middle of the generated picture. */
    static String initials(String email) {
        String display = name(email);
        if (display == null) return "?";
        String[] words = display.split(" ");
        String first = words.length > 0 && !words[0].isEmpty() ? words[0].substring(0, 1) : "?";
        String second = words.length > 1 && !words[1].isEmpty() ? words[1].substring(0, 1) : "";
        return (first + second).toUpperCase(Locale.ROOT);
    }

    /** The picture for this email; the neutral silhouette when there is no account. */
    static Drawable avatar(Context context) {
        String email = email(context);
        if (TextUtils.isEmpty(email)) return context.getDrawable(R.drawable.profile_avatar_default);
        return new InitialsAvatar(email);
    }

    /** A round gradient avatar with the account's initials, drawn at whatever size the view gives it. */
    static final class InitialsAvatar extends Drawable {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final String initials;
        private final int base;

        InitialsAvatar(String email) {
            initials = initials(email);
            base = COLORS[Math.floorMod(email.toLowerCase(Locale.ROOT).hashCode(), COLORS.length)];
            ink.setColor(0xFFFFFFFF);
            ink.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            ink.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        public void draw(Canvas canvas) {
            Rect b = getBounds();
            float size = Math.min(b.width(), b.height());
            if (size <= 0) return;
            float cx = b.exactCenterX(), cy = b.exactCenterY(), radius = size / 2f;
            fill.setShader(new LinearGradient(cx, cy - radius, cx, cy + radius, lighten(base), base,
                    Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, radius, fill);

            float textSize = size * (initials.length() > 1 ? 0.38f : 0.46f);
            ink.setTextSize(textSize);
            float widest = ink.measureText(initials);
            float limit = size * 0.74f;
            if (widest > limit) {
                ink.setTextSize(textSize * limit / widest);
            }
            Paint.FontMetrics fm = ink.getFontMetrics();
            canvas.drawText(initials, cx, cy - (fm.ascent + fm.descent) / 2f, ink);
        }

        private static int lighten(int color) {
            float amount = 0.22f;
            int r = Math.round(Color.red(color) + (255 - Color.red(color)) * amount);
            int g = Math.round(Color.green(color) + (255 - Color.green(color)) * amount);
            int b = Math.round(Color.blue(color) + (255 - Color.blue(color)) * amount);
            return Color.rgb(r, g, b);
        }

        @Override public void setAlpha(int alpha) {}
        @Override public void setColorFilter(ColorFilter colorFilter) {}
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
