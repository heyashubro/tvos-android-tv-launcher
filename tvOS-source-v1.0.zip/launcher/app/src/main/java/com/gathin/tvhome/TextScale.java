package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;

/**
 * The seven Text Size steps. The launcher multiplies the TV's own font scale by the chosen factor, so a
 * household that already enlarged the system UI keeps that reach while it tunes this screen further.
 */
final class TextScale {
    static final int DEFAULT_STEP = 2;
    static final int STEPS = 7;
    static final float[] FACTORS = {0.85f, 0.925f, 1.0f, 1.075f, 1.15f, 1.225f, 1.3f};
    static final String KEY = "text_scale";

    private TextScale() {}

    static int clamp(int step) {
        return Math.max(0, Math.min(FACTORS.length - 1, step));
    }

    static int step(SharedPreferences prefs) {
        return clamp(prefs.getInt(KEY, DEFAULT_STEP));
    }

    static int step(Context context) {
        return step(context.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE));
    }

    static float factor(int step) {
        return FACTORS[clamp(step)];
    }

    static float factor(Context context) {
        return factor(step(context));
    }

    static float factor(SharedPreferences prefs) {
        return factor(step(prefs));
    }

    static void setStep(SharedPreferences prefs, int step) {
        prefs.edit().putInt(KEY, clamp(step)).apply();
    }

    static int percent(int step) {
        return Math.round(FACTORS[clamp(step)] * 100f);
    }

    /** The same context with sp values scaled, used by every launcher screen that follows Text Size. */
    static Context wrap(Context base) {
        if (base == null) return null;
        Configuration config = new Configuration(base.getResources().getConfiguration());
        config.fontScale = config.fontScale * factor(base);
        return base.createConfigurationContext(config);
    }
}
