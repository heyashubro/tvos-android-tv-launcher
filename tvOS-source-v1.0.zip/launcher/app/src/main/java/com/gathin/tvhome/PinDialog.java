package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * The remote-friendly four-digit PIN keypad for Parental controls. Digits are large focusable keys, the row of dots
 * shows what has been typed, and the last digit checks the PIN: a rejected one clears the entry and shows the
 * caller's message, an accepted one closes the dialog.
 */
final class PinDialog {

    interface Entry {
        /** True closes the dialog; false keeps it open for another try. */
        boolean onPin(String pin);
    }

    private PinDialog() { }

    static void enter(Activity activity, CharSequence title, int errorRes, Entry entry) {
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(activity, 24), dp(activity, 6), dp(activity, 24), dp(activity, 2));
        int width = dp(activity, 300);
        root.setMinimumWidth(width);

        TextView dots = new TextView(activity);
        dots.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        dots.setLetterSpacing(0.28f);
        dots.setGravity(Gravity.CENTER);
        dots.setTextColor(0xFFFFFFFF);
        dots.setText("○○○○");
        root.addView(dots);

        TextView error = new TextView(activity);
        error.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        error.setGravity(Gravity.CENTER);
        error.setTextColor(0xFFFFA24C);
        LinearLayout.LayoutParams errorParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(activity, 24));
        errorParams.topMargin = dp(activity, 4);
        root.addView(error, errorParams);

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(title)
                .setView(root)
                .setNegativeButton(android.R.string.cancel, null)
                .create();

        StringBuilder typed = new StringBuilder();
        TextView[] first = new TextView[1];
        String[] keys = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", activity.getString(R.string.parental_delete)};
        for (int row = 0; row < 4; row++) {
            LinearLayout line = new LinearLayout(activity);
            line.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            if (row > 0) lineParams.topMargin = dp(activity, 6);
            root.addView(line, lineParams);
            for (int col = 0; col < 3; col++) {
                String label = keys[row * 3 + col];
                if (label.isEmpty()) {
                    View spacer = new View(activity);
                    line.addView(spacer, newKeyParams(activity));
                    continue;
                }
                TextView key = new TextView(activity);
                key.setText(label);
                key.setTextSize(TypedValue.COMPLEX_UNIT_SP, label.length() > 1 ? 15 : 22);
                key.setTypeface(UiFont.get(activity, R.string.font_semibold));
                key.setGravity(Gravity.CENTER);
                key.setFocusable(true);
                key.setClickable(true);
                key.setBackground(keyBackground(activity));
                key.setTextColor(keyColors());
                line.addView(key, newKeyParams(activity));
                if (first[0] == null) first[0] = key;
                boolean delete = label.length() > 1;
                key.setOnClickListener(v -> {
                    if (delete) {
                        if (typed.length() > 0) typed.setLength(typed.length() - 1);
                    } else if (typed.length() < 4) {
                        typed.append(label);
                    }
                    dots.setText(dots(typed.length()));
                    error.setText("");
                    if (typed.length() == 4) {
                        String pin = typed.toString();
                        if (entry.onPin(pin)) {
                            dialog.dismiss();
                        } else {
                            typed.setLength(0);
                            dots.setText(dots(0));
                            error.setText(errorRes);
                        }
                    }
                });
            }
        }

        dialog.setOnShowListener(shown -> {
            if (first[0] != null) first[0].requestFocus();
        });
        dialog.show();
    }

    /** Set a new PIN: type it once, then again to confirm; a mismatch keeps the confirmation open. */
    static void setPin(Activity activity, Runnable done) {
        enter(activity, activity.getString(R.string.parental_set_pin), R.string.parental_wrong_pin, pin -> {
            activity.getWindow().getDecorView().post(() -> enter(activity,
                    activity.getString(R.string.parental_confirm_pin), R.string.parental_pin_mismatch, again -> {
                        if (!again.equals(pin)) return false;
                        ParentalControls.setPin(activity, pin);
                        done.run();
                        return true;
                    }));
            return true;
        });
    }

    private static LinearLayout.LayoutParams newKeyParams(Activity activity) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(activity, 50), 1f);
        params.setMarginStart(dp(activity, 4));
        params.setMarginEnd(dp(activity, 4));
        return params;
    }

    private static String dots(int filled) {
        StringBuilder text = new StringBuilder(4);
        for (int i = 0; i < 4; i++) text.append(i < filled ? '●' : '○');
        return text.toString();
    }

    private static ColorStateList keyColors() {
        return new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_focused}, new int[]{}},
                new int[]{0xFF101014, 0xFFFFFFFF});
    }

    private static StateListDrawable keyBackground(Activity activity) {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_focused}, rounded(0xFFFFFFFF, activity));
        states.addState(new int[]{}, rounded(0x33FFFFFF, activity));
        return states;
    }

    private static GradientDrawable rounded(int color, Activity activity) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(activity, 12));
        return shape;
    }

    private static int dp(Activity activity, int value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }
}
