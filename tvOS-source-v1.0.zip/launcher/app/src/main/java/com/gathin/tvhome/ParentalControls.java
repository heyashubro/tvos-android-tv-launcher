package com.gathin.tvhome;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Parental controls: a four-digit PIN and the apps that ask for it before they open. The PIN is kept as a salted
 * SHA-256 hash in its own preferences file, so it is not part of a profile, a guest session or a theme reset.
 */
final class ParentalControls {

    private static final String PREFS = "parental_controls";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_HASH = "pin_hash";
    private static final String KEY_SALT = "pin_salt";
    private static final String KEY_LOCKED = "locked_apps";

    private ParentalControls() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean hasPin(Context context) {
        String hash = prefs(context).getString(KEY_HASH, null);
        return hash != null && !hash.isEmpty();
    }

    /** App lock needs both the switch and a PIN to mean anything. */
    static boolean enabled(Context context) {
        return prefs(context).getBoolean(KEY_ENABLED, false) && hasPin(context);
    }

    static void setEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    static void setPin(Context context, String pin) {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        String saltText = Base64.encodeToString(salt, Base64.NO_WRAP);
        prefs(context).edit().putString(KEY_SALT, saltText)
                .putString(KEY_HASH, hash(saltText, pin)).apply();
    }

    static boolean checkPin(Context context, String pin) {
        String salt = prefs(context).getString(KEY_SALT, "");
        String hash = prefs(context).getString(KEY_HASH, "");
        if (pin == null || hash.isEmpty()) return false;
        return MessageDigest.isEqual(hash.getBytes(StandardCharsets.UTF_8),
                hash(salt, pin).getBytes(StandardCharsets.UTF_8));
    }

    static Set<String> locked(Context context) {
        return new HashSet<>(prefs(context).getStringSet(KEY_LOCKED, Collections.emptySet()));
    }

    static void setLocked(Context context, Set<String> packages) {
        prefs(context).edit().putStringSet(KEY_LOCKED, new HashSet<>(packages)).apply();
    }

    static boolean isLocked(Context context, String pkg) {
        return pkg != null && enabled(context) && locked(context).contains(pkg);
    }

    /** Asks for the PIN before a sensitive settings change; no PIN means there is nothing to prove yet. */
    static void verify(Activity activity, Runnable then) {
        if (!hasPin(activity)) {
            then.run();
            return;
        }
        PinDialog.enter(activity, activity.getString(R.string.parental_enter_pin), R.string.parental_wrong_pin,
                pin -> {
                    if (!checkPin(activity, pin)) return false;
                    then.run();
                    return true;
                });
    }

    /**
     * The launch gate. False means the app is not locked and the caller may open it now; true means a PIN dialog
     * went up instead and {@code then} opens it after the right PIN.
     */
    static boolean gate(Activity activity, String pkg, CharSequence label, Runnable then) {
        if (!isLocked(activity, pkg)) return false;
        PinDialog.enter(activity, activity.getString(R.string.parental_unlock_title, label),
                R.string.parental_wrong_pin, pin -> {
                    if (!checkPin(activity, pin)) return false;
                    then.run();
                    return true;
                });
        return true;
    }

    private static String hash(String salt, String pin) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] out = digest.digest((salt + ":" + pin).getBytes(StandardCharsets.UTF_8));
            StringBuilder text = new StringBuilder(out.length * 2);
            for (byte b : out) text.append(String.format("%02x", b));
            return text.toString();
        } catch (NoSuchAlgorithmException impossible) {
            return "";
        }
    }
}
