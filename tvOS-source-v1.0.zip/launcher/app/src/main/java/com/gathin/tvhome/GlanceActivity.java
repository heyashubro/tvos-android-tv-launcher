package com.gathin.tvhome;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

/** Full-screen local-photo glance shown only after Home has been idle for the owner's chosen delay. */
public final class GlanceActivity extends Activity {
    private GlanceScene scene;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.glance);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        scene = new GlanceScene(this, findViewById(R.id.glanceWallpaper));
    }

    @Override protected void onResume() {
        super.onResume();
        scene.start();
    }

    @Override protected void onPause() {
        scene.stop();
        super.onPause();
        finish();
    }

    @Override protected void onDestroy() {
        if (scene != null) scene.close();
        super.onDestroy();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_UP) finish();
        return true;
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) finish();
        return true;
    }

    @Override public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}
