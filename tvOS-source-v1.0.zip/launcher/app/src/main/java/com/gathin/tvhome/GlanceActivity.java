package com.gathin.tvhome;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

/** Full-screen local-photo glance shown only after Home has been idle for the owner's chosen delay. */
public final class GlanceActivity extends Activity {
    private GlanceScene scene;
    private ImageView playingArt;
    private ImageView playingPlaceholder;
    private Bitmap artBitmap;
    /** Artwork version on screen, -1 for none yet. */
    private int artShown = -1;
    private final IntentFilter statusFilter = new IntentFilter();
    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { updateStatus(); }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.glance);
        // Guarantee an opaque window even where an OEM theme leaves the system background translucent;
        // otherwise Home's app grid could show through the glance.
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.BLACK));
        getWindow().getDecorView().setBackgroundColor(android.graphics.Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        scene = new GlanceScene(this, findViewById(R.id.glanceWallpaper));
        playingArt = findViewById(R.id.glanceNowPlayingArt);
        playingPlaceholder = findViewById(R.id.glanceNowPlayingPlaceholder);
        applyClock();
        statusFilter.addAction(NowPlayingListener.ACTION_UPDATED);
        statusFilter.addAction(SportsRepository.ACTION_UPDATED);
        updateStatus();
    }

    /**
     * Launcher settings, Glance: the clock's style, size and font, and Clock glass, the frosted card behind the
     * time and date. The sizes are the big hero clock the Glance is built around, scaled from its 152sp base.
     */
    private void applyClock() {
        SharedPreferences prefs = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        TextClock hour = findViewById(R.id.glanceHour);
        TextClock minute = findViewById(R.id.glanceMinute);
        TextClock amPm = findViewById(R.id.glanceAmPm);
        View colon = findViewById(R.id.glanceColon);
        LinearLayout block = findViewById(R.id.glanceClockBlock);
        LinearLayout dateRow = findViewById(R.id.glanceDateRow);

        int[] sizes = {112, 152, 188, 216};
        int index = Math.max(0, Math.min(prefs.getInt(Config.GLANCE_CLOCK_SIZE_KEY, 1), sizes.length - 1));
        int sp = sizes[index];
        hour.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        minute.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        float scale = sp / 152f;
        LinearLayout.LayoutParams colonParams = (LinearLayout.LayoutParams) colon.getLayoutParams();
        colonParams.width = dp(Math.round(36 * scale));
        colonParams.height = dp(Math.round(152 * scale));
        colon.setLayoutParams(colonParams);
        amPm.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28 * scale);
        LinearLayout.LayoutParams pmParams = (LinearLayout.LayoutParams) amPm.getLayoutParams();
        pmParams.setMarginStart(dp(Math.round(14 * scale)));
        amPm.setLayoutParams(pmParams);

        Typeface face = UiFont.get(this, fontRes(prefs.getString(Config.GLANCE_CLOCK_FONT_KEY, "bold")));
        hour.setTypeface(face);
        minute.setTypeface(face);
        amPm.setTypeface(face);

        String style = prefs.getString(Config.GLANCE_CLOCK_STYLE_KEY, "hero");
        dateRow.setVisibility("minimal".equals(style) ? View.GONE : View.VISIBLE);
        if ("stacked".equals(style)) {
            block.removeView(dateRow);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.bottomMargin = dp(10);
            block.addView(dateRow, 0, params);
        }

        if (!prefs.getBoolean(Config.GLANCE_CLOCK_GLASS_KEY, false)) {
            plainGlyphs(hour, 0xB8FFFFFF);
            plainGlyphs(minute, 0xB8FFFFFF);
            plainGlyphs(amPm, 0x88FFFFFF);
            return;
        }
        // The HomePod way: the digits themselves are the glass, so no card is needed behind them. The
        // transparency level decides how much of the wallpaper shows through the middle of each glyph.
        int level = Math.max(0, Math.min(
                prefs.getInt(Config.GLANCE_CLOCK_GLASS_LEVEL_KEY, 1), GLASS_LEVELS.length - 1));
        glassGlyph(hour, 0xB8FFFFFF, level);
        glassGlyph(minute, 0xB8FFFFFF, level);
        glassGlyph(amPm, 0x88FFFFFF, level);
    }

    private static final int[][] GLASS_LEVELS = {
            {0x00FFFFFF, 0x0DFFFFFF, 0x1AFFFFFF},     // Crystal: almost empty glass
            {0x0DFFFFFF, 0x33FFFFFF, 0x4DFFFFFF},     // Frosted (default)
            {0x1AFFFFFF, 0x66FFFFFF, 0x80FFFFFF},     // Deep
            {0x33FFFFFF, 0x99FFFFFF, 0xB3FFFFFF},     // Solid
    };

    /** A glyph filled with a vertical light gradient: bright edge, clear body, light bouncing back below. */
    private void glassGlyph(TextView view, int baseColor, int level) {
        view.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        view.setShadowLayer(16f, 0f, 1f, 0x4DFFFFFF);
        int[] tints = GLASS_LEVELS[level];
        int[] colors = {
                blend(baseColor, tints[2]),
                blend(baseColor, tints[1]),
                blend(baseColor, tints[0]),
                blend(baseColor, tints[2]),
        };
        view.post(() -> {
            float height = view.getHeight() > 0 ? view.getHeight() : view.getTextSize();
            view.getPaint().setShader(new android.graphics.LinearGradient(0f, 0f, 0f, height,
                    colors, new float[]{0f, 0.42f, 0.72f, 1f}, android.graphics.Shader.TileMode.CLAMP));
            view.invalidate();
        });
    }

    private void plainGlyphs(TextView view, int color) {
        view.setLayerType(View.LAYER_TYPE_NONE, null);
        view.setShadowLayer(11f, 0f, 0f, 0xA8FFFFFF);
        view.getPaint().setShader(null);
        view.setTextColor(color);
    }

    /** The gradient tints are white veils over the glyph's own colour. */
    private int blend(int base, int veil) {
        int a = Math.min(255, (base >>> 24) + (veil >>> 24));
        int r = Math.min(255, ((base >> 16) & 0xFF) + ((veil >> 16) & 0xFF));
        int g = Math.min(255, ((base >> 8) & 0xFF) + ((veil >> 8) & 0xFF));
        int b = Math.min(255, (base & 0xFF) + (veil & 0xFF));
        return a << 24 | r << 16 | g << 8 | b;
    }

    /** The font_* string behind each Clock font choice. */
    private int fontRes(String font) {
        if ("semibold".equals(font)) return R.string.font_semibold;
        if ("regular".equals(font)) return R.string.font_regular;
        if ("light".equals(font)) return R.string.font_light;
        return R.string.font_bold;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    /** Glance sits over Home, whose own tickers are paused: it re-reads the feeds itself, once a minute. */
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable statusTick = new Runnable() {
        @Override public void run() {
            SportsRepository.refresh(GlanceActivity.this, false);
            updateStatus();
            handler.postDelayed(this, 60_000L);
        }
    };

    private void updateStatus() {
        android.content.SharedPreferences prefs = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        updateSportsLine();

        View playing = findViewById(R.id.glanceNowPlaying);
        String title = prefs.getBoolean(Config.NOW_PLAYING_ENABLED_KEY, false)
                && prefs.getBoolean(Config.GLANCE_SHOW_NOW_PLAYING_KEY, true)
                ? prefs.getString(Config.NOW_PLAYING_TITLE_KEY, "") : "";
        if (title.isEmpty()) {
            playing.setVisibility(View.GONE);
            clearArt();
            return;
        }
        String artist = prefs.getString(Config.NOW_PLAYING_ARTIST_KEY, "");
        ((TextView) findViewById(R.id.glanceNowPlayingTitle)).setText(title);
        TextView artistView = findViewById(R.id.glanceNowPlayingArtist);
        artistView.setText(artist);
        artistView.setVisibility(artist.isEmpty() ? View.GONE : View.VISIBLE);
        int artVersion = prefs.getInt(Config.NOW_PLAYING_ART_VERSION_KEY, 0);
        if (artVersion != artShown) {
            clearArt();
            artShown = artVersion;
            artBitmap = NowPlayingArt.load(this);
            playingArt.setImageBitmap(artBitmap);
            playingPlaceholder.setVisibility(artBitmap == null ? View.VISIBLE : View.GONE);
        }
        playing.setVisibility(View.VISIBLE);
        GlassEffect.apply(playing, GlassEffect.level(this));
    }

    /** The first cached score line, under Now Playing; hidden while there is nothing to show. */
    private void updateSportsLine() {
        View card = findViewById(R.id.glanceSports);
        if (card == null) return;
        java.util.List<SportsRepository.Item> items = SportsRepository.leadLive(SportsRepository.items(this));
        if (items.isEmpty()) {
            card.setVisibility(View.GONE);
            return;
        }
        SportsRepository.Item item = items.get(0);
        ((ImageView) findViewById(R.id.glanceSportsIcon)).setImageResource(SportsRepository.iconFor(item.sport));
        ((TextView) findViewById(R.id.glanceSportsHeadline)).setText(item.headline);
        TextView detail = findViewById(R.id.glanceSportsDetail);
        detail.setText(item.detail);
        detail.setVisibility(item.detail.isEmpty() ? View.GONE : View.VISIBLE);
        card.setVisibility(View.VISIBLE);
        GlassEffect.apply(card, GlassEffect.level(this));
    }

    private void clearArt() {
        if (artBitmap != null) {
            playingArt.setImageDrawable(null);
            artBitmap.recycle();
            artBitmap = null;
        }
        artShown = -1;
        playingPlaceholder.setVisibility(View.VISIBLE);
    }

    // The flagged overload only exists from 33; both broadcasts are sent with setPackage(this app).
    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    @Override protected void onStart() {
        super.onStart();
        if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(statusReceiver, statusFilter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(statusReceiver, statusFilter);
        updateStatus();
    }

    @Override protected void onStop() {
        try { unregisterReceiver(statusReceiver); } catch (IllegalArgumentException ignored) { }
        super.onStop();
    }

    @Override protected void onResume() {
        super.onResume();
        scene.start();
        handler.removeCallbacks(statusTick);
        handler.postDelayed(statusTick, 60_000L);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(statusTick);
        scene.stop();
        super.onPause();
        finish();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(statusTick);
        if (scene != null) scene.close();
        if (playingArt != null) clearArt();
        super.onDestroy();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_UP) finish();
        return true;
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) finish();
        return true;
    }

    @Override public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}
