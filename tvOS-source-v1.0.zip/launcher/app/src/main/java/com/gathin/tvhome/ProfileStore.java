package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The launcher's own profiles: a name, an avatar and a home layout each, in one Android user. The active
 * profile is a launcher setting, so switching it bumps the settings revision Home already watches.
 * Guest is a session, not a saved profile: its layout edits and setting changes are thrown away on exit.
 */
final class ProfileStore {

    static final String PREFS = "launcher_profiles";
    static final String ACTIVE_KEY = "active_profile";
    static final String DEFAULT_ID = "default";
    static final String GUEST_ID = "guest";
    static final int AVATAR_ACCOUNT = -1;
    static final int AVATAR_GUEST = -2;
    /** Avatar indexes the editor can show: the account picture first, then the presets. */
    static final int[] AVATARS = {
            R.drawable.avatar_1, R.drawable.avatar_2, R.drawable.avatar_3, R.drawable.avatar_4,
            R.drawable.avatar_5, R.drawable.avatar_6, R.drawable.avatar_7, R.drawable.avatar_8,
            R.drawable.avatar_9, R.drawable.avatar_10, R.drawable.avatar_11, R.drawable.avatar_12,
    };

    private static final String GUEST_PREFS = "launcher_guest";
    private static final String GUEST_RETURN = "return_id";
    private static final String GUEST_SETTING = "s.";
    private static final String ACCOUNT_EMAIL_KEY = "account_email";
    private static final String ACCOUNT_NAME_KEY = "account_name";

    static final class Profile {
        final String id;
        String name;
        int avatar;

        Profile(String id, String name, int avatar) {
            this.id = id;
            this.name = name;
            this.avatar = avatar;
        }

        int avatarRes() {
            return ProfileStore.avatarRes(avatar);
        }

        Drawable avatarDrawable(Context context) {
            if (avatar == AVATAR_ACCOUNT) return AccountIdentity.avatar(context);
            if (avatar == AVATAR_GUEST) return context.getDrawable(R.drawable.profile_avatar_default);
            return context.getDrawable(avatarRes());
        }
    }

    private ProfileStore() { }

    static int avatarRes(int index) {
        return AVATARS[Math.max(0, Math.min(AVATARS.length - 1, index))];
    }

    /** The avatar indexes on offer in the editors: the account picture, when there is one, then the presets. */
    static List<Integer> avatarChoices(Context context) {
        List<Integer> choices = new ArrayList<>();
        if (AccountIdentity.email(context) != null) choices.add(AVATAR_ACCOUNT);
        for (int i = 0; i < AVATARS.length; i++) choices.add(i);
        return choices;
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static SharedPreferences main(Context context) {
        return context.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE);
    }

    private static SharedPreferences guestPrefs(Context context) {
        return context.getSharedPreferences(GUEST_PREFS, Context.MODE_PRIVATE);
    }

    private static List<String> ids(SharedPreferences prefs) {
        String saved = prefs.getString("ids", "");
        List<String> ids = new ArrayList<>();
        for (String id : saved.split(",")) if (!id.isEmpty()) ids.add(id);
        if (!ids.contains(DEFAULT_ID)) {
            ids.add(0, DEFAULT_ID);
            prefs.edit().putString("ids", String.join(",", ids)).apply();
        }
        return ids;
    }

    static List<Profile> list(Context context) {
        SharedPreferences prefs = prefs(context);
        List<Profile> profiles = new ArrayList<>();
        for (String id : ids(prefs)) {
            profiles.add(new Profile(id,
                    prefs.getString(id + ".name", id.equals(DEFAULT_ID)
                            ? context.getString(R.string.profile_home) : context.getString(R.string.profile)),
                    prefs.getInt(id + ".avatar", 0)));
        }
        return profiles;
    }

    static boolean isGuest(Context context) {
        return GUEST_ID.equals(main(context).getString(ACTIVE_KEY, DEFAULT_ID))
                && guestPrefs(context).contains(GUEST_RETURN);
    }

    static String activeId(Context context) {
        String id = main(context).getString(ACTIVE_KEY, DEFAULT_ID);
        if (GUEST_ID.equals(id) && isGuest(context)) return GUEST_ID;
        return list(context).stream().anyMatch(p -> p.id.equals(id)) ? id : DEFAULT_ID;
    }

    static Profile active(Context context) {
        String id = activeId(context);
        if (GUEST_ID.equals(id)) {
            return new Profile(GUEST_ID, context.getString(R.string.profile_guest), AVATAR_GUEST);
        }
        for (Profile profile : list(context)) if (profile.id.equals(id)) return profile;
        return new Profile(DEFAULT_ID, context.getString(R.string.profile_home), 0);
    }

    static void setActive(Context context, String id) {
        SharedPreferences prefs = main(context);
        if (prefs.getString(ACTIVE_KEY, DEFAULT_ID).equals(id)) return;
        prefs.edit().putString(ACTIVE_KEY, id)
                .putLong(Config.SETTINGS_REVISION_KEY, prefs.getLong(Config.SETTINGS_REVISION_KEY, 0) + 1)
                .apply();
    }

    static Profile add(Context context, String name, int avatar) {
        SharedPreferences prefs = prefs(context);
        List<String> ids = ids(prefs);
        String id = "p" + System.currentTimeMillis();
        String from = activeId(context);
        String cleaned = clean(context, name);
        ids.add(id);
        prefs.edit().putString("ids", String.join(",", ids))
                .putString(id + ".name", cleaned)
                .putInt(id + ".avatar", avatar)
                .apply();
        ProfileFiles.copy(context, from, id);
        return new Profile(id, cleaned, avatar);
    }

    static void save(Context context, Profile profile) {
        profile.name = clean(context, profile.name);
        prefs(context).edit()
                .putString(profile.id + ".name", profile.name)
                .putInt(profile.id + ".avatar", profile.avatar)
                .apply();
    }

    /** False for the built-in profile or the last one: a launcher with no profile has no home. */
    static boolean remove(Context context, String id) {
        SharedPreferences prefs = prefs(context);
        List<String> ids = ids(prefs);
        if (DEFAULT_ID.equals(id) || ids.size() <= 1 || !ids.remove(id)) return false;
        prefs.edit().putString("ids", String.join(",", ids))
                .remove(id + ".name").remove(id + ".avatar").apply();
        ProfileFiles.delete(context, id);
        if (activeId(context).equals(id)) setActive(context, ids.get(0));
        return true;
    }

    /**
     * Starts a guest session: the current home is copied into a scratch profile, and a snapshot of the
     * launcher settings is kept in a separate prefs file. Everything written while the guest is on lands in
     * the scratch profile or is rolled back from that snapshot when the session ends.
     */
    static void enterGuest(Context context) {
        String from = activeId(context);
        if (GUEST_ID.equals(from)) return;
        SharedPreferences main = main(context);
        SharedPreferences.Editor backup = guestPrefs(context).edit().clear();
        for (Map.Entry<String, ?> entry : main.getAll().entrySet()) {
            put(backup, GUEST_SETTING + entry.getKey(), entry.getValue());
        }
        backup.putString(GUEST_RETURN, from).apply();
        ProfileFiles.delete(context, GUEST_ID);
        ProfileFiles.copy(context, from, GUEST_ID);
        main.edit().putString(ACTIVE_KEY, GUEST_ID)
                .putLong(Config.SETTINGS_REVISION_KEY, main.getLong(Config.SETTINGS_REVISION_KEY, 0) + 1)
                .apply();
    }

    /** Ends a guest session, restores the settings snapshot and switches to nextId. */
    static void leaveGuest(Context context, String nextId) {
        SharedPreferences main = main(context);
        SharedPreferences backup = guestPrefs(context);
        long revision = main.getLong(Config.SETTINGS_REVISION_KEY, 0) + 1;
        if (!backup.contains(GUEST_RETURN)) {
            setActive(context, nextId);
            return;
        }
        SharedPreferences.Editor editor = main.edit().clear();
        for (Map.Entry<String, ?> entry : backup.getAll().entrySet()) {
            String key = entry.getKey();
            if (key.startsWith(GUEST_SETTING)) put(editor, key.substring(GUEST_SETTING.length()), entry.getValue());
        }
        editor.putString(ACTIVE_KEY, nextId).putLong(Config.SETTINGS_REVISION_KEY, revision).apply();
        backup.edit().clear().apply();
        ProfileFiles.delete(context, GUEST_ID);
    }

    @SuppressWarnings("unchecked")
    private static void put(SharedPreferences.Editor editor, String key, Object value) {
        if (value instanceof Boolean) editor.putBoolean(key, (Boolean) value);
        else if (value instanceof Integer) editor.putInt(key, (Integer) value);
        else if (value instanceof Long) editor.putLong(key, (Long) value);
        else if (value instanceof Float) editor.putFloat(key, (Float) value);
        else if (value instanceof String) editor.putString(key, (String) value);
        else if (value instanceof Set) editor.putStringSet(key, (Set<String>) value);
    }

    /**
     * Fills the built-in profile from the signed-in account once, and keeps following the account while its
     * name and picture are still the ones the launcher set. A name or avatar the owner picked is left alone.
     */
    static void syncAccount(Context context) {
        if (isGuest(context)) return;
        String email = AccountIdentity.email(context);
        String autoName = AccountIdentity.name(email);
        if (email == null || autoName == null) return;
        SharedPreferences main = main(context);
        String lastName = main.getString(ACCOUNT_NAME_KEY, null);
        String defaultName = context.getString(R.string.profile_home);
        boolean firstSync = lastName == null;
        for (Profile profile : list(context)) {
            boolean nameDefault = profile.name.equals(defaultName);
            boolean ours = nameDefault || profile.name.equals(lastName);
            boolean changed = false;
            if (ours && !profile.name.equals(autoName)) {
                profile.name = autoName;
                changed = true;
            }
            // Only the first sync swaps the untouched avatar for the account picture; a preset picked later stays.
            if (firstSync && nameDefault && profile.avatar == 0) {
                profile.avatar = AVATAR_ACCOUNT;
                changed = true;
            }
            if (changed) save(context, profile);
        }
        if (!autoName.equals(lastName) || !email.equals(main.getString(ACCOUNT_EMAIL_KEY, null))) {
            main.edit().putString(ACCOUNT_EMAIL_KEY, email).putString(ACCOUNT_NAME_KEY, autoName).apply();
        }
    }

    private static String clean(Context context, String name) {
        String trimmed = name == null ? "" : name.trim();
        if (trimmed.isEmpty()) trimmed = context.getString(R.string.profile);
        return trimmed.length() > 24 ? trimmed.substring(0, 24) : trimmed;
    }
}
