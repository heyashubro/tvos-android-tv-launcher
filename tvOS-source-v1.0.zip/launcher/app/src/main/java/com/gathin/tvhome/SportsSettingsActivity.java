package com.gathin.tvhome;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** Chooses which sports appear on Home and in Control Center, the country, the football league, and which one leads. */
public final class SportsSettingsActivity extends LauncherActivity {

    private SharedPreferences choices;
    private TextView masterChoice;
    private TextView countryChoice;
    private TextView footballChoice;
    private TextView leagueChoice;
    private TextView cricketChoice;
    private TextView f1Choice;
    private TextView orderChoice;
    private TextView celebrationChoice;
    private TextView celebrationSizeChoice;
    private TextView celebrationStyleChoice;
    private static final String[] CELEBRATION_STYLES = {"party", "trophies", "fireworks"};

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_sports_settings);
        choices = SportsRepository.choices(this);
        masterChoice = findViewById(R.id.sportsMasterChoice);
        countryChoice = findViewById(R.id.sportsCountryChoice);
        footballChoice = findViewById(R.id.sportsFootballChoice);
        leagueChoice = findViewById(R.id.sportsLeagueChoice);
        cricketChoice = findViewById(R.id.sportsCricketChoice);
        f1Choice = findViewById(R.id.sportsF1Choice);
        orderChoice = findViewById(R.id.sportsOrderChoice);
        celebrationChoice = findViewById(R.id.sportsCelebrationChoice);
        celebrationSizeChoice = findViewById(R.id.sportsCelebrationSizeChoice);
        celebrationStyleChoice = findViewById(R.id.sportsCelebrationStyleChoice);
        celebrationChoice.setOnClickListener(v -> {
            choices.edit().putBoolean(SportsRepository.CELEBRATION_KEY,
                    !choices.getBoolean(SportsRepository.CELEBRATION_KEY, true)).apply();
            changed();
            refresh();
        });
        celebrationSizeChoice.setOnClickListener(v -> showCelebrationSizePicker());
        celebrationStyleChoice.setOnClickListener(v -> showCelebrationStylePicker());

        masterChoice.setOnClickListener(v -> {
            boolean enable = !choices.getBoolean(SportsRepository.MASTER_KEY, true);
            choices.edit().putBoolean(SportsRepository.MASTER_KEY, enable).apply();
            changed();
            refresh();
            if (enable) SportsRepository.refresh(this, true);
        });
        countryChoice.setOnClickListener(v -> showCountryPicker());
        footballChoice.setOnClickListener(v -> toggleSport(SportsRepository.FOOTBALL_KEY));
        cricketChoice.setOnClickListener(v -> toggleSport(SportsRepository.CRICKET_KEY));
        f1Choice.setOnClickListener(v -> toggleSport(SportsRepository.F1_KEY));
        leagueChoice.setOnClickListener(v -> showLeaguePicker());
        orderChoice.setOnClickListener(v -> {
            List<String> order = SportsRepository.order(this);
            order.add(order.remove(0));
            choices.edit().putString(SportsRepository.ORDER_KEY, String.join(",", order)).apply();
            changed();
            refresh();
        });
        findViewById(R.id.sportsRefreshChoice).setOnClickListener(v -> {
            if (!choices.getBoolean(SportsRepository.MASTER_KEY, true)
                    || !SportsRepository.anySport(this)) {
                Toast.makeText(this, R.string.sports_none, Toast.LENGTH_SHORT).show();
                return;
            }
            SportsRepository.refresh(this, true);
            Toast.makeText(this, R.string.sports_refreshing, Toast.LENGTH_SHORT).show();
        });
        refresh();
        masterChoice.requestFocus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (masterChoice == null) return;
        refresh();
        SportsRepository.refresh(this, false);
    }

    private void toggleSport(String key) {
        boolean enable = !choices.getBoolean(key, true);
        choices.edit().putBoolean(key, enable)
                // Choosing a sport is also choosing to see scores.
                .putBoolean(SportsRepository.MASTER_KEY, true).apply();
        changed();
        refresh();
        SportsRepository.refresh(this, true);
    }

    private void showCountryPicker() {
        SportsRepository.Country[] countries = SportsRepository.COUNTRIES;
        String[] labels = new String[countries.length];
        SportsRepository.Country current = SportsRepository.country(this);
        int checked = 0;
        for (int i = 0; i < countries.length; i++) {
            labels[i] = SportsRepository.countryLabel(this, countries[i]);
            if (countries[i].id.equals(current.id)) checked = i;
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.sports_country_title)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    SportsRepository.chooseCountry(this, countries[which]);
                    changed();
                    refresh();
                    SportsRepository.refresh(this, true);
                    dialog.dismiss();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void showLeaguePicker() {
        String[] labels = new String[SportsRepository.LEAGUE_SLUGS.length];
        int checked = 0;
        String current = SportsRepository.league(this);
        for (int i = 0; i < labels.length; i++) {
            labels[i] = SportsRepository.leagueLabel(this, SportsRepository.LEAGUE_SLUGS[i]);
            if (SportsRepository.LEAGUE_SLUGS[i].equals(current)) checked = i;
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.sports_league_title)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    choices.edit().putString(SportsRepository.FOOTBALL_LEAGUE_KEY,
                            SportsRepository.LEAGUE_SLUGS[which]).apply();
                    changed();
                    refresh();
                    SportsRepository.refresh(this, true);
                    dialog.dismiss();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private int celebrationSizeLabel(int size) {
        if (size <= 0) return R.string.sports_celebration_subtle;
        if (size >= 2) return R.string.sports_celebration_party;
        return R.string.sports_celebration_normal;
    }

    private int celebrationStyleLabel(String style) {
        if ("trophies".equals(style)) return R.string.sports_celebration_trophies;
        if ("fireworks".equals(style)) return R.string.sports_celebration_fireworks;
        return R.string.sports_celebration_party;
    }

    private void showCelebrationSizePicker() {
        int checked = Math.max(0, Math.min(
                choices.getInt(SportsRepository.CELEBRATION_SIZE_KEY, 1), 2));
        String[] labels = {
                getString(R.string.sports_celebration_subtle),
                getString(R.string.sports_celebration_normal),
                getString(R.string.sports_celebration_party)
        };
        new AlertDialog.Builder(this).setTitle(R.string.sports_celebration_size)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    choices.edit().putInt(SportsRepository.CELEBRATION_SIZE_KEY, which).apply();
                    changed();
                    refresh();
                    dialog.dismiss();
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void showCelebrationStylePicker() {
        String current = choices.getString(SportsRepository.CELEBRATION_STYLE_KEY, "party");
        String[] labels = new String[CELEBRATION_STYLES.length];
        int checked = 0;
        for (int i = 0; i < CELEBRATION_STYLES.length; i++) {
            labels[i] = getString(celebrationStyleLabel(CELEBRATION_STYLES[i]));
            if (CELEBRATION_STYLES[i].equals(current)) checked = i;
        }
        new AlertDialog.Builder(this).setTitle(R.string.sports_celebration_style)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    choices.edit().putString(SportsRepository.CELEBRATION_STYLE_KEY,
                            CELEBRATION_STYLES[which]).apply();
                    changed();
                    refresh();
                    dialog.dismiss();
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void changed() {
        choices.edit().putLong(Config.SETTINGS_REVISION_KEY,
                choices.getLong(Config.SETTINGS_REVISION_KEY, 0) + 1).apply();
    }

    private void refresh() {
        boolean on = choices.getBoolean(SportsRepository.MASTER_KEY, true);
        masterChoice.setText(getString(R.string.sports_sport_state,
                getString(R.string.sports_title), getString(on ? R.string.on : R.string.off)));
        masterChoice.setSelected(on);
        countryChoice.setText(getString(R.string.sports_country_state,
                SportsRepository.countryLabel(this, SportsRepository.country(this))));
        setSport(footballChoice, SportsRepository.FOOTBALL);
        setSport(cricketChoice, SportsRepository.CRICKET);
        setSport(f1Choice, SportsRepository.F1);
        leagueChoice.setText(getString(R.string.sports_league,
                SportsRepository.leagueLabel(this, SportsRepository.league(this))));
        List<String> order = SportsRepository.order(this);
        orderChoice.setText(getString(R.string.sports_order_state,
                SportsRepository.label(this, order.get(0))));
        boolean celebration = choices.getBoolean(SportsRepository.CELEBRATION_KEY, true);
        celebrationChoice.setText(getString(R.string.sports_celebration_state,
                getString(celebration ? R.string.on : R.string.off)));
        celebrationChoice.setSelected(celebration);
        int size = Math.max(0, Math.min(choices.getInt(SportsRepository.CELEBRATION_SIZE_KEY, 1), 2));
        celebrationSizeChoice.setText(getString(R.string.sports_celebration_size_state,
                getString(celebrationSizeLabel(size))));
        celebrationSizeChoice.setEnabled(celebration);
        celebrationSizeChoice.setAlpha(celebration ? 1f : 0.5f);
        celebrationStyleChoice.setText(getString(R.string.sports_celebration_style_state,
                getString(celebrationStyleLabel(
                        choices.getString(SportsRepository.CELEBRATION_STYLE_KEY, "party")))));
        celebrationStyleChoice.setEnabled(celebration);
        celebrationStyleChoice.setAlpha(celebration ? 1f : 0.5f);
    }

    private void setSport(TextView row, String sport) {
        boolean on = SportsRepository.isSportEnabled(this, sport);
        row.setText(getString(R.string.sports_sport_state, SportsRepository.label(this, sport),
                getString(on ? R.string.on : R.string.off)));
        row.setSelected(on);
    }
}
