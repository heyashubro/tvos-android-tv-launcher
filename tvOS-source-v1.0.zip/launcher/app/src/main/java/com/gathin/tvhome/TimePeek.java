package com.gathin.tvhome;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

/**
 * The Menu (three-line) button's time peek: the Home time pill as an accessibility overlay, so it shows over any
 * app without taking focus or pausing what is playing. It hides itself, and a second press hides it early.
 */
final class TimePeek {

    private static final long SHOW_MS = 4000;

    private static TimePeek current;

    private final AccessibilityService service;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final WindowManager windows;
    private final View pill;
    private boolean hidden;

    private TimePeek(AccessibilityService service) {
        this.service = service;
        windows = (WindowManager) service.getSystemService(Context.WINDOW_SERVICE);
        pill = LayoutInflater.from(service).inflate(R.layout.view_time_peek, null);
        ImageView avatar = pill.findViewById(R.id.peekAvatar);
        // The layout attribute ignores this below Android 12; the oval ring background gives the outline.
        avatar.setClipToOutline(true);
        ProfileStore.Profile profile = ProfileStore.active(service);
        avatar.setImageDrawable(profile.avatarDrawable(service));
        avatar.setContentDescription(profile.name);
    }

    static void toggle(AccessibilityService service) {
        if (current != null) {
            if (!current.hidden) {
                current.hide();
                return;
            }
            current.remove();
        }
        current = new TimePeek(service);
        current.show();
    }

    /** Drops the overlay when its service goes away. */
    static void clear() {
        if (current != null) current.remove();
    }

    private void show() {
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = dp(56);
        params.y = dp(26);
        params.setTitle("tvOS time");
        try {
            windows.addView(pill, params);
        } catch (RuntimeException unavailable) {
            current = null;
            return;
        }
        pill.setAlpha(0f);
        pill.setTranslationY(-dp(8));
        pill.animate().alpha(1f).translationY(0f).setDuration(160).start();
        handler.postDelayed(this::hide, SHOW_MS);
    }

    private void hide() {
        if (hidden) return;
        hidden = true;
        handler.removeCallbacksAndMessages(null);
        pill.animate().alpha(0f).translationY(-dp(6)).setDuration(140)
                .withEndAction(this::remove).start();
    }

    private void remove() {
        if (current == this) current = null;
        handler.removeCallbacksAndMessages(null);
        try {
            windows.removeView(pill);
        } catch (RuntimeException alreadyGone) {
        }
    }

    private int dp(int value) {
        return Math.round(value * service.getResources().getDisplayMetrics().density);
    }
}
