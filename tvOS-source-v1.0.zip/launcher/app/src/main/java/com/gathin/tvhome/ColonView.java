package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/**
 * The two dots between the Glance hour and minute. Drawn rather than typeset: a font's colon sits on
 * the baseline, which at 152sp reads as two dots hanging under the digits instead of centred between
 * them. The glow paints in software, since shadows are not drawn on a hardware canvas.
 */
public class ColonView extends View {

    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);

    public ColonView(Context context, AttributeSet attrs) {
        super(context, attrs);
        dot.setColor(0xB8FFFFFF);
        dot.setShadowLayer(11f, 0, 0, 0xA8FFFFFF);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float cx = getWidth() / 2f;
        float radius = getHeight() * 0.032f;
        // Optical centre of the cap-height digits in the Nunito clock: dots at 40% and 58% of the line.
        canvas.drawCircle(cx, getHeight() * 0.40f, radius, dot);
        canvas.drawCircle(cx, getHeight() * 0.58f, radius, dot);
    }
}
