package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.app.NotificationManager;
import android.util.AtomicFile;
import android.view.View;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.Collator;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Remote-friendly settings owned by the launcher; system settings stay one row away. */
public final class LauncherSettingsActivity extends LauncherActivity {
    static final String EXTRA_REORDER = "com.gathin.tvhome.extra.REORDER_FROM_SETTINGS";
    private static final String STATE_CATEGORY = "settings_category";
    private static final int REQUEST_WALLPAPER_ACCESS = 41;
    private static final int REQUEST_GLANCE_ACCESS = 43;
    private static final int REQUEST_WEATHER_LOCATION = 44;
    private static final int MAX_WALLPAPER_BYTES = 10 * 1024 * 1024;
    private SharedPreferences choices;
    private final TextView[] columnChoices = new TextView[4];
    private final TextView[] rowChoices = new TextView[4];
    private static final int[] DOCK_OPACITIES = {100, 70, 50, 30};
    private final TextView[] dockChoices = new TextView[DOCK_OPACITIES.length];
    private TextView wallpaperChoice;
    private TextView wallpaperShuffleChoice;
    private TextView glanceChoice;
    private TextView glanceDelayChoice;
    private TextView animationsChoice;
    private TextView advancedChoice;
    private TextView followThemeChoice;
    private TextView appLibraryChoice;
    private TextView glanceIntervalChoice;
    private TextView glanceClockStyleChoice;
    private TextView glanceClockSizeChoice;
    private TextView glanceClockFontChoice;
    private TextView glanceClockGlassChoice;
    private TextView glanceClockLevelChoice;
    private SeekBar glassBlurChoice;
    private TextView glassBlurValue;
    private LinearLayout settingsContent;
    private LinearLayout categoryMenu;
    private TextView settingsTitle;
    private TextView settingsBack;
    private String activeCategory;
    private boolean showingCategories = true;
    private int columns;
    private int rowsBelowDock;
    private int dockOpacity;
    private boolean animations;
    private boolean advancedEffects;
    private boolean reorderEnabled;
    private boolean enableWeatherAfterPermission;
    private boolean enableNowPlayingAfterSettings;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_launcher_settings);
        // A still of whatever was behind, so Light mode sits on tinted glass rather than flat paper.
        Bitmap still = ControlCenterBackdrop.current();
        if (still != null) {
            ImageView backdrop = findViewById(R.id.settingsBackdropImage);
            backdrop.setImageBitmap(still);
            backdrop.setVisibility(View.VISIBLE);
        }
        choices = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        settingsContent = findViewById(R.id.settingsContent);
        settingsTitle = findViewById(R.id.settingsTitle);
        settingsBack = findViewById(R.id.settingsBack);
        ((TextView) findViewById(R.id.settingsVersion)).setText(
                getString(R.string.about_version, versionName()));
        buildCategoryMenu();
        settingsBack.setOnClickListener(v -> showCategories());
        glassBlurChoice = findViewById(R.id.glassBlurChoice);
        glassBlurValue = findViewById(R.id.glassBlurValue);
        glassBlurChoice.setMax(GlassEffect.LEVELS - 1);
        glassBlurChoice.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                choices.edit().putInt(Config.GLASS_BLUR_KEY, progress).apply();
                changed();
                refresh();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        View.OnClickListener website = v -> open(new Intent(Intent.ACTION_VIEW, Uri.parse("https://heyashubro.pages.dev/")));
        findViewById(R.id.aboutWebsite).setOnClickListener(website);
        Config config = Config.load(this);
        View reorderChoice = findViewById(R.id.reorderChoice);
        reorderEnabled = config.launcherSettingsButton;
        reorderChoice.setVisibility(reorderEnabled ? View.VISIBLE : View.GONE);
        reorderChoice.setOnClickListener(v -> {
            setResult(RESULT_OK, new Intent().putExtra(EXTRA_REORDER, true));
            finish();
        });
        columns = config.columns;
        rowsBelowDock = config.rowsBelowDock;
        dockOpacity = config.dockOpacity;
        animations = config.animations;
        advancedEffects = config.animations && config.advancedEffects;

        int[] ids = {R.id.columns4, R.id.columns5, R.id.columns6, R.id.columns7};
        for (int i = 0; i < ids.length; i++) {
            final int value = i + 4;
            columnChoices[i] = findViewById(ids[i]);
            columnChoices[i].setOnClickListener(v -> {
                if (columns == value) return;
                columns = value;
                choices.edit().putInt("columns", value).apply();
                changed();
                refresh();
            });
        }
        int[] rowIds = {R.id.rows0, R.id.rows1, R.id.rows2, R.id.rows3};
        for (int i = 0; i < rowIds.length; i++) {
            final int value = i;
            rowChoices[i] = findViewById(rowIds[i]);
            rowChoices[i].setOnClickListener(v -> {
                if (rowsBelowDock == value) return;
                rowsBelowDock = value;
                choices.edit().putInt(Config.ROWS_BELOW_DOCK_KEY, value).apply();
                changed();
                refresh();
            });
        }
        int[] dockIds = {R.id.dock100, R.id.dock70, R.id.dock50, R.id.dock30};
        for (int i = 0; i < dockIds.length; i++) {
            final int value = DOCK_OPACITIES[i];
            dockChoices[i] = findViewById(dockIds[i]);
            dockChoices[i].setOnClickListener(v -> {
                if (dockOpacity == value) return;
                dockOpacity = value;
                choices.edit().putInt(Config.DOCK_OPACITY_KEY, value).apply();
                changed();
                refresh();
            });
        }
        // Keep the numeric choices increasing in the Hebrew reading direction. Reorder the
        // actual views so D-pad focus follows their positions without changing the saved values.
        if (getResources().getBoolean(R.bool.rtl_app_grid)) {
            reverseRow(columnChoices);
            reverseRow(rowChoices);
            reverseRow(dockChoices);
        }
        wallpaperChoice = findViewById(R.id.wallpaperChoice);
        appLibraryChoice = findViewById(R.id.appLibraryChoice);
        appLibraryChoice.setOnClickListener(v -> { choices.edit().putBoolean(Config.APP_LIBRARY_ENABLED_KEY, !choices.getBoolean(Config.APP_LIBRARY_ENABLED_KEY, true)).apply(); changed(); refresh(); });
        glanceIntervalChoice = findViewById(R.id.glanceIntervalChoice);
        glanceIntervalChoice.setOnClickListener(v -> showGlanceIntervalPicker());
        TextView glanceNowPlayingChoice = findViewById(R.id.glanceNowPlayingChoice);
        glanceNowPlayingChoice.setOnClickListener(v -> toggleChoice(Config.GLANCE_SHOW_NOW_PLAYING_KEY, true));
        glanceClockStyleChoice = findViewById(R.id.glanceClockStyleChoice);
        glanceClockStyleChoice.setOnClickListener(v -> showGlanceClockStylePicker());
        glanceClockSizeChoice = findViewById(R.id.glanceClockSizeChoice);
        glanceClockSizeChoice.setOnClickListener(v -> showGlanceClockSizePicker());
        glanceClockFontChoice = findViewById(R.id.glanceClockFontChoice);
        glanceClockFontChoice.setOnClickListener(v -> showGlanceClockFontPicker());
        glanceClockGlassChoice = findViewById(R.id.glanceClockGlassChoice);
        glanceClockGlassChoice.setOnClickListener(v -> toggleChoice(Config.GLANCE_CLOCK_GLASS_KEY, false));
        glanceClockLevelChoice = findViewById(R.id.glanceClockLevelChoice);
        glanceClockLevelChoice.setOnClickListener(v -> showGlanceClockLevelPicker());
        findViewById(R.id.parentalLockChoice).setOnClickListener(v -> toggleParentalLock());
        findViewById(R.id.parentalPinChoice).setOnClickListener(v -> changeParentalPin());
        findViewById(R.id.parentalAppsChoice).setOnClickListener(v -> showLockedAppsPicker());
        findViewById(R.id.updateCheckChoice).setOnClickListener(v ->
                startActivity(new Intent(this, UpdateActivity.class)));
        TextView weatherEnabledChoice = findViewById(R.id.weatherEnabledChoice);
        weatherEnabledChoice.setOnClickListener(v -> toggleWeather());
        TextView weatherLocationChoice = findViewById(R.id.weatherLocationChoice);
        weatherLocationChoice.setOnClickListener(v -> showWeatherLocationPicker());
        TextView weatherUnitChoice = findViewById(R.id.weatherUnitChoice);
        weatherUnitChoice.setOnClickListener(v -> showWeatherUnitPicker());
        TextView nowPlayingChoice = findViewById(R.id.nowPlayingChoice);
        nowPlayingChoice.setOnClickListener(v -> toggleNowPlaying());
        wallpaperChoice.setOnClickListener(v -> showWallpaperPicker());
        wallpaperShuffleChoice = findViewById(R.id.wallpaperShuffleChoice);
        wallpaperShuffleChoice.setOnClickListener(v -> showWallpaperShufflePicker());
        glanceChoice = findViewById(R.id.glanceChoice);
        glanceChoice.setOnClickListener(v -> setGlanceEnabled(!choices.getBoolean(Config.GLANCE_ENABLED_KEY, false)));
        glanceDelayChoice = findViewById(R.id.glanceDelayChoice);
        glanceDelayChoice.setOnClickListener(v -> showGlanceDelayPicker());
        animationsChoice = findViewById(R.id.animationsChoice);
        animationsChoice.setOnClickListener(v -> {
            animations = !animations;
            if (!animations) advancedEffects = false;
            choices.edit().putBoolean("animations", animations)
                    .putBoolean("advanced_effects", advancedEffects).apply();
            changed();
            refresh();
        });
        advancedChoice = findViewById(R.id.advancedChoice);
        advancedChoice.setOnClickListener(v -> {
            if (advancedEffects) {
                setAdvanced(false);
            } else {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.advanced_effects)
                        .setMessage(R.string.advanced_effects_warning)
                        .setPositiveButton(R.string.enable, (dialog, which) -> setAdvanced(true))
                        .setNegativeButton(android.R.string.cancel, null)
                        .show();
            }
        });
        findViewById(R.id.textSizeChoice).setOnClickListener(v ->
                startActivity(new Intent(this, TextSizeActivity.class)));
        followThemeChoice = findViewById(R.id.followThemeChoice);        followThemeChoice.setOnClickListener(v -> {
            if (!hasOnTvChoices()) return;
            choices.edit().remove("columns").remove(Config.ROWS_BELOW_DOCK_KEY).remove("animations")
                    .remove("advanced_effects").remove(Config.WALLPAPER_CHOICE_KEY)
                    .remove(Config.WALLPAPER_SHUFFLE_MINUTES_KEY)
                    .remove(Config.GLANCE_ENABLED_KEY).remove(Config.GLANCE_IDLE_MINUTES_KEY)
                    .remove(Config.GLANCE_CLOCK_STYLE_KEY).remove(Config.GLANCE_CLOCK_SIZE_KEY)
                    .remove(Config.GLANCE_CLOCK_FONT_KEY).remove(Config.GLANCE_CLOCK_GLASS_KEY)
                    .remove(Config.GLANCE_CLOCK_GLASS_LEVEL_KEY)
                    .remove(Config.DOCK_OPACITY_KEY).remove(Config.GLASS_BLUR_KEY).remove(Config.GLANCE_SLIDE_SECONDS_KEY).remove(Config.APP_LIBRARY_ENABLED_KEY).commit();
            Config current = Config.load(this);
            columns = current.columns;
            rowsBelowDock = current.rowsBelowDock;
            dockOpacity = current.dockOpacity;
            animations = current.animations;
            advancedEffects = current.animations && current.advancedEffects;
            changed();
            refresh();
        });
        findViewById(R.id.defaultHomeChoice).setOnClickListener(v -> {
            Toast.makeText(this, R.string.home_settings_help, Toast.LENGTH_LONG).show();
            open(new Intent(Settings.ACTION_HOME_SETTINGS));
        });
        findViewById(R.id.tvSettingsChoice).setOnClickListener(v ->
                open(SystemSettings.intent(this, Settings.ACTION_SETTINGS)));
        findViewById(R.id.setupAssistantChoice).setOnClickListener(v ->
                startActivity(new Intent(this, WelcomeActivity.class)));
        findViewById(R.id.sportsChoice).setOnClickListener(v ->
                startActivity(new Intent(this, SportsSettingsActivity.class)));
        findViewById(R.id.profileSwitchChoice).setOnClickListener(v ->
                startActivity(new Intent(this, ProfilesActivity.class)));
        findViewById(R.id.profileEditChoice).setOnClickListener(v ->
                startActivity(new Intent(this, ProfileEditorActivity.class)
                        .putExtra(ProfileEditorActivity.EXTRA_PROFILE_ID, ProfileStore.activeId(this))));
        findViewById(R.id.profileAddChoice).setOnClickListener(v ->
                startActivity(new Intent(this, ProfileEditorActivity.class)));
        applyProfileRows();
        refresh();
        showCategories();
        if (state != null && state.getString(STATE_CATEGORY) != null) {
            showCategory(state.getString(STATE_CATEGORY));
        }
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (!showingCategories && activeCategory != null) out.putString(STATE_CATEGORY, activeCategory);
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "";
        }
    }

    private void buildCategoryMenu() {
        categoryMenu = new LinearLayout(this);
        categoryMenu.setOrientation(LinearLayout.VERTICAL);
        String[] labels = {getString(R.string.settings_general), getString(R.string.settings_appearance), getString(R.string.settings_home_screen), getString(R.string.profiles_title), getString(R.string.settings_apps), getString(R.string.settings_now_bar), getString(R.string.settings_parental), getString(R.string.settings_glance), getString(R.string.settings_about)};
        String[] tags = {"General", "Appearance", "Home Screen", "Profiles", "Apps", "Now Bar", "Parental", "Glance", "About"};
        for (int i = 0; i < labels.length; i++) {
            final String tag = tags[i];
            TextView item = (TextView) getLayoutInflater().inflate(R.layout.item_settings_category, categoryMenu, false);
            item.setText(labels[i]);
            item.setTag(tag);
            item.setOnClickListener(v -> showCategory(tag));
            categoryMenu.addView(item);
        }
        TextView sleep = (TextView) getLayoutInflater().inflate(R.layout.item_settings_category, categoryMenu, false);
        sleep.setText(R.string.settings_sleep_now);
        sleep.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0);
        LinearLayout.LayoutParams sleepParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        sleepParams.topMargin = dp(12);
        sleep.setOnClickListener(v -> startIdleScreen());
        categoryMenu.addView(sleep, sleepParams);
        settingsContent.addView(categoryMenu, 0);
    }

    /** Sleep Now hands the screen to Glance (or the clock when Glance is off), like the TV's own saver. */
    private void startIdleScreen() {
        boolean glance = choices.getBoolean(Config.GLANCE_ENABLED_KEY, false);
        startActivity(new Intent(this, glance ? GlanceActivity.class : ClockActivity.class));
    }

    @Override protected void onResume() {
        super.onResume();
        // Profiles can be renamed or switched from their own screens; this page's row follows.
        if (glanceChoice != null) refresh();
        applyProfileRows();
        if (enableNowPlayingAfterSettings) {
            enableNowPlayingAfterSettings = false;
            if (hasNotificationAccess()) {
                choices.edit().putBoolean(Config.NOW_PLAYING_ENABLED_KEY, true).apply();
                changed();
                refresh();
            } else {
                Toast.makeText(this, R.string.now_playing_no_access, Toast.LENGTH_LONG).show();
            }
        }
    }

    private void toggleChoice(String key, boolean defaultValue) {
        choices.edit().putBoolean(key, !choices.getBoolean(key, defaultValue)).apply();
        changed();
        refresh();
    }

    private void toggleWeather() {
        if (choices.getBoolean(Config.WEATHER_ENABLED_KEY, false)) {
            choices.edit().putBoolean(Config.WEATHER_ENABLED_KEY, false).apply();
            changed();
            refresh();
            return;
        }
        if ("device".equals(choices.getString(Config.WEATHER_LOCATION_MODE_KEY, "city"))) {
            requestWeatherLocation();
            return;
        }
        String city = choices.getString(Config.WEATHER_CITY_KEY, "").trim();
        if (city.isEmpty()) showCityEntry(true);
        else enableWeather();
    }

    private void enableWeather() {
        choices.edit().putBoolean(Config.WEATHER_ENABLED_KEY, true).apply();
        changed();
        refresh();
        WeatherClient.refresh(this, true);
    }

    private void showWeatherLocationPicker() {
        String[] choicesText = {getString(R.string.weather_location_city), getString(R.string.weather_location_device)};
        int selected = "device".equals(choices.getString(Config.WEATHER_LOCATION_MODE_KEY, "city")) ? 1 : 0;
        new AlertDialog.Builder(this).setTitle(R.string.weather_location_title)
                .setSingleChoiceItems(choicesText, selected, (dialog, which) -> {
                    dialog.dismiss();
                    if (which == 0) {
                        choices.edit().putString(Config.WEATHER_LOCATION_MODE_KEY, "city").apply();
                        showCityEntry(choices.getBoolean(Config.WEATHER_ENABLED_KEY, false));
                    } else {
                        choices.edit().putString(Config.WEATHER_LOCATION_MODE_KEY, "device").apply();
                        changed();
                        if (choices.getBoolean(Config.WEATHER_ENABLED_KEY, false)) requestWeatherLocation();
                        else refresh();
                    }
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void showCityEntry(boolean enableAfterSave) {
        EditText cityInput = new EditText(this);
        cityInput.setSingleLine(true);
        cityInput.setText(choices.getString(Config.WEATHER_CITY_KEY, ""));
        cityInput.setHint(R.string.weather_city_prompt);
        cityInput.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle(R.string.weather_city_prompt).setView(cityInput)
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    String city = cityInput.getText().toString().trim();
                    if (city.isEmpty()) return;
                    choices.edit().putString(Config.WEATHER_CITY_KEY, city)
                            .putString(Config.WEATHER_LOCATION_MODE_KEY, "city").apply();
                    changed();
                    if (enableAfterSave) enableWeather(); else refresh();
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void requestWeatherLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            enableWeather();
            return;
        }
        enableWeatherAfterPermission = true;
        new AlertDialog.Builder(this).setTitle(R.string.weather_location_permission_title)
                .setMessage(R.string.weather_location_permission_message)
                .setPositiveButton(R.string.enable, (dialog, which) -> requestPermissions(
                        new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_WEATHER_LOCATION))
                .setNegativeButton(android.R.string.cancel, (dialog, which) -> enableWeatherAfterPermission = false)
                .show();
    }

    private void showWeatherUnitPicker() {
        String[] units = {getString(R.string.weather_unit_celsius), getString(R.string.weather_unit_fahrenheit)};
        int selected = "f".equals(choices.getString(Config.WEATHER_UNIT_KEY, "c")) ? 1 : 0;
        new AlertDialog.Builder(this).setTitle(R.string.weather_unit)
                .setSingleChoiceItems(units, selected, (dialog, which) -> {
                    choices.edit().putString(Config.WEATHER_UNIT_KEY, which == 1 ? "f" : "c").apply();
                    changed();
                    refresh();
                    if (choices.getBoolean(Config.WEATHER_ENABLED_KEY, false)) WeatherClient.refresh(this, true);
                    dialog.dismiss();
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void toggleNowPlaying() {
        if (choices.getBoolean(Config.NOW_PLAYING_ENABLED_KEY, false)) {
            choices.edit().putBoolean(Config.NOW_PLAYING_ENABLED_KEY, false).apply();
            changed();
            refresh();
            return;
        }
        if (hasNotificationAccess()) {
            choices.edit().putBoolean(Config.NOW_PLAYING_ENABLED_KEY, true).apply();
            changed();
            refresh();
            return;
        }
        new AlertDialog.Builder(this).setTitle(R.string.now_playing_permission_title)
                .setMessage(R.string.now_playing_permission_message)
                .setPositiveButton(R.string.tv_settings, (dialog, which) -> {
                    enableNowPlayingAfterSettings = true;
                    open(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private boolean hasNotificationAccess() {
        NotificationManager manager = getSystemService(NotificationManager.class);
        return manager != null && manager.isNotificationListenerAccessGranted(
                new ComponentName(this, NowPlayingListener.class));
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void showCategories() {
        showingCategories = true; activeCategory = null; settingsTitle.setText(R.string.launcher_settings); settingsBack.setVisibility(View.GONE); categoryMenu.setVisibility(View.VISIBLE);
        for (int i = 1; i < settingsContent.getChildCount(); i++) settingsContent.getChildAt(i).setVisibility(View.GONE);
        categoryMenu.getChildAt(0).requestFocus(); ((ScrollView)findViewById(R.id.settingsScroll)).smoothScrollTo(0,0);
    }

    private void showCategory(String category) {
        showingCategories = false; activeCategory = category; settingsTitle.setText(categoryLabel(category)); settingsBack.setVisibility(View.VISIBLE); categoryMenu.setVisibility(View.GONE); View first = null;
        for (int i = 1; i < settingsContent.getChildCount(); i++) {
            View child = settingsContent.getChildAt(i);
            boolean visible = category.equals(child.getTag())
                    && (child.getId() != R.id.reorderChoice || reorderEnabled);
            child.setVisibility(visible ? View.VISIBLE : View.GONE);
            if (visible && first == null && child.isFocusable()) first = child;
        }
        ((ScrollView)findViewById(R.id.settingsScroll)).smoothScrollTo(0,0); if (first != null) first.requestFocus();
        // applyProfileRows toggles the profile rows on resume; keep them inside the Profiles category.
        applyProfileRows();
    }

    /** The category's own label, so the title follows the TV's language instead of the internal tag. */
    private CharSequence categoryLabel(String category) {
        for (int i = 0; i < categoryMenu.getChildCount(); i++) {
            View child = categoryMenu.getChildAt(i);
            if (category.equals(child.getTag()) && child instanceof TextView) return ((TextView) child).getText();
        }
        return category;
    }

    @Override public void onBackPressed() { if (!showingCategories) showCategories(); else super.onBackPressed(); }

    private void showGlanceIntervalPicker() {
        int[] values={10,20,30,60}; String[] labels=new String[values.length]; int selected=1; int current=choices.getInt(Config.GLANCE_SLIDE_SECONDS_KEY,20); for(int i=0;i<values.length;i++){labels[i]=getResources().getQuantityString(R.plurals.glance_interval_seconds,values[i],values[i]);if(values[i]==current)selected=i;}
        new AlertDialog.Builder(this).setTitle(R.string.glance_interval_title).setSingleChoiceItems(labels,selected,(d,which)->{choices.edit().putInt(Config.GLANCE_SLIDE_SECONDS_KEY,values[which]).apply();changed();refresh();d.dismiss();}).setNegativeButton(android.R.string.cancel,null).show();
    }

    private static final String[] CLOCK_STYLES = {"hero", "minimal", "stacked"};
    private static final String[] CLOCK_FONTS = {"bold", "semibold", "regular", "light"};

    private int clockStyleLabel(String style) {
        if ("minimal".equals(style)) return R.string.glance_clock_minimal;
        if ("stacked".equals(style)) return R.string.glance_clock_stacked;
        return R.string.glance_clock_hero;
    }

    private int clockSizeLabel(int size) {
        switch (size) {
            case 0: return R.string.glance_clock_small;
            case 2: return R.string.glance_clock_large;
            case 3: return R.string.glance_clock_huge;
            default: return R.string.glance_clock_medium;
        }
    }

    private int clockFontLabel(String font) {
        if ("semibold".equals(font)) return R.string.glance_clock_semibold;
        if ("regular".equals(font)) return R.string.glance_clock_regular;
        if ("light".equals(font)) return R.string.glance_clock_light;
        return R.string.glance_clock_bold;
    }

    private void showGlanceClockStylePicker() {
        String current = choices.getString(Config.GLANCE_CLOCK_STYLE_KEY, "hero");
        String[] labels = new String[CLOCK_STYLES.length];
        int checked = 0;
        for (int i = 0; i < CLOCK_STYLES.length; i++) {
            labels[i] = getString(clockStyleLabel(CLOCK_STYLES[i]));
            if (CLOCK_STYLES[i].equals(current)) checked = i;
        }
        new AlertDialog.Builder(this).setTitle(R.string.glance_clock_style)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    choices.edit().putString(Config.GLANCE_CLOCK_STYLE_KEY, CLOCK_STYLES[which]).apply();
                    changed();
                    refresh();
                    dialog.dismiss();
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void showGlanceClockSizePicker() {
        int[] sizes = {0, 1, 2, 3};
        String[] labels = new String[sizes.length];
        int current = choices.getInt(Config.GLANCE_CLOCK_SIZE_KEY, 1);
        int checked = 1;
        for (int i = 0; i < sizes.length; i++) {
            labels[i] = getString(clockSizeLabel(sizes[i]));
            if (sizes[i] == current) checked = i;
        }
        new AlertDialog.Builder(this).setTitle(R.string.glance_clock_size)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    choices.edit().putInt(Config.GLANCE_CLOCK_SIZE_KEY, sizes[which]).apply();
                    changed();
                    refresh();
                    dialog.dismiss();
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void showGlanceClockFontPicker() {
        String current = choices.getString(Config.GLANCE_CLOCK_FONT_KEY, "bold");
        String[] labels = new String[CLOCK_FONTS.length];
        int checked = 0;
        for (int i = 0; i < CLOCK_FONTS.length; i++) {
            labels[i] = getString(clockFontLabel(CLOCK_FONTS[i]));
            if (CLOCK_FONTS[i].equals(current)) checked = i;
        }
        new AlertDialog.Builder(this).setTitle(R.string.glance_clock_font)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    choices.edit().putString(Config.GLANCE_CLOCK_FONT_KEY, CLOCK_FONTS[which]).apply();
                    changed();
                    refresh();
                    dialog.dismiss();
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private int clockLevelLabel(int level) {
        switch (level) {
            case 0: return R.string.glance_clock_crystal;
            case 2: return R.string.glance_clock_deep;
            case 3: return R.string.glance_clock_solid;
            default: return R.string.glance_clock_frosted;
        }
    }

    private void showGlanceClockLevelPicker() {
        int[] levels = {0, 1, 2, 3};
        String[] labels = new String[levels.length];
        int current = choices.getInt(Config.GLANCE_CLOCK_GLASS_LEVEL_KEY, 1);
        int checked = 1;
        for (int i = 0; i < levels.length; i++) {
            labels[i] = getString(clockLevelLabel(levels[i]));
            if (levels[i] == current) checked = i;
        }
        new AlertDialog.Builder(this).setTitle(R.string.glance_clock_level)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    choices.edit().putInt(Config.GLANCE_CLOCK_GLASS_LEVEL_KEY, levels[which]).apply();
                    changed();
                    refresh();
                    dialog.dismiss();
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void toggleParentalLock() {
        if (ParentalControls.enabled(this)) {
            ParentalControls.verify(this, () -> {
                ParentalControls.setEnabled(this, false);
                changed();
                refresh();
            });
            return;
        }
        Runnable enable = () -> {
            ParentalControls.setEnabled(this, true);
            changed();
            refresh();
        };
        if (ParentalControls.hasPin(this)) {
            enable.run();
        } else {
            Toast.makeText(this, R.string.parental_pin_needed, Toast.LENGTH_LONG).show();
            PinDialog.setPin(this, enable);
        }
    }

    private void changeParentalPin() {
        ParentalControls.verify(this, () -> PinDialog.setPin(this, () ->
                Toast.makeText(this, R.string.parental_pin_saved, Toast.LENGTH_SHORT).show()));
    }

    /** Editing the list is a parental change too, so it asks for the PIN once the lock is on. */
    private void showLockedAppsPicker() {
        if (ParentalControls.enabled(this)) {
            ParentalControls.verify(this, this::pickLockedApps);
        } else {
            pickLockedApps();
        }
    }

    private void pickLockedApps() {
        PackageManager pm = getPackageManager();
        Map<String, CharSequence> labels = new LinkedHashMap<>();
        for (String category : new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER}) {
            for (ResolveInfo info : pm.queryIntentActivities(
                    new Intent(Intent.ACTION_MAIN).addCategory(category), 0)) {
                if (info.activityInfo == null || !info.activityInfo.exported) continue;
                String pkg = info.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || labels.containsKey(pkg)) continue;
                labels.put(pkg, info.loadLabel(pm));
            }
        }
        List<String> packages = new ArrayList<>(labels.keySet());
        Collator collator = Collator.getInstance();
        packages.sort((a, b) -> collator.compare(String.valueOf(labels.get(a)), String.valueOf(labels.get(b))));
        String[] names = new String[packages.size()];
        boolean[] checked = new boolean[packages.size()];
        Set<String> chosen = ParentalControls.locked(this);
        for (int i = 0; i < names.length; i++) {
            names[i] = String.valueOf(labels.get(packages.get(i)));
            checked[i] = chosen.contains(packages.get(i));
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.parental_locked_apps)
                .setMultiChoiceItems(names, checked, (dialog, which, isChecked) -> {
                    String pkg = packages.get(which);
                    if (isChecked) chosen.add(pkg); else chosen.remove(pkg);
                })
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    ParentalControls.setLocked(this, chosen);
                    changed();
                    refresh();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void reverseRow(TextView[] views) {
        LinearLayout row = (LinearLayout) views[0].getParent();
        row.removeAllViews();
        for (int i = views.length - 1; i >= 0; i--) row.addView(views[i]);
    }

    private void showWallpaperPicker() {
        File dir = Config.dir(this);
        List<File> images = new java.util.ArrayList<>(WallpaperRotation.images(
                dir == null ? null : new File(dir, "wallpapers")));
        // A theme with a single wallpaper.jpg offers that picture too (Config maps the choice back to it).
        File single = dir == null ? null : new File(dir, Config.WALLPAPER_NAME);
        if (single != null && single.isFile()) images.add(0, single);
        String[] labels = new String[images.size() + 2];
        labels[0] = getString(R.string.wallpaper_choose_tv);
        for (int i = 0; i < images.size(); i++) labels[i + 1] = images.get(i).getName();
        labels[labels.length - 1] = getString(R.string.wallpaper_none);
        String current = choices.getString(Config.WALLPAPER_CHOICE_KEY, null);
        boolean hasUserWallpaper = ProfileFiles.wallpaper(this).isFile();
        int checked = hasUserWallpaper ? 0 : "none".equals(current) ? labels.length - 1
                : indexOf(images, current) + 1;
        new AlertDialog.Builder(this)
                .setTitle(R.string.wallpaper_label)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    dialog.dismiss();
                    if (which == 0) {
                        openWallpaperGallery();
                        return;
                    } else if (which == labels.length - 1) {
                        removeUserWallpaper();
                        choices.edit().putString(Config.WALLPAPER_CHOICE_KEY, "none").apply();
                    } else {
                        removeUserWallpaper();
                        // One held picture and a shuffling collection are two modes: picking the
                        // picture turns shuffle off; Theme default can bring it back.
                        choices.edit().putString(Config.WALLPAPER_CHOICE_KEY,
                                images.get(which - 1).getName())
                                .remove(Config.WALLPAPER_SHUFFLE_MINUTES_KEY).apply();
                    }
                    changed();
                    Toast.makeText(this, R.string.wallpaper_applied, Toast.LENGTH_SHORT).show();
                    refresh();
                })
                .setNeutralButton(R.string.wallpaper_theme_default, (dialog, which) -> {
                    removeUserWallpaper();
                    choices.edit().remove(Config.WALLPAPER_CHOICE_KEY).apply();
                    changed();
                    refresh();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    /** Shuffle cadences in minutes: 0 is off, then 1 minute to daily. */
    private static final int[] WALLPAPER_SHUFFLE_MINUTES =
            {0, 1, 5, 15, 30, 60, 180, 360, 720, 1440};

    private String wallpaperShuffleLabel(int minutes) {
        if (minutes <= 0) return getString(R.string.off);
        if (minutes >= Config.WALLPAPER_SHUFFLE_MAX_MINUTES) return getString(R.string.wallpaper_shuffle_daily);
        if (minutes < 60) return getResources().getQuantityString(R.plurals.wallpaper_shuffle_minutes, minutes, minutes);
        int hours = minutes / 60;
        return getResources().getQuantityString(R.plurals.wallpaper_shuffle_hours, hours, hours);
    }

    private void showWallpaperShufflePicker() {
        String[] labels = new String[WALLPAPER_SHUFFLE_MINUTES.length];
        int current = choices.getInt(Config.WALLPAPER_SHUFFLE_MINUTES_KEY, 0);
        int checked = 0;
        for (int i = 0; i < labels.length; i++) {
            labels[i] = wallpaperShuffleLabel(WALLPAPER_SHUFFLE_MINUTES[i]);
            if (WALLPAPER_SHUFFLE_MINUTES[i] == current) checked = i;
        }
        new AlertDialog.Builder(this).setTitle(R.string.wallpaper_shuffle_title)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    dialog.dismiss();
                    int minutes = WALLPAPER_SHUFFLE_MINUTES[which];
                    SharedPreferences.Editor edit = choices.edit()
                            .putInt(Config.WALLPAPER_SHUFFLE_MINUTES_KEY, minutes);
                    // Shuffling plays the theme's whole collection again, not one held picture.
                    if (minutes > 0) edit.remove(Config.WALLPAPER_CHOICE_KEY);
                    edit.apply();
                    changed();
                    refresh();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private String wallpaperReadPermission() {
        return Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    private void openWallpaperGallery() {
        String permission = wallpaperReadPermission();
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) {
            showWallpaperGallery();
        } else {
            requestPermissions(new String[]{permission}, REQUEST_WALLPAPER_ACCESS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_GLANCE_ACCESS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                choices.edit().putBoolean(Config.GLANCE_ENABLED_KEY, true).apply();
                changed();
                refresh();
            } else {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.glance_permission_title)
                        .setMessage(R.string.glance_permission_message)
                        .setPositiveButton(R.string.tv_settings, (dialog, which) -> openAppPermissionSettings())
                        .setNegativeButton(android.R.string.cancel, null)
                        .show();
            }
            return;
        }
        if (requestCode == REQUEST_WEATHER_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (enableWeatherAfterPermission) enableWeather(); else refresh();
            } else {
                enableWeatherAfterPermission = false;
                Toast.makeText(this, R.string.weather_location_denied, Toast.LENGTH_LONG).show();
                refresh();
            }
            return;
        }
        if (requestCode != REQUEST_WALLPAPER_ACCESS) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            showWallpaperGallery();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.wallpaper_permission_title)
                    .setMessage(R.string.wallpaper_permission_message)
                    .setPositiveButton(R.string.tv_settings, (dialog, which) -> openAppPermissionSettings())
                    .setNegativeButton(android.R.string.cancel, null)
                    .show();
        }
    }

    private void openAppPermissionSettings() {
        Intent appSettings = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()));
        try { startActivity(appSettings); }
        catch (ActivityNotFoundException | SecurityException ignored) { }
    }

    private void setGlanceEnabled(boolean enabled) {
        if (!enabled) {
            choices.edit().putBoolean(Config.GLANCE_ENABLED_KEY, false).apply();
            changed();
            refresh();
            return;
        }
        String permission = wallpaperReadPermission();
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) {
            choices.edit().putBoolean(Config.GLANCE_ENABLED_KEY, true).apply();
            changed();
            refresh();
        } else {
            requestPermissions(new String[]{permission}, REQUEST_GLANCE_ACCESS);
        }
    }

    private void showGlanceDelayPicker() {
        final int[] values = {1, 2, 3, 5, 10, 15, 30};
        String[] labels = new String[values.length];
        int selected = 2;
        int current = choices.getInt(Config.GLANCE_IDLE_MINUTES_KEY, 3);
        for (int i = 0; i < values.length; i++) {
            labels[i] = getResources().getQuantityString(R.plurals.glance_delay_minutes, values[i], values[i]);
            if (values[i] == current) selected = i;
        }
        new AlertDialog.Builder(this).setTitle(R.string.glance_delay_title)
                .setSingleChoiceItems(labels, selected, (dialog, which) -> {
                    choices.edit().putInt(Config.GLANCE_IDLE_MINUTES_KEY, values[which]).apply();
                    changed();
                    refresh();
                    dialog.dismiss();
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void showWallpaperGallery() {
        WallpaperGalleryDialog.show(this, getString(R.string.wallpaper_gallery_empty),
                getString(R.string.wallpaper_gallery_title), (uri, name) -> {
        if (!saveUserWallpaper(uri)) {
            Toast.makeText(this, R.string.wallpaper_pick_failed, Toast.LENGTH_LONG).show();
            return;
        }
        choices.edit().remove(Config.WALLPAPER_CHOICE_KEY)
                .remove(Config.WALLPAPER_SHUFFLE_MINUTES_KEY)
                .putString(Config.USER_WALLPAPER_NAME_KEY, name).apply();
        changed();
        Toast.makeText(this, R.string.wallpaper_applied, Toast.LENGTH_SHORT).show();
        refresh();
        });
    }

    private boolean saveUserWallpaper(Uri uri) {
        AtomicFile target = new AtomicFile(ProfileFiles.wallpaper(this));
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream probe = getContentResolver().openInputStream(uri)) {
            if (probe == null) return false;
            BitmapFactory.decodeStream(probe, null, bounds);
        } catch (IOException | SecurityException e) {
            return false;
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false;
        int sample = WallpaperSize.sampleSize(bounds.outWidth, bounds.outHeight,
                getResources().getDisplayMetrics().widthPixels, getResources().getDisplayMetrics().heightPixels);
        if (!WallpaperSize.accepted(bounds.outWidth / sample, bounds.outHeight / sample)) return false;
        FileOutputStream output = null;
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            if (input == null) return false;
            output = target.startWrite();
            byte[] buffer = new byte[8192];
            int count;
            int total = 0;
            while ((count = input.read(buffer)) != -1) {
                total += count;
                if (total > MAX_WALLPAPER_BYTES) throw new IOException("Image exceeds 10 MB");
                output.write(buffer, 0, count);
            }
            if (total == 0) throw new IOException("Empty image");
            target.finishWrite(output);
            return true;
        } catch (IOException | SecurityException e) {
            if (output != null) target.failWrite(output);
            return false;
        }
    }

    private void removeUserWallpaper() {
        new AtomicFile(ProfileFiles.wallpaper(this)).delete();
        choices.edit().remove(Config.USER_WALLPAPER_NAME_KEY).apply();
    }

    private static int indexOf(List<File> images, String name) {
        if (name == null) return -1;
        for (int i = 0; i < images.size(); i++) {
            if (images.get(i).getName().equals(name)) return i;
        }
        return -1;
    }

    /** Guest keeps nothing, so changing profiles from here is the only profile action it offers. */
    private void applyProfileRows() {
        boolean profilesOpen = !showingCategories && "Profiles".equals(activeCategory);
        int visibility = !profilesOpen || ProfileStore.isGuest(this) ? View.GONE : View.VISIBLE;
        findViewById(R.id.profileEditChoice).setVisibility(visibility);
        findViewById(R.id.profileAddChoice).setVisibility(visibility);
    }

    /** A choice was saved. Home rebuilds when it next resumes because the change count moved, whether these
     * settings are left with Back or with the remote's Home button (which cancels the activity result).
     */
    private void changed() {
        setResult(RESULT_OK);
        choices.edit().putLong(Config.SETTINGS_REVISION_KEY,
                choices.getLong(Config.SETTINGS_REVISION_KEY, 0) + 1).apply();
    }

    private void setAdvanced(boolean enabled) {
        advancedEffects = enabled;
        choices.edit().putBoolean("advanced_effects", enabled).apply();
        changed();
        refresh();
    }

    private void refresh() {
        for (int i = 0; i < columnChoices.length; i++) {
            columnChoices[i].setSelected(columns == i + 4);
        }
        for (int i = 0; i < rowChoices.length; i++) {
            rowChoices[i].setSelected(rowsBelowDock == i);
        }
        for (int i = 0; i < dockChoices.length; i++) {
            dockChoices[i].setSelected(dockOpacity == DOCK_OPACITIES[i]);
        }
        appLibraryChoice.setText(getString(R.string.app_library_state, getString(choices.getBoolean(Config.APP_LIBRARY_ENABLED_KEY, true) ? R.string.on : R.string.off)));
        appLibraryChoice.setSelected(choices.getBoolean(Config.APP_LIBRARY_ENABLED_KEY, true));
        int slideSeconds=choices.getInt(Config.GLANCE_SLIDE_SECONDS_KEY,20); glanceIntervalChoice.setText(getString(R.string.glance_interval_state,getResources().getQuantityString(R.plurals.glance_interval_seconds,slideSeconds,slideSeconds)));
        boolean weatherEnabled = choices.getBoolean(Config.WEATHER_ENABLED_KEY, false);
        ((TextView)findViewById(R.id.weatherEnabledChoice)).setText(getString(R.string.weather_enable, getString(weatherEnabled ? R.string.on : R.string.off)));
        boolean deviceLocation = "device".equals(choices.getString(Config.WEATHER_LOCATION_MODE_KEY, "city"));
        String weatherLocation = deviceLocation ? getString(R.string.weather_location_device)
                : choices.getString(Config.WEATHER_CITY_KEY, "").trim();
        if (weatherLocation.isEmpty()) weatherLocation = getString(R.string.weather_city_unset);
        ((TextView)findViewById(R.id.weatherLocationChoice)).setText(getString(R.string.weather_location, weatherLocation));
        String unit = "f".equals(choices.getString(Config.WEATHER_UNIT_KEY, "c"))
                ? getString(R.string.weather_unit_fahrenheit) : getString(R.string.weather_unit_celsius);
        ((TextView)findViewById(R.id.weatherUnitChoice)).setText(getString(R.string.weather_unit, unit));
        boolean nowPlayingEnabled = choices.getBoolean(Config.NOW_PLAYING_ENABLED_KEY, false);
        ((TextView)findViewById(R.id.nowPlayingChoice)).setText(getString(R.string.now_playing_enable, getString(nowPlayingEnabled ? R.string.on : R.string.off)));
        ((TextView)findViewById(R.id.glanceNowPlayingChoice)).setText(getString(R.string.now_playing_in_glance,
                getString(choices.getBoolean(Config.GLANCE_SHOW_NOW_PLAYING_KEY, true) ? R.string.on : R.string.off)));
        glanceClockStyleChoice.setText(getString(R.string.glance_clock_style_state,
                getString(clockStyleLabel(choices.getString(Config.GLANCE_CLOCK_STYLE_KEY, "hero")))));
        glanceClockSizeChoice.setText(getString(R.string.glance_clock_size_state,
                getString(clockSizeLabel(choices.getInt(Config.GLANCE_CLOCK_SIZE_KEY, 1)))));
        glanceClockFontChoice.setText(getString(R.string.glance_clock_font_state,
                getString(clockFontLabel(choices.getString(Config.GLANCE_CLOCK_FONT_KEY, "bold")))));
        glanceClockGlassChoice.setText(getString(R.string.glance_clock_glass_state,
                getString(choices.getBoolean(Config.GLANCE_CLOCK_GLASS_KEY, false) ? R.string.on : R.string.off)));
        boolean clockGlass = choices.getBoolean(Config.GLANCE_CLOCK_GLASS_KEY, false);
        glanceClockLevelChoice.setText(getString(R.string.glance_clock_level_state,
                getString(clockLevelLabel(choices.getInt(Config.GLANCE_CLOCK_GLASS_LEVEL_KEY, 1)))));
        glanceClockLevelChoice.setEnabled(clockGlass);
        glanceClockLevelChoice.setAlpha(clockGlass ? 1f : 0.5f);
        ((TextView) findViewById(R.id.parentalLockChoice)).setText(getString(R.string.parental_lock_state,
                getString(ParentalControls.enabled(this) ? R.string.on : R.string.off)));
        ((TextView) findViewById(R.id.parentalPinChoice)).setText(getString(R.string.parental_pin_state,
                getString(ParentalControls.hasPin(this) ? R.string.parental_pin_set : R.string.parental_pin_unset)));
        ((TextView) findViewById(R.id.parentalAppsChoice)).setText(getString(R.string.parental_locked_apps_state,
                ParentalControls.locked(this).size()));
        ((TextView) findViewById(R.id.aboutVersion)).setText(getString(R.string.about_version, versionName()));
        int blurLevel = GlassEffect.level(this);
        glassBlurChoice.setProgress(blurLevel);
        glassBlurValue.setText(getString(R.string.glass_blur_state, getString(GlassEffect.labelRes(blurLevel))));
        animationsChoice.setText(getString(R.string.animations_state,
                getString(animations ? R.string.on : R.string.off)));
        boolean glanceEnabled = choices.getBoolean(Config.GLANCE_ENABLED_KEY, false);
        int glanceMinutes = choices.getInt(Config.GLANCE_IDLE_MINUTES_KEY, 3);
        glanceChoice.setText(getString(R.string.glance_state, getString(glanceEnabled ? R.string.on : R.string.off)));
        glanceChoice.setSelected(glanceEnabled);
        glanceDelayChoice.setText(getResources().getQuantityString(R.plurals.glance_idle_delay,
                glanceMinutes, glanceMinutes));
        glanceDelayChoice.setEnabled(glanceEnabled);
        glanceDelayChoice.setAlpha(glanceEnabled ? 1f : 0.5f);
        advancedChoice.setText(getString(R.string.advanced_effects_state,
                getString(advancedEffects ? R.string.on : R.string.off)));
        advancedChoice.setEnabled(animations);
        advancedChoice.setAlpha(animations ? 1f : 0.5f);
        String wallpaperCurrent = choices.getString(Config.WALLPAPER_CHOICE_KEY, null);
        if (ProfileFiles.wallpaper(this).isFile()) {
            wallpaperCurrent = choices.getString(Config.USER_WALLPAPER_NAME_KEY,
                    getString(R.string.wallpaper_custom));
        }
        wallpaperChoice.setText(getString(R.string.wallpaper_state,
                "none".equals(wallpaperCurrent) ? getString(R.string.wallpaper_none)
                        : wallpaperCurrent != null ? wallpaperCurrent
                        : getString(R.string.wallpaper_theme_default)));
        wallpaperShuffleChoice.setText(getString(R.string.wallpaper_shuffle_state,
                wallpaperShuffleLabel(choices.getInt(Config.WALLPAPER_SHUFFLE_MINUTES_KEY, 0))));
        ((TextView) findViewById(R.id.profileEditChoice)).setText(
                getString(R.string.profile_edit_state, ProfileStore.active(this).name));
        followThemeChoice.setSelected(!hasOnTvChoices());
    }

    private boolean hasOnTvChoices() {
        return choices.contains("columns") || choices.contains(Config.ROWS_BELOW_DOCK_KEY)
                || choices.contains("animations") || choices.contains("advanced_effects")
                || choices.contains(Config.WALLPAPER_CHOICE_KEY)
                || choices.contains(Config.WALLPAPER_SHUFFLE_MINUTES_KEY)
                || choices.contains(Config.USER_WALLPAPER_NAME_KEY) || choices.contains(Config.DOCK_OPACITY_KEY)
                || choices.contains(Config.GLANCE_ENABLED_KEY) || choices.contains(Config.GLANCE_IDLE_MINUTES_KEY) || choices.contains(Config.GLANCE_SLIDE_SECONDS_KEY) || choices.contains(Config.APP_LIBRARY_ENABLED_KEY)
                || choices.contains(Config.GLANCE_CLOCK_STYLE_KEY) || choices.contains(Config.GLANCE_CLOCK_SIZE_KEY)
                || choices.contains(Config.GLANCE_CLOCK_FONT_KEY) || choices.contains(Config.GLANCE_CLOCK_GLASS_KEY)
                || choices.contains(Config.GLANCE_CLOCK_GLASS_LEVEL_KEY)
                || choices.contains(Config.GLASS_BLUR_KEY)
                || choices.contains(Config.WEATHER_ENABLED_KEY) || choices.contains(Config.WEATHER_LOCATION_MODE_KEY)
                || choices.contains(Config.WEATHER_CITY_KEY) || choices.contains(Config.WEATHER_UNIT_KEY)
                || choices.contains(Config.NOW_PLAYING_ENABLED_KEY);
    }

    private void open(Intent intent) {
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, R.string.not_available, Toast.LENGTH_LONG).show();
        }
    }
}
