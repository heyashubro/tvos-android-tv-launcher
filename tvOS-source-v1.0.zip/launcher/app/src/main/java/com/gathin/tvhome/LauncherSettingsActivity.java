package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.AtomicFile;
import android.view.View;
import android.view.Gravity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/** Remote-friendly settings owned by the launcher; system settings stay one row away. */
public final class LauncherSettingsActivity extends Activity {
    static final String EXTRA_REORDER = "com.gathin.tvhome.extra.REORDER_FROM_SETTINGS";
    private static final int REQUEST_WALLPAPER_ACCESS = 41;
    private static final int REQUEST_GLANCE_ACCESS = 43;
    private static final int MAX_WALLPAPER_BYTES = 10 * 1024 * 1024;
    private SharedPreferences choices;
    private final TextView[] columnChoices = new TextView[4];
    private final TextView[] rowChoices = new TextView[4];
    private static final int[] DOCK_OPACITIES = {100, 70, 50, 30};
    private final TextView[] dockChoices = new TextView[DOCK_OPACITIES.length];
    private TextView wallpaperChoice;
    private TextView glanceChoice;
    private TextView glanceDelayChoice;
    private TextView animationsChoice;
    private TextView advancedChoice;
    private TextView followThemeChoice;
    private TextView appearanceChoice;
    private TextView launcherTileChoice;
    private TextView appLibraryChoice;
    private TextView glanceIntervalChoice;
    private LinearLayout settingsContent;
    private LinearLayout categoryMenu;
    private TextView settingsTitle;
    private TextView settingsBack;
    private boolean darkMode;
    private String activeCategory;
    private boolean showingCategories = true;
    private int columns;
    private int rowsBelowDock;
    private int dockOpacity;
    private boolean animations;
    private boolean advancedEffects;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_launcher_settings);
        choices = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        settingsContent = findViewById(R.id.settingsContent);
        settingsTitle = findViewById(R.id.settingsTitle);
        settingsBack = findViewById(R.id.settingsBack);
        darkMode = choices.getBoolean(Config.DARK_MODE_KEY, true);
        buildCategoryMenu();
        settingsBack.setOnClickListener(v -> showCategories());
        View.OnClickListener website = v -> open(new Intent(Intent.ACTION_VIEW, Uri.parse("https://heyashubro.pages.dev/")));
        findViewById(R.id.aboutWebsite).setOnClickListener(website);
        Config config = Config.load(this);
        View reorderChoice = findViewById(R.id.reorderChoice);
        reorderChoice.setVisibility(config.launcherSettingsButton ? View.VISIBLE : View.GONE);
        reorderChoice.setOnClickListener(v -> {
            setResult(RESULT_OK, new Intent().putExtra(EXTRA_REORDER, true));
            finish();
        });
        columns = config.columns;
        rowsBelowDock = config.rowsBelowDock;
        dockOpacity = config.dockOpacity;
        animations = config.animations;
        advancedEffects = config.animations && config.advancedEffects;

        int[] ids = {R.id.columns4, R.id.columns5, R.id.columns6, R.id.columns7};
        for (int i = 0; i < ids.length; i++) {
            final int value = i + 4;
            columnChoices[i] = findViewById(ids[i]);
            columnChoices[i].setOnClickListener(v -> {
                if (columns == value) return;
                columns = value;
                choices.edit().putInt("columns", value).apply();
                changed();
                refresh();
            });
        }
        int[] rowIds = {R.id.rows0, R.id.rows1, R.id.rows2, R.id.rows3};
        for (int i = 0; i < rowIds.length; i++) {
            final int value = i;
            rowChoices[i] = findViewById(rowIds[i]);
            rowChoices[i].setOnClickListener(v -> {
                if (rowsBelowDock == value) return;
                rowsBelowDock = value;
                choices.edit().putInt(Config.ROWS_BELOW_DOCK_KEY, value).apply();
                changed();
                refresh();
            });
        }
        int[] dockIds = {R.id.dock100, R.id.dock70, R.id.dock50, R.id.dock30};
        for (int i = 0; i < dockIds.length; i++) {
            final int value = DOCK_OPACITIES[i];
            dockChoices[i] = findViewById(dockIds[i]);
            dockChoices[i].setOnClickListener(v -> {
                if (dockOpacity == value) return;
                dockOpacity = value;
                choices.edit().putInt(Config.DOCK_OPACITY_KEY, value).apply();
                changed();
                refresh();
            });
        }
        // Keep the numeric choices increasing in the Hebrew reading direction. Reorder the
        // actual views so D-pad focus follows their positions without changing the saved values.
        if (getResources().getBoolean(R.bool.rtl_app_grid)) {
            reverseRow(columnChoices);
            reverseRow(rowChoices);
            reverseRow(dockChoices);
        }
        wallpaperChoice = findViewById(R.id.wallpaperChoice);
        appearanceChoice = findViewById(R.id.appearanceChoice);
        appearanceChoice.setOnClickListener(v -> { darkMode = !darkMode; choices.edit().putBoolean(Config.DARK_MODE_KEY, darkMode).apply(); changed(); applySettingsPalette(); refresh(); });
        launcherTileChoice = findViewById(R.id.launcherTileChoice);
        launcherTileChoice.setOnClickListener(v -> { choices.edit().putBoolean(Config.LAUNCHER_SETTINGS_TILE_KEY, !choices.getBoolean(Config.LAUNCHER_SETTINGS_TILE_KEY, false)).apply(); changed(); refresh(); });
        appLibraryChoice = findViewById(R.id.appLibraryChoice);
        appLibraryChoice.setOnClickListener(v -> { choices.edit().putBoolean(Config.APP_LIBRARY_ENABLED_KEY, !choices.getBoolean(Config.APP_LIBRARY_ENABLED_KEY, true)).apply(); changed(); refresh(); });
        glanceIntervalChoice = findViewById(R.id.glanceIntervalChoice);
        glanceIntervalChoice.setOnClickListener(v -> showGlanceIntervalPicker());
        wallpaperChoice.setOnClickListener(v -> showWallpaperPicker());
        glanceChoice = findViewById(R.id.glanceChoice);
        glanceChoice.setOnClickListener(v -> setGlanceEnabled(!choices.getBoolean(Config.GLANCE_ENABLED_KEY, false)));
        glanceDelayChoice = findViewById(R.id.glanceDelayChoice);
        glanceDelayChoice.setOnClickListener(v -> showGlanceDelayPicker());
        animationsChoice = findViewById(R.id.animationsChoice);
        animationsChoice.setOnClickListener(v -> {
            animations = !animations;
            if (!animations) advancedEffects = false;
            choices.edit().putBoolean("animations", animations)
                    .putBoolean("advanced_effects", advancedEffects).apply();
            changed();
            refresh();
        });
        advancedChoice = findViewById(R.id.advancedChoice);
        advancedChoice.setOnClickListener(v -> {
            if (advancedEffects) {
                setAdvanced(false);
            } else {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.advanced_effects)
                        .setMessage(R.string.advanced_effects_warning)
                        .setPositiveButton(R.string.enable, (dialog, which) -> setAdvanced(true))
                        .setNegativeButton(android.R.string.cancel, null)
                        .show();
            }
        });
        followThemeChoice = findViewById(R.id.followThemeChoice);
        followThemeChoice.setOnClickListener(v -> {
            if (!hasOnTvChoices()) return;
            choices.edit().remove("columns").remove(Config.ROWS_BELOW_DOCK_KEY).remove("animations")
                    .remove("advanced_effects").remove(Config.WALLPAPER_CHOICE_KEY)
                    .remove(Config.GLANCE_ENABLED_KEY).remove(Config.GLANCE_IDLE_MINUTES_KEY)
                    .remove(Config.DOCK_OPACITY_KEY).remove(Config.GLANCE_SLIDE_SECONDS_KEY).remove(Config.LAUNCHER_SETTINGS_TILE_KEY).remove(Config.APP_LIBRARY_ENABLED_KEY).remove(Config.DARK_MODE_KEY).commit();
            Config current = Config.load(this);
            columns = current.columns;
            rowsBelowDock = current.rowsBelowDock;
            dockOpacity = current.dockOpacity;
            animations = current.animations;
            advancedEffects = current.animations && current.advancedEffects;
            changed();
            refresh();
        });
        findViewById(R.id.defaultHomeChoice).setOnClickListener(v -> {
            Toast.makeText(this, R.string.home_settings_help, Toast.LENGTH_LONG).show();
            open(new Intent(Settings.ACTION_HOME_SETTINGS));
        });
        findViewById(R.id.tvSettingsChoice).setOnClickListener(v ->
                open(SystemSettings.intent(this, Settings.ACTION_SETTINGS)));
        refresh();
        applySettingsPalette();
        showCategories();
    }

    private void buildCategoryMenu() {
        categoryMenu = new LinearLayout(this);
        categoryMenu.setOrientation(LinearLayout.VERTICAL);
        String[] labels = {getString(R.string.settings_general), getString(R.string.settings_appearance), getString(R.string.settings_home_screen), getString(R.string.settings_apps), getString(R.string.settings_glance), getString(R.string.settings_about)};
        String[] tags = {"General", "Appearance", "Home Screen", "Apps", "Glance", "About"};
        for (int i = 0; i < labels.length; i++) {
            final String tag = tags[i];
            TextView item = new TextView(this); item.setText(labels[i] + "   ›"); item.setTextSize(24); item.setGravity(Gravity.CENTER_VERTICAL); item.setPadding(22, 0, 22, 0); item.setFocusable(true); item.setClickable(true); item.setBackgroundResource(R.drawable.settings_choice_bg);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(66)); lp.topMargin = dp(10); categoryMenu.addView(item, lp); item.setOnClickListener(v -> showCategory(tag));
        }
        settingsContent.addView(categoryMenu, 2);
        applySettingsPalette();
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void showCategories() {
        showingCategories = true; activeCategory = null; settingsTitle.setText(R.string.launcher_settings); settingsBack.setVisibility(View.GONE); categoryMenu.setVisibility(View.VISIBLE);
        for (int i = 3; i < settingsContent.getChildCount(); i++) settingsContent.getChildAt(i).setVisibility(View.GONE);
        categoryMenu.getChildAt(0).requestFocus(); ((ScrollView)findViewById(R.id.settingsScroll)).smoothScrollTo(0,0);
    }

    private void showCategory(String category) {
        showingCategories = false; activeCategory = category; settingsTitle.setText(category); settingsBack.setVisibility(View.VISIBLE); categoryMenu.setVisibility(View.GONE); View first = null;
        for (int i = 3; i < settingsContent.getChildCount(); i++) { View child = settingsContent.getChildAt(i); boolean visible = category.equals(child.getTag()); child.setVisibility(visible ? View.VISIBLE : View.GONE); if (visible && first == null && child.isFocusable()) first = child; }
        ((ScrollView)findViewById(R.id.settingsScroll)).smoothScrollTo(0,0); if (first != null) first.requestFocus();
    }

    @Override public void onBackPressed() { if (!showingCategories) showCategories(); else super.onBackPressed(); }

    private void applySettingsPalette() {
        int text = darkMode ? Color.WHITE : Color.rgb(24, 30, 40); int secondary = darkMode ? 0xFFACB8C1 : 0xFF4D5968;
        findViewById(R.id.settingsScroll).setBackgroundColor(darkMode ? Color.BLACK : 0xFFF1F3F7);
        for (int i=0; i<settingsContent.getChildCount(); i++) tintTree(settingsContent.getChildAt(i), text, secondary); settingsTitle.setTextColor(text); settingsBack.setTextColor(text);
    }
    private void tintTree(View view, int text, int secondary) {
        if (view instanceof TextView) { TextView tv=(TextView)view; CharSequence value=tv.getText(); tv.setTextColor(value != null && (value.toString().contains("Made with") || value.toString().contains("Inspired") || value.toString().contains("terms") || value.toString().contains("Terms") || value.toString().contains("\u2022")) ? secondary : text); if (tv.isFocusable() || tv.isClickable()) tv.setBackgroundResource(darkMode ? R.drawable.settings_choice_bg : R.drawable.settings_choice_bg_light); }
        if (view instanceof android.view.ViewGroup) { android.view.ViewGroup group=(android.view.ViewGroup)view; for(int i=0;i<group.getChildCount();i++) tintTree(group.getChildAt(i),text,secondary); }
    }

    private void showGlanceIntervalPicker() {
        int[] values={10,20,30,60}; String[] labels=new String[values.length]; int selected=1; int current=choices.getInt(Config.GLANCE_SLIDE_SECONDS_KEY,20); for(int i=0;i<values.length;i++){labels[i]=getResources().getQuantityString(R.plurals.glance_interval_seconds,values[i],values[i]);if(values[i]==current)selected=i;}
        new AlertDialog.Builder(this).setTitle(R.string.glance_interval_title).setSingleChoiceItems(labels,selected,(d,which)->{choices.edit().putInt(Config.GLANCE_SLIDE_SECONDS_KEY,values[which]).apply();changed();refresh();d.dismiss();}).setNegativeButton(android.R.string.cancel,null).show();
    }

    private void reverseRow(TextView[] views) {
        LinearLayout row = (LinearLayout) views[0].getParent();
        row.removeAllViews();
        for (int i = views.length - 1; i >= 0; i--) row.addView(views[i]);
    }

    private void showWallpaperPicker() {
        File dir = Config.dir(this);
        List<File> images = new java.util.ArrayList<>(WallpaperRotation.images(
                dir == null ? null : new File(dir, "wallpapers")));
        // A theme with a single wallpaper.jpg offers that picture too (Config maps the choice back to it).
        File single = dir == null ? null : new File(dir, Config.WALLPAPER_NAME);
        if (single != null && single.isFile()) images.add(0, single);
        String[] labels = new String[images.size() + 2];
        labels[0] = getString(R.string.wallpaper_choose_tv);
        for (int i = 0; i < images.size(); i++) labels[i + 1] = images.get(i).getName();
        labels[labels.length - 1] = getString(R.string.wallpaper_none);
        String current = choices.getString(Config.WALLPAPER_CHOICE_KEY, null);
        boolean hasUserWallpaper = new File(getFilesDir(), Config.USER_WALLPAPER_FILE).isFile();
        int checked = hasUserWallpaper ? 0 : "none".equals(current) ? labels.length - 1
                : indexOf(images, current) + 1;
        new AlertDialog.Builder(this)
                .setTitle(R.string.wallpaper_label)
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    dialog.dismiss();
                    if (which == 0) {
                        openWallpaperGallery();
                        return;
                    } else if (which == labels.length - 1) {
                        removeUserWallpaper();
                        choices.edit().putString(Config.WALLPAPER_CHOICE_KEY, "none").apply();
                    } else {
                        removeUserWallpaper();
                        choices.edit().putString(Config.WALLPAPER_CHOICE_KEY,
                                images.get(which - 1).getName()).apply();
                    }
                    changed();
                    Toast.makeText(this, R.string.wallpaper_applied, Toast.LENGTH_SHORT).show();
                    refresh();
                })
                .setNeutralButton(R.string.wallpaper_theme_default, (dialog, which) -> {
                    removeUserWallpaper();
                    choices.edit().remove(Config.WALLPAPER_CHOICE_KEY).apply();
                    changed();
                    refresh();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private String wallpaperReadPermission() {
        return Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    private void openWallpaperGallery() {
        String permission = wallpaperReadPermission();
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) {
            showWallpaperGallery();
        } else {
            requestPermissions(new String[]{permission}, REQUEST_WALLPAPER_ACCESS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_GLANCE_ACCESS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                choices.edit().putBoolean(Config.GLANCE_ENABLED_KEY, true).apply();
                changed();
                refresh();
            } else {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.glance_permission_title)
                        .setMessage(R.string.glance_permission_message)
                        .setPositiveButton(R.string.tv_settings, (dialog, which) -> openAppPermissionSettings())
                        .setNegativeButton(android.R.string.cancel, null)
                        .show();
            }
            return;
        }
        if (requestCode != REQUEST_WALLPAPER_ACCESS) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            showWallpaperGallery();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.wallpaper_permission_title)
                    .setMessage(R.string.wallpaper_permission_message)
                    .setPositiveButton(R.string.tv_settings, (dialog, which) -> openAppPermissionSettings())
                    .setNegativeButton(android.R.string.cancel, null)
                    .show();
        }
    }

    private void openAppPermissionSettings() {
        Intent appSettings = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()));
        try { startActivity(appSettings); }
        catch (ActivityNotFoundException | SecurityException ignored) { }
    }

    private void setGlanceEnabled(boolean enabled) {
        if (!enabled) {
            choices.edit().putBoolean(Config.GLANCE_ENABLED_KEY, false).apply();
            changed();
            refresh();
            return;
        }
        String permission = wallpaperReadPermission();
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) {
            choices.edit().putBoolean(Config.GLANCE_ENABLED_KEY, true).apply();
            changed();
            refresh();
        } else {
            requestPermissions(new String[]{permission}, REQUEST_GLANCE_ACCESS);
        }
    }

    private void showGlanceDelayPicker() {
        final int[] values = {1, 2, 3, 5, 10, 15, 30};
        String[] labels = new String[values.length];
        int selected = 2;
        int current = choices.getInt(Config.GLANCE_IDLE_MINUTES_KEY, 3);
        for (int i = 0; i < values.length; i++) {
            labels[i] = getResources().getQuantityString(R.plurals.glance_delay_minutes, values[i], values[i]);
            if (values[i] == current) selected = i;
        }
        new AlertDialog.Builder(this).setTitle(R.string.glance_delay_title)
                .setSingleChoiceItems(labels, selected, (dialog, which) -> {
                    choices.edit().putInt(Config.GLANCE_IDLE_MINUTES_KEY, values[which]).apply();
                    changed();
                    refresh();
                    dialog.dismiss();
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void showWallpaperGallery() {
        WallpaperGalleryDialog.show(this, getString(R.string.wallpaper_gallery_empty),
                getString(R.string.wallpaper_gallery_title), (uri, name) -> {
        if (!saveUserWallpaper(uri)) {
            Toast.makeText(this, R.string.wallpaper_pick_failed, Toast.LENGTH_LONG).show();
            return;
        }
        choices.edit().remove(Config.WALLPAPER_CHOICE_KEY)
                .putString(Config.USER_WALLPAPER_NAME_KEY, name).apply();
        changed();
        Toast.makeText(this, R.string.wallpaper_applied, Toast.LENGTH_SHORT).show();
        refresh();
        });
    }

    private boolean saveUserWallpaper(Uri uri) {
        AtomicFile target = new AtomicFile(new File(getFilesDir(), Config.USER_WALLPAPER_FILE));
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream probe = getContentResolver().openInputStream(uri)) {
            if (probe == null) return false;
            BitmapFactory.decodeStream(probe, null, bounds);
        } catch (IOException | SecurityException e) {
            return false;
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false;
        int sample = WallpaperSize.sampleSize(bounds.outWidth, bounds.outHeight,
                getResources().getDisplayMetrics().widthPixels, getResources().getDisplayMetrics().heightPixels);
        if (!WallpaperSize.accepted(bounds.outWidth / sample, bounds.outHeight / sample)) return false;
        FileOutputStream output = null;
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            if (input == null) return false;
            output = target.startWrite();
            byte[] buffer = new byte[8192];
            int count;
            int total = 0;
            while ((count = input.read(buffer)) != -1) {
                total += count;
                if (total > MAX_WALLPAPER_BYTES) throw new IOException("Image exceeds 10 MB");
                output.write(buffer, 0, count);
            }
            if (total == 0) throw new IOException("Empty image");
            target.finishWrite(output);
            return true;
        } catch (IOException | SecurityException e) {
            if (output != null) target.failWrite(output);
            return false;
        }
    }

    private void removeUserWallpaper() {
        new AtomicFile(new File(getFilesDir(), Config.USER_WALLPAPER_FILE)).delete();
        choices.edit().remove(Config.USER_WALLPAPER_NAME_KEY).apply();
    }

    private static int indexOf(List<File> images, String name) {
        if (name == null) return -1;
        for (int i = 0; i < images.size(); i++) {
            if (images.get(i).getName().equals(name)) return i;
        }
        return -1;
    }

    /**
     * A choice was saved. Home rebuilds when it next resumes because the change count moved, whether these
     * settings are left with Back or with the remote's Home button (which cancels the activity result).
     */
    private void changed() {
        setResult(RESULT_OK);
        choices.edit().putLong(Config.SETTINGS_REVISION_KEY,
                choices.getLong(Config.SETTINGS_REVISION_KEY, 0) + 1).apply();
    }

    private void setAdvanced(boolean enabled) {
        advancedEffects = enabled;
        choices.edit().putBoolean("advanced_effects", enabled).apply();
        changed();
        refresh();
    }

    private void refresh() {
        for (int i = 0; i < columnChoices.length; i++) {
            columnChoices[i].setSelected(columns == i + 4);
        }
        for (int i = 0; i < rowChoices.length; i++) {
            rowChoices[i].setSelected(rowsBelowDock == i);
        }
        for (int i = 0; i < dockChoices.length; i++) {
            dockChoices[i].setSelected(dockOpacity == DOCK_OPACITIES[i]);
        }
        appearanceChoice.setText(getString(R.string.appearance_mode) + ": " + getString(darkMode ? R.string.appearance_dark : R.string.appearance_light));
        launcherTileChoice.setText(getString(R.string.launcher_tile_state, getString(choices.getBoolean(Config.LAUNCHER_SETTINGS_TILE_KEY, false) ? R.string.on : R.string.off)));
        launcherTileChoice.setSelected(choices.getBoolean(Config.LAUNCHER_SETTINGS_TILE_KEY, false));
        appLibraryChoice.setText(getString(R.string.app_library_state, getString(choices.getBoolean(Config.APP_LIBRARY_ENABLED_KEY, true) ? R.string.on : R.string.off)));
        appLibraryChoice.setSelected(choices.getBoolean(Config.APP_LIBRARY_ENABLED_KEY, true));
        int slideSeconds=choices.getInt(Config.GLANCE_SLIDE_SECONDS_KEY,20); glanceIntervalChoice.setText(getString(R.string.glance_interval_state,getResources().getQuantityString(R.plurals.glance_interval_seconds,slideSeconds,slideSeconds)));
        ((TextView) findViewById(R.id.aboutVersion)).setText(getString(R.string.about_version, "1.0"));
        animationsChoice.setText(getString(R.string.animations_state,
                getString(animations ? R.string.on : R.string.off)));
        boolean glanceEnabled = choices.getBoolean(Config.GLANCE_ENABLED_KEY, false);
        int glanceMinutes = choices.getInt(Config.GLANCE_IDLE_MINUTES_KEY, 3);
        glanceChoice.setText(getString(R.string.glance_state, getString(glanceEnabled ? R.string.on : R.string.off)));
        glanceChoice.setSelected(glanceEnabled);
        glanceDelayChoice.setText(getResources().getQuantityString(R.plurals.glance_idle_delay,
                glanceMinutes, glanceMinutes));
        glanceDelayChoice.setEnabled(glanceEnabled);
        glanceDelayChoice.setAlpha(glanceEnabled ? 1f : 0.5f);
        advancedChoice.setText(getString(R.string.advanced_effects_state,
                getString(advancedEffects ? R.string.on : R.string.off)));
        advancedChoice.setEnabled(animations);
        advancedChoice.setAlpha(animations ? 1f : 0.5f);
        String wallpaperCurrent = choices.getString(Config.WALLPAPER_CHOICE_KEY, null);
        if (new File(getFilesDir(), Config.USER_WALLPAPER_FILE).isFile()) {
            wallpaperCurrent = choices.getString(Config.USER_WALLPAPER_NAME_KEY,
                    getString(R.string.wallpaper_custom));
        }
        wallpaperChoice.setText(getString(R.string.wallpaper_state,
                "none".equals(wallpaperCurrent) ? getString(R.string.wallpaper_none)
                        : wallpaperCurrent != null ? wallpaperCurrent
                        : getString(R.string.wallpaper_theme_default)));
        followThemeChoice.setSelected(!hasOnTvChoices());
    }

    private boolean hasOnTvChoices() {
        return choices.contains("columns") || choices.contains(Config.ROWS_BELOW_DOCK_KEY)
                || choices.contains("animations") || choices.contains("advanced_effects")
                || choices.contains(Config.WALLPAPER_CHOICE_KEY)
                || choices.contains(Config.USER_WALLPAPER_NAME_KEY) || choices.contains(Config.DOCK_OPACITY_KEY)
                || choices.contains(Config.GLANCE_ENABLED_KEY) || choices.contains(Config.GLANCE_IDLE_MINUTES_KEY) || choices.contains(Config.GLANCE_SLIDE_SECONDS_KEY) || choices.contains(Config.LAUNCHER_SETTINGS_TILE_KEY) || choices.contains(Config.APP_LIBRARY_ENABLED_KEY) || choices.contains(Config.DARK_MODE_KEY);
    }

    private void open(Intent intent) {
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this, R.string.not_available, Toast.LENGTH_LONG).show();
        }
    }
}
