package com.gathin.tvhome;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

/**
 * Base for every launcher screen that follows Text Size. The context wraps the TV's font scale with the
 * owner's step, and a change made on another screen recreates this one on return. Glance and the clock keep
 * their fixed dark look.
 */
public abstract class LauncherActivity extends Activity {
    private int textStepAtCreate;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(TextScale.wrap(base));
    }

    @Override
    protected void onCreate(Bundle state) {
        setTheme(themeRes());
        super.onCreate(state);
        textStepAtCreate = TextScale.step(this);
    }

    /** The theme to inflate with; Control Center overrides this with its translucent variant. */
    protected int themeRes() {
        return R.style.Theme_TvHome;
    }

    /** Home watches its whole settings revision and rebuilds itself, so it opts out of this check. */
    protected boolean recreateOnAppearanceChange() {
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!recreateOnAppearanceChange()) return;
        int textStep = TextScale.step(this);
        if (textStep == textStepAtCreate) return;
        textStepAtCreate = textStep;
        recreate();
    }
}
