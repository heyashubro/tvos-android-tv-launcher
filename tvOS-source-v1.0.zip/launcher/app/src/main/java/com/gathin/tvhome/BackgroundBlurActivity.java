package com.gathin.tvhome;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.view.View;
import android.widget.LinearLayout;
import android.graphics.drawable.GradientDrawable;

/** Dedicated, remote-friendly Background Blur screen, matching the Text Size page. */
public final class BackgroundBlurActivity extends LauncherActivity {
    private SeekBar slider;
    private LinearLayout dots;
    private TextView value;
    private View preview;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_background_blur);
        slider = findViewById(R.id.backgroundBlurSlider);
        dots = findViewById(R.id.backgroundBlurDots);
        value = findViewById(R.id.backgroundBlurValue);
        preview = findViewById(R.id.backgroundBlurPreview);
        slider.setMax(GlassEffect.LEVELS - 1);
        slider.setProgress(GlassEffect.level(this));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                applyLevel(progress, fromUser);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
        applyLevel(GlassEffect.level(this), false);
        slider.requestFocus();
    }

    private void applyLevel(int level, boolean save) {
        value.setText(getString(R.string.glass_blur_state, getString(GlassEffect.labelRes(level))));
        GlassEffect.apply(preview, level);
        showDots(level);
        if (save) {
            SharedPreferences prefs = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
            prefs.edit().putInt(Config.GLASS_BLUR_KEY, level)
                    .putLong(Config.SETTINGS_REVISION_KEY,
                            prefs.getLong(Config.SETTINGS_REVISION_KEY, 0) + 1).apply();
        }
    }

    private void showDots(int selected) {
        dots.removeAllViews();
        for (int i = 0; i < GlassEffect.LEVELS; i++) {
            View dot = new View(this);
            GradientDrawable shape = new GradientDrawable();
            shape.setShape(GradientDrawable.OVAL);
            shape.setColor(i == selected ? 0xFFE5E7EB : 0x668C8E96);
            dot.setBackground(shape);
            int size = dp(i == selected ? 8 : 6);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
            params.setMarginStart(dp(7));
            params.setMarginEnd(dp(7));
            dots.addView(dot, params);
        }
    }

    @Override protected boolean recreateOnAppearanceChange() { return false; }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
