package com.gathin.tvhome;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.PixelCopy;
import android.view.Window;

/**
 * A small, blurred still of Home for Control Center, Profiles and Recent Apps to sit on. It is captured
 * before the panel opens (the panel's own window would otherwise be all it could see). PixelCopy is used
 * rather than View.draw because Home's wallpaper is a hardware bitmap, which a software canvas cannot draw.
 */
final class ControlCenterBackdrop {
    private static final long MAX_AGE_MS = 45_000L;
    private static final int WIDTH = 192;
    private static Bitmap snapshot;
    private static long capturedAt;

    private ControlCenterBackdrop() { }

    /** Captures Home and runs next as soon as the still is ready (immediately if capture cannot start). */
    static void capture(Activity activity, Runnable next) {
        Window window = activity.getWindow();
        int width = window.getDecorView().getWidth();
        int height = window.getDecorView().getHeight();
        if (width <= 1 || height <= 1) {
            if (next != null) next.run();
            return;
        }
        Bitmap full;
        try {
            full = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError | RuntimeException ignored) {
            if (next != null) next.run();
            return;
        }
        try {
            PixelCopy.request(window, full, result -> {
                if (result == PixelCopy.SUCCESS) {
                    snapshot = shrink(full);
                    capturedAt = SystemClock.uptimeMillis();
                }
                full.recycle();
                if (next != null) next.run();
            }, new Handler(Looper.getMainLooper()));
        } catch (RuntimeException ignored) {
            // The window has no surface yet, or the platform refused the copy.
            full.recycle();
            if (next != null) next.run();
        }
    }

    /** The last capture while it is fresh, or null (over another app, or after a while). */
    static Bitmap current() {
        if (snapshot == null) return null;
        if (SystemClock.uptimeMillis() - capturedAt > MAX_AGE_MS) {
            snapshot = null;
            return null;
        }
        return snapshot.isRecycled() ? null : snapshot;
    }

    /** A softer copy of a still, for a panel that wants frosted glass rather than a readable blur. */
    static Bitmap frost(Bitmap source) {
        if (source == null || source.getWidth() <= 32) return source;
        try {
            return Bitmap.createScaledBitmap(source,
                    Math.max(16, source.getWidth() / 2), Math.max(9, source.getHeight() / 2), true);
        } catch (RuntimeException refused) {
            return source;
        }
    }

    private static Bitmap shrink(Bitmap source) {
        int height = Math.max(1, Math.round(WIDTH * source.getHeight() / (float) source.getWidth()));
        Bitmap small = Bitmap.createBitmap(WIDTH, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(small);
        canvas.drawBitmap(source, null, new Rect(0, 0, WIDTH, height), new Paint(Paint.FILTER_BITMAP_FLAG));
        blur(small);
        return small;
    }

    private static void blur(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int[] pixels = new int[width * height];
        int[] temp = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
        for (int pass = 0; pass < 2; pass++) {
            blurRows(pixels, temp, width, height, 3);
            blurColumns(temp, pixels, width, height, 3);
        }
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
    }

    private static void blurRows(int[] source, int[] target, int width, int height, int radius) {
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int a = 0, r = 0, g = 0, b = 0, count = 0;
                for (int dx = -radius; dx <= radius; dx++) {
                    int color = source[y * width + clamp(x + dx, width)];
                    a += color >>> 24;
                    r += (color >> 16) & 0xFF;
                    g += (color >> 8) & 0xFF;
                    b += color & 0xFF;
                    count++;
                }
                target[y * width + x] = (a / count) << 24 | (r / count) << 16 | (g / count) << 8 | b / count;
            }
        }
    }

    private static void blurColumns(int[] source, int[] target, int width, int height, int radius) {
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int a = 0, r = 0, g = 0, b = 0, count = 0;
                for (int dy = -radius; dy <= radius; dy++) {
                    int color = source[clamp(y + dy, height) * width + x];
                    a += color >>> 24;
                    r += (color >> 16) & 0xFF;
                    g += (color >> 8) & 0xFF;
                    b += color & 0xFF;
                    count++;
                }
                target[y * width + x] = (a / count) << 24 | (r / count) << 16 | (g / count) << 8 | b / count;
            }
        }
    }

    private static int clamp(int value, int size) {
        return value < 0 ? 0 : value >= size ? size - 1 : value;
    }
}
