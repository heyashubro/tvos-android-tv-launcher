package com.gathin.tvhome;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class NowPlayingProgressTest {
    @Test
    public void playingRunsOnFromTheLastReport() {
        assertEquals(6_000, NowPlayingProgress.position(1_000, 100, 1f, 60_000, true, 5_100));
        assertEquals(11_000, NowPlayingProgress.position(1_000, 100, 2f, 60_000, true, 5_100));
    }

    @Test
    public void pausedStaysWhereItWas() {
        assertEquals(1_000, NowPlayingProgress.position(1_000, 100, 1f, 60_000, false, 5_100));
    }

    @Test
    public void neverPastTheEndOrBeforeTheStart() {
        assertEquals(60_000, NowPlayingProgress.position(59_000, 100, 1f, 60_000, true, 5_100));
        assertEquals(0, NowPlayingProgress.position(-500, 0, 0f, 60_000, false, 0));
        assertEquals(4_000, NowPlayingProgress.position(4_000, 0, 0f, 0, false, 9_000));
    }

    @Test
    public void clockSkewDoesNotRewind() {
        assertEquals(4_000, NowPlayingProgress.position(4_000, 9_000, 1f, 60_000, true, 5_000));
    }

    @Test
    public void timesReadAsMinutesAndSeconds() {
        assertEquals("0:00", NowPlayingProgress.time(0));
        assertEquals("0:42", NowPlayingProgress.time(42_000));
        assertEquals("3:24", NowPlayingProgress.time(204_000));
        assertEquals("1:02:03", NowPlayingProgress.time(3_723_000));
        assertEquals("0:00", NowPlayingProgress.time(-5_000));
    }
}
