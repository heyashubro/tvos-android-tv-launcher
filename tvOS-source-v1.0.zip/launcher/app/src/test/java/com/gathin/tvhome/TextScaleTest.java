package com.gathin.tvhome;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TextScaleTest {
    @Test
    public void defaultStepKeepsTheSystemScale() {
        assertEquals(1f, TextScale.factor(TextScale.DEFAULT_STEP), 0.0001f);
        assertEquals(100, TextScale.percent(TextScale.DEFAULT_STEP));
    }

    @Test
    public void stepsClampToTheSevenOffered() {
        assertEquals(0, TextScale.clamp(-3));
        assertEquals(TextScale.STEPS - 1, TextScale.clamp(42));
        assertEquals(TextScale.STEPS, TextScale.FACTORS.length);
    }

    @Test
    public void factorsRiseFromSmallToLarge() {
        for (int i = 1; i < TextScale.FACTORS.length; i++) {
            assertTrue(TextScale.FACTORS[i] > TextScale.FACTORS[i - 1]);
        }
        assertEquals(0.85f, TextScale.factor(0), 0.0001f);
        assertEquals(1.3f, TextScale.factor(TextScale.STEPS - 1), 0.0001f);
    }

    @Test
    public void clampingWorksThroughFactorAndPercent() {
        assertEquals(TextScale.factor(0), TextScale.factor(-1), 0.0001f);
        assertEquals(TextScale.factor(TextScale.STEPS - 1), TextScale.factor(99), 0.0001f);
        assertEquals(85, TextScale.percent(-1));
        assertEquals(130, TextScale.percent(99));
    }
}
