package com.gathin.tvhome;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ClockTrustTest {
    @Test
    public void anUnsetRtcIsNotTrusted() {
        assertFalse(ClockTrust.valid(0L));
        assertFalse(ClockTrust.valid(ClockTrust.VALID_AFTER_MS - 1));
    }

    @Test
    public void theCutoverAndLaterAreTrusted() {
        assertTrue(ClockTrust.valid(ClockTrust.VALID_AFTER_MS));
        assertTrue(ClockTrust.valid(ClockTrust.VALID_AFTER_MS + 1));
    }

    @Test
    public void retriesBackOffAndStayAtTheSlowest() {
        assertEquals(1_000L, ClockTrust.retryDelayMs(0));
        assertEquals(30_000L, ClockTrust.retryDelayMs(4));
        assertEquals(30_000L, ClockTrust.retryDelayMs(99));
        assertEquals(1_000L, ClockTrust.retryDelayMs(-1));
        for (int i = 1; i < 5; i++) {
            assertTrue(ClockTrust.retryDelayMs(i) > ClockTrust.retryDelayMs(i - 1));
        }
    }
}
